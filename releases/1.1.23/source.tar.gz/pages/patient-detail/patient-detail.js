import {
  addClinicalEvent, addDrain, addReminderAsTask, addSettingItem, addTask, archivePatient, changePatientStage, dischargePatient, ensureStageTasks,
  formatBeijingDateTime, getDepartmentWards, getPatient, getPatientBundle, getPatientFlow, getPatientReminders, getPOD, getPrivacyMaskEnabled, getWorkspace, isDrainPeriod, isIntraoperativeOrLater, isPostoperative, isPreAdmission, maskPatient,
  ensureDrainRowCount, recordDrainVolume, removeDrain, revertPatientDischarge, revokePatientRegistration, setPrivacyMaskEnabled, setTaskDone, todayKey, updatePatient,
} from '../../utils/workspace-store';

const CUSTOM_PROCEDURE_OPTION = '＋ 自定义新术式';
const CUSTOM_ASSISTANT_OPTION = '其他（手动填写）';
const ALLERGY_OPTIONS = [
  { value: 'unknown', label: '未核实' }, { value: 'none', label: '无' }, { value: 'present', label: '有' },
];
const SURGERY_NAME_CONFIRM_TASK = '与主刀确认手术名称，并核实手术同意书名称';
const EVENT_LABELS = { 'drain-status': '引流', 'patient-revision': '资料修改' };
const VALUE_LABELS = { active: '在位', removed: '已拔除' };

function wardFormState(department, departmentWards, ward = '') {
  const wardOptions = getDepartmentWards(department, { departmentWards });
  const selectedWard = wardOptions.length === 1 ? wardOptions[0] : (wardOptions.includes(ward) ? ward : '');
  return { wardOptions, ward: selectedWard, wardIndex: Math.max(0, wardOptions.indexOf(selectedWard)) };
}

function missingFields(patient, fields) {
  return fields.filter((field) => !`${patient[field] || ''}`.trim());
}

function appointmentText(patient, type) {
  if (type === 'discharge-notice') return dischargeNoticeText(patient);
  const surgeryName = patient.confirmedSurgeryName || patient.surgeryName;
  const surgerySchedule = patient.surgeryDate ? `拟于${patient.surgeryDate}行${surgeryName}` : `拟行${surgeryName}`;
  if (type === 'photo') {
    return `老师好，申请拍照\n${patient.name} ${patient.age}/${patient.gender}，${patient.id}，${patient.diagnosis}，${surgerySchedule}。${patient.surgeon}/代寰宇`;
  }
  if (type === 'surgery-summary') {
    const shortName = `${patient.name || ''}`.trim().slice(0, 1);
    const gender = patient.gender === '女' ? 'F' : patient.gender === '男' ? 'M' : patient.gender;
    return `${shortName}*，${patient.age}/${gender}，诊断：${patient.diagnosis}\n拟行：${surgeryName}`;
  }
  return `老师您好，${patient.name}，${patient.gender}，${patient.id}，${patient.diagnosis}，${patient.surgeryDate ? `拟于${patient.surgeryDate}手术切除` : '拟手术切除'}，申请术后放疗`;
}

function appointmentTitle(type) {
  if (type === 'discharge-notice') return '核对出院通知';
  if (type === 'surgery-summary') return '核对 PPT 患者信息模板';
  return type === 'photo' ? '核对拍照预约文本' : '核对放疗预约文本';
}

function dischargeNoticeText(patient) {
  return `${patient.firstAssistant}老师您好，【${patient.patientType}】出院病人${patient.name}（${patient.id}）于${patient.actualDischargeDate}出院，现病历已经整理完毕，请您审核、修改并提交，谢谢。`;
}

function isRadiotherapyCandidate(diagnosis) {
  return /瘢痕疙瘩|瘢痕瘤|keloid/i.test(diagnosis || '');
}

function isRadiotherapySchedule(patient) {
  if (!isRadiotherapyCandidate(patient.diagnosis)) return false;
  const today = todayKey();
  const [year, month, day] = today.split('-').map(Number);
  const tomorrowDate = new Date(Date.UTC(year, month - 1, day + 1));
  const tomorrow = `${tomorrowDate.getUTCFullYear()}-${`${tomorrowDate.getUTCMonth() + 1}`.padStart(2, '0')}-${`${tomorrowDate.getUTCDate()}`.padStart(2, '0')}`;
  return patient.surgeryDate === (patient.patientType === '日间' ? today : tomorrow);
}

function buildDrainTable(patient, currentPod) {
  const columns = (patient.devices || []).filter((device) => device.type === 'drain');
  const entries = (patient.observations || []).filter((item) => columns.some((device) => device.id === item.deviceId));
  const discharged = ['出院', '整理'].includes(patient.stage) || Boolean(patient.actualDischargeDate);
    const maxPod = Math.max(1, patient.drainRowCount || 0, currentPod > 0 ? currentPod : 1, ...entries.map((item) => Number(item.pod) || 1));
  const byCell = new Map(entries.map((item) => [`${item.deviceId}:${item.pod}`, item]));
  return {
    columns: columns.map((device) => ({ ...device, canDelete: !entries.some((item) => item.deviceId === device.id) })),
    activeColumnCount: columns.filter((device) => device.status === 'active').length,
    width: 156 + columns.length * 168,
    rows: Array.from({ length: maxPod }, (_, index) => {
      const pod = index + 1;
      return {
        pod,
        cells: columns.map((device) => {
          const entry = byCell.get(`${device.id}:${pod}`);
          const removal = entries.find((item) => item.deviceId === device.id && item.entryType === 'removed');
          return {
            deviceId: device.id, deviceName: device.name, pod,
            text: entry ? (entry.entryType === 'removed' ? '拔' : `${entry.value} mL`) : '记录',
            entryType: entry ? entry.entryType : '', value: entry && entry.entryType === 'volume' ? `${entry.value}` : '',
            editable: !discharged && (device.status === 'active' || (removal && pod <= removal.pod)),
          };
        }),
      };
    }),
  };
}

function completeAppointmentTask(patientId, type) {
  const labelMap = { photo: '拍照预约文本', radiotherapy: '放疗预约文本', 'surgery-summary': 'PPT 患者信息模板' };
  if (!labelMap[type]) return false;
  const eventSaved = addClinicalEvent(patientId, `cooperation-${type}`, `已复制${labelMap[type]}`).ok;
  if (type === 'surgery-summary') return eventSaved;
  if (!['photo', 'radiotherapy'].includes(type)) return false;
  const title = type === 'photo' ? '完成术前拍照' : '完成放疗科会诊';
  const task = getWorkspace().tasks.find((item) => item.patientId === patientId && item.title === title);
  if (!task || task.status === 'done') return eventSaved;
  return setTaskDone(patientId, task.id, true).ok && eventSaved;
}

Page({
  data: { patient: null, privacyVisible: true, newTask: '', taskCategories: [], taskCategoryIndex: 0, flow: [], reminders: [], archived: false, intraoperative: false, postoperative: false, drains: [], drainTable: { columns: [], rows: [], width: 156 }, intraopAssistantOptions: [], intraopAssistantIndex: 0, clinicalEvents: [], revisionEvents: [], appointmentTypes: [], editing: false, editForm: {}, dischargeDateInput: '', departments: [], departmentWards: {}, departmentIndex: 0, wardOptions: [], wardIndex: 0, procedures: [], procedureOptions: [], procedureIndex: 0, customProcedureMode: false, customProcedure: '', addCustomProcedureToLibrary: false, conditionOptions: [], editConditions: [], genders: ['男', '女'], patientTypes: ['普通', '国疗', '日间'], allergyOptions: ALLERGY_OPTIONS, firstAssistants: [], firstAssistantOptions: [], firstAssistantIndex: 0, customAssistantMode: false, customAssistant: '', addCustomAssistantToLibrary: false, editor: { visible: false, title: '', description: '', placeholder: '', content: '', kind: '', taskId: '', drainId: '', pod: 0, nextStage: '', focus: false }, editorKeyboardHeight: 0 },
  onLoad(options) { this.patientId = decodeURIComponent(options.id || ''); },
  onShow() {
    this.setData({ privacyVisible: !getPrivacyMaskEnabled() });
    ensureStageTasks(this.patientId);
    this.loadPatient();
  },
  loadPatient() {
    const original = getPatientBundle(this.patientId);
    const workspace = getWorkspace();
    if (!original) return wx.showToast({ title: '未找到患者', icon: 'none' });
    const masked = maskPatient(original, workspace.settings.departmentWards);
    const displayPatient = this.data.privacyVisible ? { ...masked, displayName: original.name, displayId: original.id } : masked;
    const patientFlow = getPatientFlow(original);
    const current = patientFlow.findIndex((item) => item.name === original.stage);
    const flow = patientFlow.map((step, index) => {
      const pendingCritical = original.tasks.filter((task) => task.stage === step.name && task.critical && task.status !== 'done').length;
      return { name: step.name, pendingCritical, state: index < current ? 'done' : index === current ? 'current' : 'pending', action: index === current ? 'complete' : index < current ? 'rollback' : 'locked', actionLabel: index < current ? '已完成' : index === current ? '点击完成' : '待开始' };
    });
    const pod = getPOD(original.surgeryDate);
    const reminders = original.archived ? [] : getPatientReminders(original).map((item) => ({
      ...item,
      alreadyAdded: original.tasks.some((task) => task.sourceRef === item.sourceRef),
    }));
    const rounds = original.rounds.map((round) => ({ ...round, timeText: formatBeijingDateTime(round.createdAt).slice(11, 16) }));
    const tasks = original.tasks.map((task) => ({
      ...task, done: task.status === 'done', dueText: task.dueAt ? task.dueAt.slice(0, 10) : '未设置',
      priorityClass: task.priority === '重要' ? 'important' : '', requiresSurgeryNameConfirm: task.title === SURGERY_NAME_CONFIRM_TASK,
    }));
    const stageLogs = (original.stageLogs || []).slice(0, 8).map((log) => ({ ...log, timeText: formatBeijingDateTime(log.at) }));
    const intraoperative = isIntraoperativeOrLater(original);
    const postoperative = isDrainPeriod(original) || (original.devices || []).some((device) => device.type === 'drain' && device.legacy);
    const drainTable = buildDrainTable(original, pod);
    const drains = drainTable.columns;
    const intraopAssistantOptions = ['未填写', ...workspace.settings.firstAssistants, CUSTOM_ASSISTANT_OPTION];
    const knownAssistantIndex = workspace.settings.firstAssistants.indexOf(original.firstAssistant);
    const intraopAssistantIndex = knownAssistantIndex >= 0 ? knownAssistantIndex + 1 : (original.firstAssistant ? intraopAssistantOptions.length - 1 : 0);
    const clinicalEvents = (original.clinicalEvents || []).filter((item) => EVENT_LABELS[item.type]).sort((a, b) => b.at.localeCompare(a.at)).slice(0, 10).map((item) => {
      const statusText = VALUE_LABELS[item.value] || item.value;
      return { ...item, typeLabel: EVENT_LABELS[item.type], valueLabel: `${item.note ? `${item.note} · ` : ''}${statusText}`, timeText: formatBeijingDateTime(item.at) };
    });
    const revisionEvents = (original.clinicalEvents || []).filter((item) => item.type === 'patient-revision').sort((a, b) => b.at.localeCompare(a.at)).slice(0, 5).map((item) => ({ ...item, timeText: formatBeijingDateTime(item.at) }));
    const preopTasks = original.stage === '术前' ? tasks.filter((task) => task.stage === '术前' && task.source !== '已取消的阶段要求') : [];
    const preopIds = new Set(preopTasks.map((task) => task.id));
    const appointmentTypes = original.archived ? [] : [
      ...(original.department === '整形外科' && !['出院', '整理'].includes(original.stage) ? [
      { type: 'photo', title: '生成拍照预约文本', desc: '手术日期为明日时可复制；复制后自行核对并发送', done: (original.clinicalEvents || []).some((item) => item.type === 'cooperation-photo') || tasks.some((task) => task.title === '完成术前拍照' && task.status === 'done') },
      { type: 'surgery-summary', title: '生成 PPT 患者信息模板', desc: original.surgeryNameConfirmedAt && original.confirmedSurgeryName ? '简略姓名与已确认术式' : '完成主刀术式确认后可生成', done: (original.clinicalEvents || []).some((item) => item.type === 'cooperation-surgery-summary' || item.type === 'ppt-copy') },
      ...(isRadiotherapySchedule(original) ? [{ type: 'radiotherapy', title: '生成放疗预约文本', desc: original.patientType === '日间' ? '日间手术当日可复制；复制后自行核对并发送' : '明日手术可复制；复制后自行核对并发送', done: (original.clinicalEvents || []).some((item) => item.type === 'cooperation-radiotherapy') || tasks.some((task) => task.title === '完成放疗科会诊' && task.status === 'done') }] : []),
      ] : []),
      ...(['出院', '整理'].includes(original.stage) ? [{ type: 'discharge-notice', title: '生成出院通知', desc: '请预览复制并自行发送；通知一助后再标记完成', done: (original.clinicalEvents || []).some((item) => item.type === 'cooperation-discharge-notice') }] : []),
    ];
    this.setData({
      patient: { ...displayPatient, rounds, tasks, generalTasks: tasks.filter((task) => !preopIds.has(task.id)), preopTasks, surgeryNameConfirmed: Boolean(original.surgeryNameConfirmedAt), confirmedSurgeryName: original.confirmedSurgeryName || '', podText: pod === null ? '' : pod < 0 ? `术前 ${Math.abs(pod)} 天` : `POD ${pod}`, stageLogs },
      flow, reminders, archived: original.archived, intraoperative, postoperative, drains, drainTable, intraopAssistantOptions, intraopAssistantIndex, clinicalEvents, revisionEvents, appointmentTypes,
      dischargeDateInput: original.actualDischargeDate || (original.patientType === '日间' ? original.admissionDate : todayKey()),
      taskCategories: workspace.settings.taskCategories, taskCategoryIndex: Math.max(0, workspace.settings.taskCategories.indexOf(this.data.taskCategories[this.data.taskCategoryIndex]) >= 0 ? workspace.settings.taskCategories.indexOf(this.data.taskCategories[this.data.taskCategoryIndex]) : workspace.settings.taskCategories.indexOf('其他')),
    });
  },
  togglePrivacy() { const privacyVisible = !this.data.privacyVisible; setPrivacyMaskEnabled(!privacyVisible); this.setData({ privacyVisible }, () => this.loadPatient()); },
  startEdit() {
    if (this.data.archived) return;
    const patient = getPatient(this.patientId);
    const workspace = getWorkspace();
    if (!patient) return;
    const procedures = workspace.settings.procedures;
    const knownProcedureIndex = procedures.indexOf(patient.surgeryName || '未选择术式');
    const customProcedureMode = Boolean(patient.surgeryName) && knownProcedureIndex < 0;
    const firstAssistants = workspace.settings.firstAssistants;
    const assistantIndex = firstAssistants.indexOf(patient.firstAssistant);
    const wards = wardFormState(patient.department, workspace.settings.departmentWards, patient.ward);
    this.setData({
      editing: true, departments: workspace.settings.departments, departmentWards: workspace.settings.departmentWards, wardOptions: wards.wardOptions, wardIndex: wards.wardIndex, procedures, procedureOptions: [...procedures, CUSTOM_PROCEDURE_OPTION], conditionOptions: workspace.settings.conditionTags.filter((item) => !['有引流', '留置导尿'].includes(item)).map((value) => ({ value, selected: (patient.conditions || []).includes(value) })), editConditions: (patient.conditions || []).filter((item) => !['有引流', '留置导尿'].includes(item)),
      departmentIndex: Math.max(0, workspace.settings.departments.indexOf(patient.department)),
      procedureIndex: customProcedureMode ? procedures.length : Math.max(0, knownProcedureIndex),
      customProcedureMode, customProcedure: customProcedureMode ? patient.surgeryName : '', addCustomProcedureToLibrary: false,
      firstAssistants, firstAssistantOptions: ['未填写', ...firstAssistants, CUSTOM_ASSISTANT_OPTION], firstAssistantIndex: assistantIndex >= 0 ? assistantIndex + 1 : (patient.firstAssistant ? firstAssistants.length + 1 : 0), customAssistantMode: Boolean(patient.firstAssistant) && assistantIndex < 0, customAssistant: assistantIndex < 0 ? patient.firstAssistant : '', addCustomAssistantToLibrary: false,
      editForm: {
        id: patient.id, name: patient.name, ward: wards.ward, bed: patient.bed, age: patient.age || '', gender: patient.gender || '', patientType: patient.patientType || '普通',
        diagnosis: patient.diagnosis || '', allergyStatus: patient.allergyStatus || (patient.allergies ? 'present' : 'unknown'), allergies: patient.allergies || '', admissionDate: patient.admissionDate || '', surgeryDate: patient.surgeryDate || '', plannedDischargeDate: patient.plannedDischargeDate || '', surgeon: patient.surgeon || '', firstAssistant: patient.firstAssistant || '',
      },
    });
  },
  cancelEdit() { this.setData({ editing: false, editForm: {}, customProcedureMode: false, customProcedure: '', addCustomProcedureToLibrary: false }); },
  inputEdit(e) {
    const field = e.currentTarget.dataset.field;
    const value = ['bed', 'age'].includes(field) ? `${e.detail.value}`.replace(/\D/g, '') : e.detail.value;
    const updates = { [`editForm.${field}`]: value };
    if (field === 'admissionDate' && this.data.editForm.patientType === '日间') {
      updates['editForm.surgeryDate'] = value;
      updates['editForm.plannedDischargeDate'] = value;
    }
    this.setData(updates);
  },
  chooseEditGender(e) { this.setData({ 'editForm.gender': e.currentTarget.dataset.value }); },
  chooseEditType(e) {
    const patientType = e.currentTarget.dataset.value;
    const updates = { 'editForm.patientType': patientType };
    if (patientType === '日间' && this.data.editForm.admissionDate) {
      updates['editForm.surgeryDate'] = this.data.editForm.admissionDate;
      updates['editForm.plannedDischargeDate'] = this.data.editForm.admissionDate;
    }
    this.setData(updates);
  },
  chooseEditAllergyStatus(e) { this.setData({ 'editForm.allergyStatus': e.currentTarget.dataset.value, 'editForm.allergies': e.currentTarget.dataset.value === 'none' ? '' : this.data.editForm.allergies }); },
  chooseEditFirstAssistant(e) {
    const firstAssistantIndex = Number(e.detail.value);
    const customAssistantMode = firstAssistantIndex === this.data.firstAssistantOptions.length - 1;
    const firstAssistant = customAssistantMode ? this.data.editForm.firstAssistant : (this.data.firstAssistantOptions[firstAssistantIndex] === '未填写' ? '' : this.data.firstAssistantOptions[firstAssistantIndex]);
    this.setData({ firstAssistantIndex, customAssistantMode, customAssistant: customAssistantMode ? this.data.customAssistant || this.data.editForm.firstAssistant : '', 'editForm.firstAssistant': firstAssistant, addCustomAssistantToLibrary: customAssistantMode ? this.data.addCustomAssistantToLibrary : false });
  },
  inputEditCustomAssistant(e) { this.setData({ customAssistant: e.detail.value, 'editForm.firstAssistant': e.detail.value }); },
  toggleEditCustomAssistantLibrary(e) { this.setData({ addCustomAssistantToLibrary: Boolean(e.detail.value) }); },
  toggleEditCondition(e) {
    const value = e.currentTarget.dataset.value;
    const editConditions = this.data.editConditions.includes(value) ? this.data.editConditions.filter((item) => item !== value) : [...this.data.editConditions, value];
    this.setData({ editConditions, conditionOptions: this.data.conditionOptions.map((item) => ({ ...item, selected: editConditions.includes(item.value) })) });
  },
  chooseEditDepartment(e) {
    const departmentIndex = Number(e.detail.value);
    const wards = wardFormState(this.data.departments[departmentIndex], this.data.departmentWards);
    this.setData({ departmentIndex, wardOptions: wards.wardOptions, wardIndex: wards.wardIndex, 'editForm.ward': wards.ward });
  },
  chooseEditWard(e) { const wardIndex = Number(e.detail.value); this.setData({ wardIndex, 'editForm.ward': this.data.wardOptions[wardIndex] || '' }); },
  chooseEditProcedure(e) {
    const procedureIndex = Number(e.detail.value);
    const customProcedureMode = procedureIndex === this.data.procedureOptions.length - 1;
    this.setData({ procedureIndex, customProcedureMode, customProcedure: customProcedureMode ? this.data.customProcedure : '', addCustomProcedureToLibrary: customProcedureMode ? this.data.addCustomProcedureToLibrary : false });
  },
  inputEditCustomProcedure(e) { this.setData({ customProcedure: e.detail.value }); },
  toggleEditCustomProcedureLibrary(e) { this.setData({ addCustomProcedureToLibrary: Boolean(e.detail.value) }); },
  saveEdit() {
    const form = this.data.editForm;
    if (!`${form.id || ''}`.trim() || !`${form.name || ''}`.trim() || (!isPreAdmission(form) && !`${form.bed || ''}`.trim()) || !`${form.surgeon || ''}`.trim()) return wx.showToast({ title: isPreAdmission(form) ? '请填写住院号、姓名、性别和主刀医生' : '请填写红色 * 标记的项目', icon: 'none' });
    if (!form.gender) return wx.showToast({ title: '请选择性别', icon: 'none' });
    const selectedProcedure = this.data.procedureOptions[this.data.procedureIndex];
    const procedure = this.data.customProcedureMode ? `${this.data.customProcedure || ''}`.trim() : selectedProcedure;
    if (this.data.customProcedureMode && !procedure) return wx.showToast({ title: '请填写自定义术式名称', icon: 'none' });
    const result = updatePatient(this.patientId, {
      id: form.id.trim(), name: form.name.trim(), ward: `${form.ward || ''}`.trim(), bed: form.bed, age: form.age, gender: form.gender, patientType: form.patientType,
      diagnosis: `${form.diagnosis || ''}`.trim(), allergyStatus: form.allergyStatus, allergies: `${form.allergies || ''}`.trim(), admissionDate: form.admissionDate, surgeryDate: form.surgeryDate, plannedDischargeDate: form.plannedDischargeDate,
      surgeryName: procedure === '未选择术式' ? '' : procedure, surgeon: form.surgeon.trim(), firstAssistant: `${form.firstAssistant || ''}`.trim(),
      department: this.data.departments[this.data.departmentIndex], conditions: this.data.editConditions,
    });
    if (!result.ok) return wx.showToast({ title: result.error, icon: 'none', duration: 2500 });
    if (this.data.customProcedureMode && this.data.addCustomProcedureToLibrary) addSettingItem('procedures', procedure);
    if (this.data.customAssistantMode && this.data.addCustomAssistantToLibrary && `${form.firstAssistant || ''}`.trim()) addSettingItem('firstAssistants', `${form.firstAssistant}`.trim());
    this.patientId = form.id.trim();
    this.setData({ editing: false, editForm: {}, customProcedureMode: false, customProcedure: '', addCustomProcedureToLibrary: false });
    this.loadPatient();
    wx.showToast({ title: '患者资料已更新', icon: 'success' });
  },
  copyAppointment(e) {
    const patient = getPatient(this.patientId);
    const type = e.currentTarget.dataset.type;
    if (!patient || !['photo', 'radiotherapy', 'surgery-summary', 'discharge-notice'].includes(type)) return;
    const fields = type === 'photo' ? ['name', 'age', 'gender', 'id', 'diagnosis', 'surgeryName', 'surgeon'] : type === 'surgery-summary' ? ['name', 'age', 'gender', 'diagnosis', 'confirmedSurgeryName'] : type === 'discharge-notice' ? ['firstAssistant', 'name', 'id', 'patientType', 'actualDischargeDate'] : ['name', 'gender', 'id', 'diagnosis'];
    const missing = missingFields(patient, fields);
    if (missing.length) return wx.showToast({ title: type === 'photo' ? '请补全患者、术式和主刀信息' : type === 'surgery-summary' ? '请补全姓名、年龄、性别、诊断和术式' : type === 'discharge-notice' ? '请补全一助、姓名、住院号、类别和出院日期' : '请补全患者基本信息和诊断', icon: 'none', duration: 2600 });
    if (type === 'discharge-notice' && !['出院', '整理'].includes(patient.stage) && !patient.archived) return wx.showToast({ title: '请先确认患者出院', icon: 'none' });
    if (type === 'surgery-summary' && (!patient.surgeryNameConfirmedAt || !patient.confirmedSurgeryName)) return wx.showToast({ title: '请先完成主刀术式确认', icon: 'none', duration: 2400 });
    const text = appointmentText(patient, type);
    const timingHint = type === 'photo' && getPOD(patient.surgeryDate) !== -1 ? '\n\n提示：当前手术日期不是明日，请核对文本和发送时机。' : type === 'radiotherapy' && !isRadiotherapySchedule(patient) ? '\n\n提示：日间患者应为当日手术；普通或国疗患者应为明日手术，请核对。' : '';
    wx.showModal({
      title: appointmentTitle(type), content: `${text}${timingHint}`, confirmText: '确认复制',
      success: (result) => {
        if (!result.confirm) return;
        wx.setClipboardData({ data: text, success: () => {
          const offSchedule = Boolean(timingHint);
          const completed = type === 'discharge-notice' || offSchedule ? false : completeAppointmentTask(this.patientId, type);
          wx.showToast({ title: offSchedule ? '文本已复制，请核对时机；未标记任务完成' : completed ? `文本已复制，已标记${type === 'photo' ? '拍照' : type === 'radiotherapy' ? '放疗会诊' : 'PPT 已完成'}` : '文本已复制，请手动发送', icon: 'none', duration: 2600 });
          if (completed) this.loadPatient();
        } });
      },
    });
  },
  markDischargeNoticeSent() {
    const patient = getPatient(this.patientId);
    if (!patient || !['出院', '整理'].includes(patient.stage)) return wx.showToast({ title: '请先确认患者出院', icon: 'none' });
    if (getWorkspace().clinicalEvents.some((item) => item.patientId === this.patientId && item.type === 'cooperation-discharge-notice')) return wx.showToast({ title: '出院通知已完成', icon: 'none' });
    wx.showModal({
      title: '确认已完成出院通知？', content: '请确认已将出院通知发送给一助老师；此确认将记录完成时间，并作为归档前置条件。', confirmText: '确认完成',
      success: (result) => {
        if (!result.confirm) return;
        const saved = addClinicalEvent(this.patientId, 'cooperation-discharge-notice', '已确认通知一助');
        if (!saved.ok) return wx.showToast({ title: saved.error || '保存失败', icon: 'none' });
        wx.showToast({ title: '出院通知已完成', icon: 'success' });
        this.loadPatient();
      },
    });
  },
  inputTask(e) { this.setData({ newTask: e.detail.value }); },
  chooseTaskCategory(e) { this.setData({ taskCategoryIndex: Number(e.detail.value) }); },
  addTask() {
    const title = this.data.newTask.trim();
    if (!title) return wx.showToast({ title: '请输入待办内容', icon: 'none' });
    const result = addTask(this.patientId, { title, dueAt: todayKey(), category: this.data.taskCategories[this.data.taskCategoryIndex] || '其他', priority: '普通' });
    if (!result.ok) return wx.showToast({ title: result.error, icon: 'none' });
    this.setData({ newTask: '' });
    this.loadPatient();
  },
  toggleTask(e) {
    if (this.data.archived) return;
    const task = this.data.patient.tasks.find((item) => item.id === e.currentTarget.dataset.id);
    if (!task) return;
    if (task.requiresSurgeryNameConfirm) return this.confirmSurgeryName(task);
    const done = !task.done;
    if (done && task.critical) return wx.showModal({
      title: '确认完成关键任务？', content: `请确认“${task.title}”已实际完成；完成时间将自动留痕。`, confirmText: '确认完成',
      success: (modal) => {
        if (!modal.confirm) return;
        const result = setTaskDone(this.patientId, task.id, true);
        if (!result.ok) return wx.showToast({ title: result.error, icon: 'none', duration: 2400 });
        wx.showToast({ title: '已完成并留痕', icon: 'success' });
        this.loadPatient();
      },
    });
    const result = setTaskDone(this.patientId, task.id, done);
    if (!result.ok) return wx.showToast({ title: result.error, icon: 'none', duration: 2400 });
    wx.showToast({ title: done ? '已完成' : '已恢复待办', icon: 'success' });
    this.loadPatient();
  },
  confirmSurgeryName(task) {
    const patient = getPatient(this.patientId);
    if (!patient) return;
    this.openEditor({ kind: 'surgery-confirm', title: '与主刀确认正式术式', description: '确认后会完成此任务，并解锁手术同意书签署。', placeholder: '填写确认后的正式手术名称', content: patient.confirmedSurgeryName || patient.surgeryName || '', taskId: task.id, confirmText: '确认保存' });
  },
  addReminder(e) {
    const reminder = this.data.reminders.find((item) => item.id === e.currentTarget.dataset.id);
    if (!reminder || reminder.alreadyAdded) return;
    const result = addReminderAsTask(this.patientId, reminder);
    wx.showToast({ title: result.ok ? '已加入今日待办' : result.error, icon: result.ok ? 'success' : 'none' });
    this.loadPatient();
  },
  chooseIntraopFirstAssistant(e) {
    if (this.data.archived || this.data.patient.careStatus === '出院') return;
    const assistant = this.data.intraopAssistantOptions[Number(e.detail.value)];
    if (assistant === CUSTOM_ASSISTANT_OPTION) {
      const patient = getPatient(this.patientId);
      return this.openEditor({ kind: 'first-assistant', title: '填写其他一助医生', placeholder: '一助医生姓名', content: patient && patient.firstAssistant ? patient.firstAssistant : '', confirmText: '保存' });
    }
    const result = updatePatient(this.patientId, { firstAssistant: assistant === '未填写' ? '' : assistant });
    if (!result.ok) return wx.showToast({ title: result.error, icon: 'none' });
    wx.showToast({ title: assistant === '未填写' ? '已清空一助' : '一助已更新', icon: 'success' });
    this.loadPatient();
  },
  addDrain() {
    if (this.data.archived || this.data.patient.careStatus === '出院') return;
    this.openEditor({ kind: 'drain', title: '添加引流', placeholder: '例如：盆腔引流、T 管', confirmText: '添加' });
  },
  addDrainRow() {
    if (this.data.archived || this.data.patient.careStatus === '出院' || !this.data.drainTable.columns.length) return;
    const result = ensureDrainRowCount(this.patientId, this.data.drainTable.rows.length + 1);
    if (!result.ok) return wx.showToast({ title: result.error, icon: 'none' });
    this.loadPatient();
    wx.showToast({ title: `已添加 POD ${result.rowCount} 行`, icon: 'success' });
  },
  editDrainCell(e) {
    if (this.data.archived || this.data.patient.careStatus === '出院') return;
    const { deviceId, deviceName, pod, value } = e.currentTarget.dataset;
    this.openEditor({ kind: 'drain-cell', title: `${deviceName} · POD ${pod}`, description: '填写引流量（mL）；输入“拔”可记录该引流在本次拔除。', placeholder: '例如：20 或 拔', content: value || '', drainId: deviceId, pod: Number(pod), confirmText: '保存' });
  },
  removeDrainColumn(e) {
    if (this.data.archived || this.data.patient.careStatus === '出院') return;
    const { deviceId, deviceName } = e.currentTarget.dataset;
    wx.showModal({ title: '移除引流列？', content: `将移除“${deviceName}”。仅无任何记录的误加引流可以移除。`, confirmText: '移除', confirmColor: '#c33b35', success: (modal) => {
      if (!modal.confirm) return;
      const result = removeDrain(this.patientId, deviceId);
      if (!result.ok) return wx.showToast({ title: result.error, icon: 'none', duration: 2600 });
      this.loadPatient();
      wx.showToast({ title: '已移除引流列', icon: 'success' });
    } });
  },
  openEditor(config) {
    this.setData({ editor: { visible: true, title: config.title || '', description: config.description || '', placeholder: config.placeholder || '', content: config.content || '', kind: config.kind || '', taskId: config.taskId || '', drainId: config.drainId || '', pod: config.pod || 0, nextStage: config.nextStage || '', confirmText: config.confirmText || '保存', warningConfirmed: false, focus: true }, editorKeyboardHeight: 0 });
  },
  closeEditor() { this.setData({ editor: { visible: false, title: '', description: '', placeholder: '', content: '', kind: '', taskId: '', drainId: '', pod: 0, nextStage: '', confirmText: '保存', warningConfirmed: false, focus: false }, editorKeyboardHeight: 0 }); },
  keepEditorOpen() {},
  inputEditor(e) { this.setData({ 'editor.content': e.detail.value }); },
  editorKeyboardChange(e) {
    const editorKeyboardHeight = Math.max(0, Number(e.detail.height) || 0);
    if (editorKeyboardHeight !== this.data.editorKeyboardHeight) this.setData({ editorKeyboardHeight });
  },
  editorBlur() { this.setData({ editorKeyboardHeight: 0 }); },
  saveEditor() {
    const editor = this.data.editor;
    const value = `${editor.content || ''}`.trim();
    let result;
    if (editor.kind === 'surgery-confirm') {
      if (!value) return wx.showToast({ title: '请填写正式手术名称', icon: 'none' });
      result = updatePatient(this.patientId, { confirmedSurgeryName: value });
      if (result.ok) result = setTaskDone(this.patientId, editor.taskId, true);
      if (!result.ok) return wx.showToast({ title: result.error || '保存失败', icon: 'none' });
      this.closeEditor();
      wx.showToast({ title: '正式术式已确认', icon: 'success' });
      return this.loadPatient();
    }
    if (editor.kind === 'first-assistant') result = updatePatient(this.patientId, { firstAssistant: value });
    if (editor.kind === 'drain') result = addDrain(this.patientId, value);
    if (editor.kind === 'drain-cell') result = recordDrainVolume(this.patientId, editor.drainId, value, editor.pod, { confirmWarning: Boolean(editor.warningConfirmed) });
    if (editor.kind === 'discharge-revert') {
      if (!value) return wx.showToast({ title: '请填写撤回出院原因', icon: 'none' });
      result = revertPatientDischarge(this.patientId, value);
    }
    if (editor.kind === 'stage-back') {
      if (!value) return wx.showToast({ title: '请填写退回原因', icon: 'none' });
      this.closeEditor();
      return this.applyStageChange(editor.nextStage, value);
    }
    if (result && result.requiresWarningConfirmation) return wx.showModal({ title: '请核对引流量', content: result.warning, confirmText: '确认保存', success: (modal) => { if (modal.confirm) { this.setData({ 'editor.warningConfirmed': true }); this.saveEditor(); } } });
    if (!result || !result.ok) return wx.showToast({ title: (result && result.error) || '保存失败', icon: 'none' });
    this.closeEditor();
    wx.showToast({ title: result.warning || (editor.kind === 'drain' ? '已添加引流列' : editor.kind === 'drain-cell' ? '引流记录已保存' : '已保存'), icon: result.warning ? 'none' : 'success', duration: result.warning ? 3000 : 1500 });
    this.loadPatient();
  },
  goRound() {
    if (this.data.archived) return wx.showToast({ title: '归档患者为只读状态', icon: 'none' });
    wx.navigateTo({ url: `/pages/rounds/rounds?id=${encodeURIComponent(this.patientId)}` });
  },
  selectStage(e) {
    if (this.data.archived) return wx.showToast({ title: '归档患者为只读状态', icon: 'none' });
    const selectedStage = e.currentTarget.dataset.stage;
    const currentPatient = getPatient(this.patientId);
    if (!currentPatient) return;
    const names = getPatientFlow(currentPatient).map((item) => item.name);
    const currentIndex = names.indexOf(currentPatient.stage);
    const selectedIndex = names.indexOf(selectedStage);
    if (currentIndex < 0 || selectedIndex < 0) return wx.showToast({ title: '流程配置异常，请先核对设置', icon: 'none' });
    if (selectedIndex > currentIndex) return wx.showToast({ title: `请先完成“${currentPatient.stage}”`, icon: 'none' });
    const isBackward = selectedIndex < currentIndex;
    if (isBackward) {
      this.openEditor({ kind: 'stage-back', title: '确认退回流程？', description: `将从“${currentPatient.stage}”退回至“${selectedStage}”，记录不会删除；请填写原因。`, placeholder: '退回原因（必填）', nextStage: selectedStage, confirmText: '确认退回' });
    } else {
      const nextStage = names[currentIndex + 1];
      if (!nextStage) return wx.showToast({ title: `“${selectedStage}”已是最后阶段`, icon: 'none' });
      if (nextStage === '出院') return this.discharge();
      wx.showModal({ title: `完成“${selectedStage}”？`, content: `确认后将进入“${nextStage}”；系统会先校验关键项。`, confirmText: '完成阶段', success: (result) => { if (result.confirm) this.applyStageChange(nextStage); } });
    }
  },
  applyStageChange(nextStage, note = '') {
    if (nextStage === '出院') return this.discharge();
    const result = changePatientStage(this.patientId, nextStage, note);
    if (!result.ok) {
      const detail = result.blockers && result.blockers.length ? `：${result.blockers.map((item) => item.title).join('、')}` : '';
      return wx.showModal({ title: '暂不能推进', content: `${result.error}${detail}`, showCancel: false });
    }
    this.loadPatient();
    wx.showToast({ title: `已切换至${nextStage}`, icon: 'success' });
  },
  chooseDischargeDate(e) {
    if (this.data.patient && this.data.patient.patientType === '日间') return;
    this.setData({ dischargeDateInput: e.detail.value });
  },
  discharge() {
    const patient = this.data.patient || {};
    const dischargeDate = patient.patientType === '日间' ? patient.admissionDate : this.data.dischargeDateInput;
    if (!dischargeDate) return wx.showToast({ title: '请选择出院日期', icon: 'none' });
    wx.showModal({
      title: '确认患者出院？',
      content: `将患者状态设为“出院”，出院日期为 ${dischargeDate}。${patient.patientType === '日间' ? '日间患者出院日期固定为入院日。' : ''}患者资料及待办不会删除。`,
      confirmText: '确认出院',
      success: (result) => {
        if (!result.confirm) return;
        const discharged = dischargePatient(this.patientId, dischargeDate);
        if (!discharged.ok) return wx.showToast({ title: discharged.error, icon: 'none' });
        this.loadPatient();
        wx.showToast({ title: '已标记出院', icon: 'success' });
      },
    });
  },
  revertDischarge() {
    this.openEditor({ kind: 'discharge-revert', title: '撤回出院', description: '将清除实际出院日期并恢复至术后；请填写原因。', placeholder: '撤回出院原因（必填）', confirmText: '确认撤回' });
  },
  archive() {
    wx.showModal({
      title: '归档这位患者？', content: '归档后将移出主页和在院列表，全部记录保留为只读。', confirmText: '确认归档',
      success: (result) => {
        if (!result.confirm) return;
        const archived = archivePatient(this.patientId);
        if (!archived.ok) return wx.showToast({ title: archived.error, icon: 'none' });
        wx.navigateBack();
      },
    });
  },
  revokeRegistration() {
    wx.showModal({
      title: '撤销建档？',
      content: '仅用于临时取消或误建档。患者及本地关联记录将移入回收站，可在设置中恢复。',
      confirmText: '确认撤销', confirmColor: '#c33b35',
      success: (result) => {
        if (!result.confirm) return;
        const revoked = revokePatientRegistration(this.patientId);
        if (!revoked.ok) return wx.showToast({ title: revoked.error, icon: 'none' });
        wx.navigateBack();
      },
    });
  },
});
