import assert from 'node:assert/strict';
import fs from 'node:fs';

// 六位完全脱敏的虚拟患者。每位患者只承担一类临床工作流风险，
// 共同覆盖普通、国疗和日间患者，以及建档、流程、出院、归档、撤回、
// 引流、任务、回收站和备份恢复。此用例是每次版本验收的必经门槛。
const SIX_PATIENTS = [
  ['QA-SIX-001', '普通', '整形外科', '完整围术期至归档'],
  ['QA-SIX-002', '普通', '普外科', '流程边界、退回与未归档出院'],
  ['QA-SIX-003', '国疗', '普外科', '全流程与任务生成幂等'],
  ['QA-SIX-004', '日间', '整形外科', '同日出院与误出院撤回'],
  ['QA-SIX-005', '日间', '普外科', '同日日期异常防护'],
  ['QA-SIX-006', '普通', '普外科', '撤销建档与关联记录恢复'],
];

const storage = new Map();
globalThis.wx = {
  getStorageSync: (key) => storage.get(key),
  setStorageSync: (key, value) => storage.set(key, value),
};

const sourcePath = new URL('../utils/workspace-store.js', import.meta.url);
const source = fs.readFileSync(sourcePath, 'utf8');
const store = await import(`data:text/javascript;base64,${Buffer.from(source).toString('base64')}`);

const shiftDate = (dateKey, offset) => {
  const [year, month, day] = dateKey.split('-').map(Number);
  const date = new Date(Date.UTC(year, month - 1, day + offset));
  return `${date.getUTCFullYear()}-${`${date.getUTCMonth() + 1}`.padStart(2, '0')}-${`${date.getUTCDate()}`.padStart(2, '0')}`;
};
const TODAY = store.todayKey();
const YESTERDAY = shiftDate(TODAY, -1);
const TOMORROW = shiftDate(TODAY, 1);
const taskFor = (patientId, predicate = () => true) => store.getWorkspace().tasks.find((task) => task.patientId === patientId && predicate(task));
const completeStageBlockers = (patientId) => {
  store.getStageBlockers(patientId).forEach((task) => assert.equal(store.setTaskDone(patientId, task.id, true).ok, true));
};

assert.equal(SIX_PATIENTS.length, 6);
assert.deepEqual(SIX_PATIENTS.map(([, type]) => type).sort(), ['国疗', '日间', '日间', '普通', '普通', '普通'].sort());

const admitted = store.createPatientsAtomically([
  { id: 'QA-SIX-001', name: '虚拟患者甲', bed: '101', age: '40', gender: '男', department: '整形外科', patientType: '普通', diagnosis: '脱敏诊断甲', admissionDate: YESTERDAY, surgeryDate: TODAY, plannedDischargeDate: TOMORROW, surgeryName: '脱敏术式甲', surgeon: '虚拟主刀', firstAssistant: '', stage: '术前', allergyStatus: 'none' },
  { id: 'QA-SIX-002', name: '虚拟患者乙', bed: '102', age: '41', gender: '女', department: '普外科', patientType: '普通', diagnosis: '脱敏诊断乙', admissionDate: YESTERDAY, surgeryDate: YESTERDAY, plannedDischargeDate: TODAY, surgeryName: '脱敏术式乙', surgeon: '虚拟主刀', firstAssistant: '', stage: '术前', allergyStatus: 'unknown' },
  { id: 'QA-SIX-003', name: '虚拟患者丙', bed: '103', age: '42', gender: '男', department: '普外科', patientType: '国疗', diagnosis: '脱敏诊断丙', admissionDate: YESTERDAY, surgeryDate: TODAY, plannedDischargeDate: TOMORROW, surgeryName: '脱敏术式丙', surgeon: '虚拟主刀', firstAssistant: '虚拟一助', stage: '入院', allergyStatus: 'none' },
  { id: 'QA-SIX-004', name: '虚拟患者丁', bed: '104', age: '43', gender: '女', department: '整形外科', patientType: '日间', diagnosis: '脱敏诊断丁', admissionDate: TODAY, surgeryDate: TODAY, plannedDischargeDate: TODAY, surgeryName: '脱敏术式丁', surgeon: '虚拟主刀', firstAssistant: '虚拟一助', stage: '术后', allergyStatus: 'none' },
  { id: 'QA-SIX-005', name: '虚拟患者戊', bed: '105', age: '44', gender: '男', department: '普外科', patientType: '日间', diagnosis: '脱敏诊断戊', admissionDate: TODAY, surgeryDate: TODAY, plannedDischargeDate: TODAY, surgeryName: '脱敏术式戊', surgeon: '虚拟主刀', firstAssistant: '', stage: '术后', allergyStatus: 'none' },
  { id: 'QA-SIX-006', name: '虚拟患者己', bed: '106', age: '45', gender: '女', department: '普外科', patientType: '普通', diagnosis: '脱敏诊断己', admissionDate: YESTERDAY, surgeryDate: TODAY, plannedDischargeDate: TOMORROW, surgeryName: '脱敏术式己', surgeon: '虚拟主刀', firstAssistant: '', stage: '术后', allergyStatus: 'none' },
]);
assert.equal(admitted.ok, true);
assert.equal(store.getWorkspace().patients.length, 6);
assert.equal(store.getWorkspaceIntegrity().ok, true);

// 001：普通患者，术前关键项、术中一助、引流、出院通知和归档完整链路。
assert.equal(store.changePatientStage('QA-SIX-001', '手术').ok, false);
assert.equal(store.updatePatient('QA-SIX-001', { confirmedSurgeryName: '脱敏正式术式甲' }).ok, true);
completeStageBlockers('QA-SIX-001');
assert.equal(store.changePatientStage('QA-SIX-001', '手术').ok, true);
const missingAssistant = store.changePatientStage('QA-SIX-001', '术后');
assert.equal(missingAssistant.ok, false);
assert.equal(missingAssistant.blockers.some((item) => item.title === '填写术中一助医生'), true);
assert.equal(store.updatePatient('QA-SIX-001', { firstAssistant: '虚拟一助' }).ok, true);
assert.equal(store.changePatientStage('QA-SIX-001', '术后').ok, true);
assert.equal(store.addDrain('QA-SIX-001', '脱敏引流管').ok, true);
const drain = store.getWorkspace().devices.find((item) => item.patientId === 'QA-SIX-001');
assert.equal(store.ensureDrainRowCount('QA-SIX-001', 2).ok, true);
assert.equal(store.recordDrainVolume('QA-SIX-001', drain.id, '36.5', 1).ok, true);
assert.equal(store.recordDrainVolume('QA-SIX-001', drain.id, '拔', 2).ok, true);
assert.equal(store.recordDrainVolume('QA-SIX-001', drain.id, '8', 3).ok, false);
assert.equal(store.saveRound('QA-SIX-001', { date: TODAY, assessment: '脱敏查房评估', plan: '脱敏处理计划' }).ok, true);
assert.equal(store.saveRound('QA-SIX-001', { date: TODAY, assessment: '脱敏查房评估（更正）', plan: '脱敏处理计划（更正）' }).ok, true);
assert.equal(store.getWorkspace().rounds.filter((item) => item.patientId === 'QA-SIX-001' && item.date === TODAY).length, 1);
assert.equal(store.getWorkspace().rounds.find((item) => item.patientId === 'QA-SIX-001' && item.date === TODAY).assessment, '脱敏查房评估（更正）');
assert.equal(store.dischargePatient('QA-SIX-001', TODAY).ok, true);
assert.equal(store.getActiveTasks().some((task) => task.patientId === 'QA-SIX-001'), false);
assert.equal(store.archivePatient('QA-SIX-001').ok, false);
const dischargeTask001 = taskFor('QA-SIX-001', (task) => task.stage === '出院' && task.critical);
assert.equal(store.setTaskDone('QA-SIX-001', dischargeTask001.id, true).ok, true);
assert.equal(store.addClinicalEvent('QA-SIX-001', 'cooperation-discharge-notice', '已通知虚拟一助').ok, true);
assert.equal(store.archivePatient('QA-SIX-001').ok, true);
assert.equal(store.getWorkspace().archivedPatients.some((patient) => patient.id === 'QA-SIX-001'), true);
assert.equal(store.revokePatientRegistration('QA-SIX-001').ok, false);

// 002：普通患者，限制跳级／无原因退回，并验证已出院但未归档的状态。
assert.equal(store.changePatientStage('QA-SIX-002', '出院').error, '请通过“确认出院”录入实际出院日期');
assert.equal(store.changePatientStage('QA-SIX-002', '手术').ok, false);
completeStageBlockers('QA-SIX-002');
assert.equal(store.changePatientStage('QA-SIX-002', '手术').ok, true);
assert.equal(store.updatePatient('QA-SIX-002', { firstAssistant: '虚拟一助' }).ok, true);
assert.equal(store.changePatientStage('QA-SIX-002', '术后').ok, true);
assert.equal(store.changePatientStage('QA-SIX-002', '手术').error, '请填写退回原因');
assert.equal(store.changePatientStage('QA-SIX-002', '手术', '需补术中记录').ok, true);
assert.equal(store.changePatientStage('QA-SIX-002', '术后').ok, true);
assert.equal(store.dischargePatient('QA-SIX-002', TODAY).ok, true);
assert.equal(store.getPatientStatus(store.getPatient('QA-SIX-002')), '出院');
assert.equal(store.getActiveTasks().some((task) => task.patientId === 'QA-SIX-002'), false);
assert.equal(store.getDischargeReadiness(store.getPatient('QA-SIX-002')).readyToArchive, false);

// 003：国疗患者，走通通用流程并确保相同来源任务不会重复生成。
assert.equal(store.changePatientStage('QA-SIX-003', '检查').ok, true);
assert.equal(store.changePatientStage('QA-SIX-003', '谈话').ok, true);
assert.equal(store.changePatientStage('QA-SIX-003', '术前').ok, false);
completeStageBlockers('QA-SIX-003');
assert.equal(store.changePatientStage('QA-SIX-003', '术前').ok, true);
completeStageBlockers('QA-SIX-003');
assert.equal(store.changePatientStage('QA-SIX-003', '手术').ok, true);
assert.equal(store.changePatientStage('QA-SIX-003', '术后').ok, true);
assert.equal(store.addTask('QA-SIX-003', { title: '国疗脱敏待办', sourceRef: 'qa:national:unique' }).ok, true);
assert.equal(store.addTask('QA-SIX-003', { title: '国疗脱敏待办', sourceRef: 'qa:national:unique' }).ok, false);
assert.equal(store.addTasksFromDrafts('QA-SIX-003', [{ title: '国疗查房任务', sourceRef: 'qa:national:draft' }], 'qa:national').every((result) => result.ok), true);
assert.equal(store.addTasksFromDrafts('QA-SIX-003', [{ title: '国疗查房任务', sourceRef: 'qa:national:draft' }], 'qa:national').every((result) => !result.ok), true);

// 004：日间患者只能同日出院；误出院需有原因才能撤回并可再次确认。
const dayPatient004 = store.getPatient('QA-SIX-004');
assert.deepEqual([dayPatient004.admissionDate, dayPatient004.surgeryDate, dayPatient004.plannedDischargeDate], [TODAY, TODAY, TODAY]);
assert.equal(store.dischargePatient('QA-SIX-004', TOMORROW).ok, false);
assert.equal(store.dischargePatient('QA-SIX-004', TODAY).ok, true);
assert.equal(store.revertPatientDischarge('QA-SIX-004', '').ok, false);
assert.equal(store.revertPatientDischarge('QA-SIX-004', '误点确认').ok, true);
assert.equal(store.getPatient('QA-SIX-004').stage, '术后');
assert.equal(store.dischargePatient('QA-SIX-004', TODAY).ok, true);

// 005：日间患者的任一日期不一致都必须被数据层拒绝，原记录不被改写。
assert.equal(store.updatePatient('QA-SIX-005', { surgeryDate: TOMORROW, plannedDischargeDate: TOMORROW }).error, '日间手术患者的入院日期与手术日期必须为同一天');
assert.equal(store.updatePatient('QA-SIX-005', { plannedDischargeDate: TOMORROW }).error, '日间患者的计划出院日期必须与入院日期同一天');
assert.equal(store.updatePatient('QA-SIX-005', { actualDischargeDate: TOMORROW }).error, '实际出院日期不能晚于今天');
assert.deepEqual([store.getPatient('QA-SIX-005').admissionDate, store.getPatient('QA-SIX-005').surgeryDate, store.getPatient('QA-SIX-005').plannedDischargeDate], [TODAY, TODAY, TODAY]);

// 006：撤销建档必须带走全部关联记录，恢复后必须完整回到工作区。
assert.equal(store.addTask('QA-SIX-006', '撤销建档关联待办').ok, true);
assert.equal(store.saveRound('QA-SIX-006', { date: TODAY, assessment: '撤销建档查房', plan: '仅测试恢复关联' }).ok, true);
assert.equal(store.addDrain('QA-SIX-006', '撤销建档引流').ok, true);
const drain006 = store.getWorkspace().devices.find((item) => item.patientId === 'QA-SIX-006');
assert.equal(store.recordDrainVolume('QA-SIX-006', drain006.id, '12', 1).ok, true);
assert.equal(store.revokePatientRegistration('QA-SIX-006').ok, true);
assert.equal(store.getWorkspace().patients.some((patient) => patient.id === 'QA-SIX-006'), false);
const revoked006 = store.getRevokedRegistrations().find((entry) => entry.patient.id === 'QA-SIX-006');
assert.equal(Boolean(revoked006), true);
assert.equal(revoked006.records.tasks.some((task) => task.title === '撤销建档关联待办'), true);
assert.equal(revoked006.records.rounds.length, 1);
assert.equal(revoked006.records.devices.length, 1);
assert.equal(revoked006.records.observations.length, 1);
assert.equal(store.getWorkspaceIntegrity().ok, true);
assert.equal(store.restoreRevokedRegistration(revoked006.id).ok, true);
assert.equal(store.getPatientBundle('QA-SIX-006').observations.length, 1);

// 备份导入、恢复前快照与回退必须不丢失六位患者工作区的关联记录。
const backup = structuredClone(store.getWorkspace());
const prepared = store.prepareBackupImport(backup);
assert.equal(prepared.integrity.ok, true);
assert.equal(prepared.workspace.patients.length, backup.patients.length);
assert.equal(store.recordBackupVerification('export', store.getBackupSummary(backup)).kind, 'export');
assert.equal(store.addTask('QA-SIX-003', '恢复前快照标记').ok, true);
assert.equal(store.restoreWorkspace(backup).tasks.some((task) => task.title === '恢复前快照标记'), false);
assert.equal(store.getRestoreSnapshotSummary().activePatients, backup.patients.length);
assert.equal(store.restorePreviousWorkspace().ok, true);
assert.equal(store.getWorkspace().tasks.some((task) => task.title === '恢复前快照标记'), true);
assert.equal(store.getWorkspaceIntegrity().ok, true);

console.log('six-patient de-identified clinical flow, recovery, and safety gate: passed');
