import { addReminderAsTask, getActiveTasks, getPatient, getPatientReminders, getWorkspace, getPOD, maskPatient, setActiveDepartment, setTaskDone, taskBucket, todayKey, updatePatient } from '../../utils/workspace-store';

function todayLabel() {
  const now = new Date(Date.now() + 8 * 60 * 60000);
  const weekdays = ['周日', '周一', '周二', '周三', '周四', '周五', '周六'];
  return `${now.getUTCMonth() + 1}月${now.getUTCDate()}日 · ${weekdays[now.getUTCDay()]}`;
}

const stageTones = ['blue', 'cyan', 'purple', 'orange', 'orange', 'green', 'slate', 'gray'];
const SURGERY_NAME_CONFIRM_TASK = '与主刀确认手术名称，并核实手术同意书名称';

function isSameDayDayPatient(patient) {
  return patient.patientType === '日间' && patient.admissionDate && patient.admissionDate === patient.dischargeDate;
}

function inHospitalList(patient) {
  return patient.careStatus !== '出院' || isSameDayDayPatient(patient);
}

function clinicalAlertFlags(patient, date, listType) {
  if (listType === 'discharged' || patient.careStatus === '出院') return { flags: [], highlightClass: '' };
  const flags = [];
  if (patient.surgeryDate === date) flags.push({ key: 'surgery', label: '今日手术', tone: 'surgery' });
  if (patient.dischargeDate === date) flags.push({ key: 'discharge', label: '今日出院', tone: 'discharge' });
  if (patient.admissionDate === date) flags.push({ key: 'admission', label: '新入院', tone: 'admission' });
  const highlightClass = flags.some((item) => item.key === 'surgery') ? 'highlight-surgery' : flags.some((item) => item.key === 'discharge') ? 'highlight-discharge' : flags.some((item) => item.key === 'admission') ? 'highlight-admission' : '';
  return { flags, highlightClass };
}

function nextDayKey(dateKey) {
  const [year, month, day] = dateKey.split('-').map(Number);
  const date = new Date(Date.UTC(year, month - 1, day + 1));
  return `${date.getUTCFullYear()}-${`${date.getUTCMonth() + 1}`.padStart(2, '0')}-${`${date.getUTCDate()}`.padStart(2, '0')}`;
}

function isRadiotherapyCandidate(diagnosis) {
  return /瘢痕疙瘩|瘢痕瘤|keloid/i.test(diagnosis || '');
}

function photoText(patient) {
  return `${patient.name} ${patient.age}/${patient.gender}，${patient.id}，${patient.diagnosis}，拟于${patient.surgeryDate}行${patient.surgeryName}。${patient.surgeon}/代寰宇`;
}

function radiotherapyText(patient) {
  return `${patient.name}，${patient.gender}，${patient.id}，${patient.diagnosis}，拟于${patient.surgeryDate}手术切除`;
}

function pptText(patient) {
  const shortName = `${patient.name || ''}`.trim().slice(0, 1);
  const gender = patient.gender === '女' ? 'F' : patient.gender === '男' ? 'M' : patient.gender;
  return `${shortName}*，${patient.age}/${gender}，诊断：${patient.diagnosis}\n拟行：${patient.confirmedSurgeryName}`;
}

function collectTodayCooperation(workspace, department, type, date) {
  const tomorrow = nextDayKey(date);
  const required = type === 'photo' ? ['name', 'age', 'gender', 'id', 'diagnosis', 'surgeryName', 'surgeon'] : type === 'ppt' ? ['name', 'age', 'gender', 'diagnosis', 'confirmedSurgeryName', 'surgeryNameConfirmedAt'] : ['name', 'gender', 'id', 'diagnosis', 'surgeryDate'];
  const candidates = workspace.patients.filter((patient) => patient.department === department && inHospitalList(maskPatient(patient)) && patient.surgeryDate === tomorrow && (type !== 'radiotherapy' || isRadiotherapyCandidate(patient.diagnosis)));
  const ready = candidates.filter((patient) => required.every((field) => `${patient[field] || ''}`.trim()));
  const missing = candidates.filter((patient) => !ready.includes(patient)).map((patient) => `${patient.bed || '?'}床 ${patient.name || '未命名'}`);
  const heading = type === 'photo' ? '老师好，申请明日手术患者拍照：' : type === 'ppt' ? '明日手术 PPT 患者信息：' : '老师您好，以下患者申请术后放疗：';
  const lines = ready.map((patient, index) => `${index + 1}. ${type === 'photo' ? photoText(patient) : type === 'ppt' ? pptText(patient) : radiotherapyText(patient)}`);
  return { candidateCount: candidates.length, readyCount: ready.length, missing, text: lines.length ? `${heading}\n${lines.join('\n')}` : '' };
}

function overviewPatient(patient, workspace, privacyVisible, date, listType) {
  const masked = maskPatient(patient);
  const pod = getPOD(patient.surgeryDate);
  const tasks = workspace.tasks.filter((task) => task.patientId === patient.id && task.status !== 'done').sort((a, b) => `${a.dueAt}`.localeCompare(`${b.dueAt}`));
  const alerts = clinicalAlertFlags(masked, date, listType);
  return {
    ...masked,
    displayName: privacyVisible ? patient.name : masked.displayName,
    displayId: privacyVisible ? patient.id : masked.displayId,
    podText: pod === null ? '' : pod < 0 ? `术前 ${Math.abs(pod)} 天` : `POD ${pod}`,
    nextTask: tasks[0] ? tasks[0].title : '暂无未完成待办',
    alertFlags: alerts.flags,
    highlightClass: alerts.highlightClass,
  };
}

Page({
  data: {
    today: '', activeStage: '全部', privacyVisible: true,
    stages: [], totalPatients: 0, dischargedCount: 0, taskGroups: [], patientSummary: [], dischargedPatients: [], reminders: [], departments: [], departmentIndex: 0, activeDepartment: '',
    overview: { urgent: 0, overdue: 0, today: 0, upcoming: 0 }, todayPhotoCount: 0, todayPptCount: 0, todayRadiotherapyCount: 0,
    surgeryNameEditor: { visible: false, patientId: '', taskId: '', content: '', focus: false }, editorKeyboardHeight: 0,
  },
  onShow() {
    this.setData({ privacyVisible: true });
    this.loadDashboard();
  },
  onHide() { this.setData({ privacyVisible: true }); },
  loadDashboard() {
    const workspace = getWorkspace();
    const date = todayKey();
    const activeDepartment = workspace.settings.activeDepartment;
    const departmentPatients = workspace.patients.filter((patient) => patient.department === activeDepartment);
    const activePatients = departmentPatients.filter((patient) => inHospitalList(maskPatient(patient)));
    const dischargedPatients = departmentPatients.filter((patient) => !inHospitalList(maskPatient(patient)));
    const patientMap = {};
    departmentPatients.forEach((patient) => { patientMap[patient.id] = patient; });
    const flow = workspace.settings.departmentWorkflows[activeDepartment];
    const stageNames = flow && flow.length ? flow.map((step) => step.name) : workspace.settings.stages;
    const stages = stageNames.map((name, index) => ({
      name, short: name.slice(0, 1), count: activePatients.filter((patient) => patient.stage === name).length,
      tone: stageTones[index % stageTones.length],
    }));
    const selectedPatients = activePatients;
    const patientSummary = selectedPatients.map((patient) => overviewPatient(patient, workspace, this.data.privacyVisible, date, 'active'));
    const dischargedSummary = dischargedPatients.map((patient) => overviewPatient(patient, workspace, this.data.privacyVisible, date, 'discharged'));
    let tasks = getActiveTasks().filter((task) => patientMap[task.patientId]);
    if (this.data.activeStage !== '全部') tasks = tasks.filter((task) => patientMap[task.patientId] && patientMap[task.patientId].stage === this.data.activeStage);
    const decoratedTasks = tasks.map((task) => {
      const patient = patientMap[task.patientId];
      const masked = maskPatient(patient);
      const bucket = taskBucket(task, date);
      return {
        ...task, bucket, done: task.status === 'done',
        patientName: this.data.privacyVisible ? patient.name : masked.displayName,
        patientCode: this.data.privacyVisible ? patient.id : masked.displayId,
        bed: patient.bed, stage: patient.stage,
        level: task.priority === '重要' ? '重要' : task.category,
        levelClass: task.priority === '重要' ? 'danger' : bucket === 'overdue' ? 'warning' : 'normal',
        dueText: bucket === 'overdue' ? `已逾期 · ${task.dueAt.slice(0, 10)}` : bucket === 'today' ? '今日' : task.dueAt.slice(0, 10),
      };
    }).sort((a, b) => `${a.dueAt}${a.priority === '重要' ? '0' : '1'}`.localeCompare(`${b.dueAt}${b.priority === '重要' ? '0' : '1'}`));
    const groupDefinitions = [
      { key: 'overdue', title: '已逾期', tone: 'overdue' },
      { key: 'today', title: '今日处理', tone: 'today' },
      { key: 'upcoming', title: '即将到期', tone: 'upcoming' },
    ];
    const taskGroups = groupDefinitions.map((group) => ({ ...group, tasks: decoratedTasks.filter((task) => task.bucket === group.key) }));
    const reminders = selectedPatients.flatMap((patient) => getPatientReminders(patient).map((reminder) => {
      const masked = maskPatient(patient);
      return {
        ...reminder, id: `${patient.id}:${reminder.id}`, patientId: patient.id, bed: patient.bed,
        patientName: this.data.privacyVisible ? patient.name : masked.displayName,
        alreadyAdded: workspace.tasks.some((task) => task.patientId === patient.id && task.sourceRef === reminder.sourceRef),
      };
    })).slice(0, 8);
    const allTasks = getActiveTasks().filter((task) => patientMap[task.patientId]);
    const overview = {
      urgent: allTasks.filter((task) => task.priority === '重要').length,
      overdue: allTasks.filter((task) => taskBucket(task, date) === 'overdue').length,
      today: allTasks.filter((task) => taskBucket(task, date) === 'today').length,
      upcoming: allTasks.filter((task) => taskBucket(task, date) === 'upcoming').length,
    };
    const photo = collectTodayCooperation(workspace, activeDepartment, 'photo', date);
    const ppt = collectTodayCooperation(workspace, activeDepartment, 'ppt', date);
    const radiotherapy = collectTodayCooperation(workspace, activeDepartment, 'radiotherapy', date);
    this.setData({ today: todayLabel(), stages, totalPatients: activePatients.length, dischargedCount: dischargedPatients.length, taskGroups, patientSummary, dischargedPatients: dischargedSummary, reminders, overview, todayPhotoCount: photo.readyCount, todayPptCount: ppt.readyCount, todayRadiotherapyCount: radiotherapy.readyCount, departments: workspace.settings.departments, departmentIndex: Math.max(0, workspace.settings.departments.indexOf(activeDepartment)), activeDepartment });
  },
  selectStage(e) { this.setData({ activeStage: e.currentTarget.dataset.name }, () => this.loadDashboard()); },
  chooseDepartment(e) {
    const department = this.data.departments[Number(e.detail.value)];
    if (department && setActiveDepartment(department)) this.setData({ activeStage: '全部' }, () => this.loadDashboard());
  },
  togglePrivacy() { this.setData({ privacyVisible: !this.data.privacyVisible }, () => this.loadDashboard()); },
  previewTodayCooperation(e) {
    const type = e.currentTarget.dataset.type;
    if (!['photo', 'ppt', 'radiotherapy'].includes(type)) return;
    const workspace = getWorkspace();
    const result = collectTodayCooperation(workspace, workspace.settings.activeDepartment, type, todayKey());
    if (!result.candidateCount) return wx.showToast({ title: type === 'photo' ? '暂无明日手术需拍照患者' : type === 'ppt' ? '暂无明日手术 PPT 患者' : '暂无明日手术需放疗患者', icon: 'none' });
    if (!result.text) return wx.showModal({ title: '暂不能生成文本', content: `请先补全以下患者资料：${result.missing.join('、')}`, showCancel: false });
    const incompleteNote = result.missing.length ? `\n\n以下 ${result.missing.length} 位资料不全，未纳入：${result.missing.join('、')}` : '';
    wx.showModal({
      title: type === 'photo' ? `核对拍照文本（${result.readyCount} 位）` : type === 'ppt' ? `核对 PPT 文本（${result.readyCount} 位）` : `核对放疗文本（${result.readyCount} 位）`, content: `${result.text}${incompleteNote}`, confirmText: '确认复制',
      success: (modal) => { if (modal.confirm) wx.setClipboardData({ data: result.text, success: () => wx.showToast({ title: '文本已复制，请自行核对后发送', icon: 'none', duration: 2400 }) }); },
    });
  },
  completeTask(e) {
    const patientId = e.currentTarget.dataset.patientId;
    const taskId = e.currentTarget.dataset.id;
    const task = getWorkspace().tasks.find((item) => item.id === taskId && item.patientId === patientId);
    if (task && task.title === SURGERY_NAME_CONFIRM_TASK) {
      const patient = getPatient(patientId);
      return this.setData({ surgeryNameEditor: { visible: true, patientId, taskId, content: (patient && (patient.confirmedSurgeryName || patient.surgeryName)) || '', focus: false }, editorKeyboardHeight: 0 }, () => this.setData({ 'surgeryNameEditor.focus': true }));
    }
    const result = setTaskDone(patientId, taskId, true);
    if (result.ok) {
      wx.showToast({ title: '已完成', icon: 'success' });
      this.loadDashboard();
    } else wx.showToast({ title: result.error, icon: 'none', duration: 2400 });
  },
  inputSurgeryNameEditor(e) { this.setData({ 'surgeryNameEditor.content': e.detail.value }); },
  editorFocus(e) { this.setData({ editorKeyboardHeight: Math.max(0, Number(e.detail.height) || 0) }); },
  editorBlur() { this.setData({ editorKeyboardHeight: 0 }); },
  closeSurgeryNameEditor() { this.setData({ surgeryNameEditor: { visible: false, patientId: '', taskId: '', content: '', focus: false }, editorKeyboardHeight: 0 }); },
  keepEditorOpen() {},
  saveSurgeryNameEditor() {
    const editor = this.data.surgeryNameEditor;
    const confirmedSurgeryName = `${editor.content || ''}`.trim();
    if (!confirmedSurgeryName) return wx.showToast({ title: '请填写正式手术名称', icon: 'none' });
    const saved = updatePatient(editor.patientId, { confirmedSurgeryName });
    if (!saved.ok) return wx.showToast({ title: saved.error || '保存失败', icon: 'none' });
    const result = setTaskDone(editor.patientId, editor.taskId, true);
    if (!result.ok) return wx.showToast({ title: result.error, icon: 'none', duration: 2400 });
    this.closeSurgeryNameEditor();
    wx.showToast({ title: '正式术式已确认', icon: 'success' });
    this.loadDashboard();
  },
  addHomeReminder(e) {
    const reminder = this.data.reminders.find((item) => item.id === e.currentTarget.dataset.id);
    if (!reminder || reminder.alreadyAdded) return;
    const result = addReminderAsTask(reminder.patientId, reminder);
    wx.showToast({ title: result.ok ? '已直接加入待办' : result.error, icon: result.ok ? 'success' : 'none', duration: 2200 });
    if (result.ok) this.loadDashboard();
  },
  goPatients() { wx.navigateTo({ url: '/pages/patients/patients' }); },
  goTemplates() { wx.navigateTo({ url: '/pages/templates/templates' }); },
  goPatient(e) { wx.navigateTo({ url: `/pages/patient-detail/patient-detail?id=${encodeURIComponent(e.currentTarget.dataset.id)}` }); },
  goRounds() { wx.navigateTo({ url: '/pages/rounds/rounds' }); },
  goSettings() { wx.navigateTo({ url: '/pages/settings' }); },
});
