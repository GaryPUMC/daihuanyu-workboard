import assert from 'node:assert/strict';
import fs from 'node:fs';
import { createV3ImportDemo } from './fixtures/v3-import-demo.mjs';

const storage = new Map();
globalThis.wx = {
  getStorageSync: (key) => storage.get(key),
  setStorageSync: (key, value) => storage.set(key, value),
};

const sourcePath = new URL('../utils/workspace-store.js', import.meta.url);
const source = fs.readFileSync(sourcePath, 'utf8');
const store = await import(`data:text/javascript;base64,${Buffer.from(source).toString('base64')}`);
const sourceWorkspace = createV3ImportDemo();
const imported = store.prepareBackupImport(sourceWorkspace);

assert.equal(imported.sourceSchemaVersion, 3);
assert.equal(imported.targetSchemaVersion, 4);
assert.equal(imported.migrated, true);
assert.equal(imported.workspace.patients.length, 10);
assert.equal(imported.workspace.tasks.length >= 58, true);
assert.equal(imported.workspace.devices.length, 9);
assert.equal(imported.workspace.observations.length, 3);
assert.equal(imported.workspace.clinicalEvents.length, 11);
assert.equal(imported.workspace.pathologySpecimens.length, 4);
assert.equal(imported.workspace.patients[0].id, 'DEMO-V3-001');
assert.equal(imported.workspace.patients[0].allergies, '');

const dischargeTarget = imported.workspace.patients[0];
dischargeTarget.stage = '术后';
dischargeTarget.dischargeDate = '';
storage.set('daihuanyu_workboard_local_v3', structuredClone(imported.workspace));
const discharged = store.dischargePatient(dischargeTarget.id);
const dischargedWorkspace = store.getWorkspace();
const dischargedPatient = dischargedWorkspace.patients.find((item) => item.id === dischargeTarget.id);
assert.equal(discharged.ok, true);
assert.equal(dischargedPatient.stage, '出院');
assert.equal(dischargedPatient.dischargeDate, store.todayKey());
assert.equal(store.getPatientStatus(dischargedPatient), '出院');
assert.equal(dischargedWorkspace.stageLogs[0].action, 'discharge');

const invalidDischargeWorkspace = structuredClone(imported.workspace);
invalidDischargeWorkspace.patients[1].admissionDate = '2999-12-31';
storage.set('daihuanyu_workboard_local_v3', invalidDischargeWorkspace);
const invalidDischarge = store.dischargePatient(invalidDischargeWorkspace.patients[1].id);
assert.equal(invalidDischarge.ok, false);
assert.equal(invalidDischarge.error, '入院日期不能晚于手术日期');

const invalidBackup = structuredClone(sourceWorkspace);
invalidBackup.patients[0].admissionDate = '2026-02-31';
assert.throws(() => store.prepareBackupImport(invalidBackup), /备份中存在无效日期/);

const scheduledWorkspace = structuredClone(imported.workspace);
scheduledWorkspace.patients[1].stage = '术后';
scheduledWorkspace.patients[1].dischargeDate = store.todayKey();
scheduledWorkspace.patients[2].stage = '术后';
scheduledWorkspace.patients[2].dischargeDate = '2999-12-31';
storage.set('daihuanyu_workboard_local_v3', scheduledWorkspace);
const scheduled = store.getWorkspace();
assert.equal(scheduled.patients[1].stage, '术后');
assert.equal(scheduled.patients[2].stage, '术后');
assert.equal(store.getPatientStatus(scheduled.patients[1]), '术后');

const reversedDates = store.createPatient({ id: 'validation-1', admissionDate: '2026-08-08', surgeryDate: '2026-08-07' });
assert.equal(reversedDates.ok, false);
assert.equal(reversedDates.error, '入院日期不能晚于手术日期');

const correctionTarget = scheduled.patients[0];
assert.equal(store.updatePatient(correctionTarget.id, { diagnosis: '更正后的诊断' }).ok, false);
assert.equal(store.updatePatient(correctionTarget.id, { diagnosis: '更正后的诊断', correctionReason: '首次录入有误' }).ok, true);
assert.equal(store.getWorkspace().clinicalEvents.some((item) => item.patientId === correctionTarget.id && item.type === 'patient-correction' && item.note === '首次录入有误'), true);

const cancellationId = scheduled.patients[2].id;
assert.equal(store.revokePatientRegistration(cancellationId).ok, true);
assert.equal(store.getWorkspace().patients.some((patient) => patient.id === cancellationId), false);

console.log('v3 de-identified import demo, manual discharge, reminder, validation, and cancellation: passed');
