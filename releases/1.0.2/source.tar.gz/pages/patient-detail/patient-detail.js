import {
  addClinicalEvent, addDrain, addPathologySpecimen, addReminderAsTask, addSettingItem, addTask, archivePatient, changePatientStage, ensureStageTasks,
  getPatient, getPatientBundle, getPatientFlow, getPatientReminders, getPOD, getWorkspace, isIntraoperativeOrLater, isPostoperative, maskPatient,
  recordDrainVolume, setDrainStatus, setIntraopStatus, setPathologyStatus, setPostopStatus, setTaskDone, todayKey, updatePatient,
} from '../../utils/workspace-store';

const POSTOP_OPTIONS = {
  urinaryCatheter: [{ value: 'unknown', label: '未确认' }, { value: 'present', label: '留置中' }, { value: 'removed', label: '已拔除' }, { value: 'none', label: '未留置' }],
  monitoring: [{ value: 'unknown', label: '未确认' }, { value: 'active', label: '监护中' }, { value: 'stopped', label: '已停止' }, { value: 'none', label: '未使用' }],
  oxygen: [{ value: 'unknown', label: '未确认' }, { value: 'active', label: '吸氧中' }, { value: 'stopped', label: '已停止' }, { value: 'none', label: '未使用' }],
  antibiotic: [{ value: 'unknown', label: '未确认' }, { value: 'active', label: '使用中' }, { value: 'stopped', label: '已停用' }, { value: 'none', label: '未使用' }],
};

const INTRAOP_OPTIONS = [{ value: 'unknown', label: '未确认' }, { value: 'none', label: '无' }, { value: 'present', label: '有' }];
const CUSTOM_PROCEDURE_OPTION = '＋ 自定义新术式';
const SURGERY_NAME_CONFIRM_TASK = '与主刀确认手术名称，并核实手术同意书名称';
const EVENT_LABELS = { urinaryCatheter: '尿管', antibiotic: '抗生素', 'antibiotic-note': '抗生素调整', 'drain-status': '引流' };
const VALUE_LABELS = { unknown: '未确认', present: '留置中', removed: '已拔除', none: '未使用', active: '使用中', stopped: '已停用' };

function missingFields(patient, fields) {
  return fields.filter((field) => !`${patient[field] || ''}`.trim());
}

function appointmentText(patient, type) {
  const surgeryName = patient.confirmedSurgeryName || patient.surgeryName;
  if (type === 'photo') {
    return `老师好，申请今日拍照\n${patient.name} ${patient.age}/${patient.gender}，${patient.id}，${patient.diagnosis}，拟明日行${surgeryName}。${patient.surgeon}/代寰宇`;
  }
  if (type === 'surgery-summary') {
    const shortName = `${patient.name || ''}`.trim().slice(0, 1);
    const gender = patient.gender === '女' ? 'F' : patient.gender === '男' ? 'M' : patient.gender;
    return `${shortName}*，${patient.age}/${gender}，诊断：${patient.diagnosis}\n拟行：${surgeryName}`;
  }
  return `老师您好，${patient.name}，${patient.gender}，${patient.id}，${patient.diagnosis}，拟明日手术切除，申请术后放疗`;
}

function appointmentTitle(type) {
  if (type === 'surgery-summary') return '核对 PPT 患者信息模板';
  return type === 'photo' ? '核对拍照预约文本' : '核对放疗预约文本';
}

function isRadiotherapyCandidate(diagnosis) {
  return /瘢痕疙瘩|瘢痕瘤|keloid/i.test(diagnosis || '');
}

function completeAppointmentTask(patientId, type) {
  if (!['photo', 'radiotherapy'].includes(type)) return false;
  const title = type === 'photo' ? '完成术前拍照' : '完成放疗科会诊';
  const task = getWorkspace().tasks.find((item) => item.patientId === patientId && item.stage === '术前' && item.title === title);
  if (!task || task.status === 'done') return false;
  return setTaskDone(patientId, task.id, true).ok;
}

Page({
  data: { patient: null, privacyVisible: false, newTask: '', taskCategories: [], taskCategoryIndex: 0, flow: [], reminders: [], archived: false, intraoperative: false, postoperative: false, drains: [], statusControls: [], intraopControls: [], specimens: [], clinicalEvents: [], appointmentTypes: [], editing: false, editForm: {}, departments: [], departmentIndex: 0, procedures: [], procedureOptions: [], procedureIndex: 0, customProcedureMode: false, customProcedure: '', addCustomProcedureToLibrary: false, conditionOptions: [], editConditions: [], genders: ['男', '女'], patientTypes: ['普通', '国疗', '日间'], editor: { visible: false, title: '', description: '', placeholder: '', content: '', kind: '', taskId: '', drainId: '', nextStage: '', focus: false }, editorKeyboardHeight: 0 },
  onLoad(options) { this.patientId = decodeURIComponent(options.id || ''); },
  onShow() {
    this.setData({ privacyVisible: false });
    ensureStageTasks(this.patientId);
    this.loadPatient();
  },
  onHide() { this.setData({ privacyVisible: false }); },
  loadPatient() {
    const original = getPatientBundle(this.patientId);
    const workspace = getWorkspace();
    if (!original) return wx.showToast({ title: '未找到患者', icon: 'none' });
    const masked = maskPatient(original);
    const displayPatient = this.data.privacyVisible ? { ...masked, displayName: original.name, displayId: original.id } : masked;
    const patientFlow = getPatientFlow(original);
    const current = patientFlow.findIndex((item) => item.name === original.stage);
    const flow = patientFlow.map((step, index) => {
      const pendingCritical = original.tasks.filter((task) => task.stage === step.name && task.critical && task.status !== 'done').length;
      return { name: step.name, pendingCritical, state: index < current ? 'done' : index === current ? 'current' : 'pending' };
    });
    const pod = getPOD(original.surgeryDate);
    const reminders = original.archived ? [] : getPatientReminders(original).map((item) => ({
      ...item,
      alreadyAdded: original.tasks.some((task) => task.sourceRef === item.sourceRef),
    }));
    const rounds = original.rounds.map((round) => ({ ...round, timeText: `${round.createdAt || ''}`.slice(11, 16) }));
    const tasks = original.tasks.map((task) => ({
      ...task, done: task.status === 'done', dueText: task.dueAt ? task.dueAt.slice(0, 10) : '未设置',
      priorityClass: task.priority === '重要' ? 'important' : '', requiresSurgeryNameConfirm: task.title === SURGERY_NAME_CONFIRM_TASK,
    }));
    const stageLogs = (original.stageLogs || []).slice(0, 8).map((log) => ({ ...log, timeText: `${log.at || ''}`.replace('T', ' ').slice(0, 16) }));
    const intraoperative = isIntraoperativeOrLater(original);
    const postoperative = isPostoperative(original);
    const drains = (original.devices || []).filter((device) => device.type === 'drain').map((device) => {
      const observations = (original.observations || []).filter((item) => item.deviceId === device.id).sort((a, b) => a.recordedAt.localeCompare(b.recordedAt));
      const latest = observations[observations.length - 1];
      const previous = observations[observations.length - 2];
      const recent = observations.slice(-7);
      const max = Math.max(1, ...recent.map((item) => item.value));
      const trend = recent.map((item) => ({ ...item, label: item.recordedAt.slice(5, 10), height: Math.max(12, Math.round(item.value / max * 100)) }));
      const delta = latest && previous ? latest.value - previous.value : null;
      return { ...device, observations, trend, latestValue: latest ? latest.value : '', changeText: delta === null ? '暂无趋势' : delta > 0 ? `↑ ${delta} mL` : delta < 0 ? `↓ ${Math.abs(delta)} mL` : '→ 无变化' };
    });
    const statusControls = [{ key: 'urinaryCatheter', label: '尿管' }, { key: 'antibiotic', label: '抗生素' }]
      .map((control) => ({ ...control, options: POSTOP_OPTIONS[control.key].map((option) => ({ ...option, selected: original.postopStatus && original.postopStatus[control.key] === option.value })) }));
    const intraopControls = [{ key: 'assistant', label: '术中一助' }, { key: 'drain', label: '术中引流' }, { key: 'urinaryCatheter', label: '术中尿管' }, { key: 'pathology', label: '标本病理' }]
      .map((control) => ({ ...control, options: INTRAOP_OPTIONS.map((option) => ({ ...option, selected: original.intraopStatus && original.intraopStatus[control.key] === option.value })) }));
    const pathologyLabels = { retained: '已留取', sent: '已送检', resulted: '结果已回' };
    const specimens = (original.pathologySpecimens || []).map((item) => ({ ...item, statusLabel: pathologyLabels[item.status], statusOptions: Object.keys(pathologyLabels).map((value) => ({ value, label: pathologyLabels[value], selected: item.status === value })) }));
    const clinicalEvents = (original.clinicalEvents || []).filter((item) => EVENT_LABELS[item.type]).sort((a, b) => b.at.localeCompare(a.at)).slice(0, 10).map((item) => {
      const statusText = item.type === 'urinaryCatheter' && item.value === 'none' ? '未留置' : item.type === 'drain-status' && item.value === 'active' ? '在位' : VALUE_LABELS[item.value] || item.value;
      return { ...item, typeLabel: EVENT_LABELS[item.type], valueLabel: item.type === 'antibiotic-note' ? item.value : `${item.note ? `${item.note} · ` : ''}${statusText}`, timeText: item.at.replace('T', ' ').slice(0, 16) };
    });
    const preopTasks = original.stage === '术前' ? tasks.filter((task) => task.stage === '术前' && task.critical) : [];
    const preopIds = new Set(preopTasks.map((task) => task.id));
    const appointmentTypes = original.department === '整形外科' && original.stage === '术前' ? [
      { type: 'photo', title: '生成拍照预约文本', desc: '复制后由医生自行核对并发送' },
      { type: 'surgery-summary', title: '生成 PPT 患者信息模板', desc: original.surgeryNameConfirmedAt && original.confirmedSurgeryName ? '简略姓名与已确认术式' : '完成主刀术式确认后可生成' },
      ...(isRadiotherapyCandidate(original.diagnosis) ? [{ type: 'radiotherapy', title: '生成放疗预约文本', desc: '瘢痕疙瘩术后放疗申请' }] : []),
    ] : [];
    this.setData({
      patient: { ...displayPatient, rounds, tasks, generalTasks: tasks.filter((task) => !preopIds.has(task.id)), preopTasks, surgeryNameConfirmed: Boolean(original.surgeryNameConfirmedAt), confirmedSurgeryName: original.confirmedSurgeryName || '', podText: pod === null ? '' : pod < 0 ? `术前 ${Math.abs(pod)} 天` : `POD ${pod}`, stageLogs },
      flow, reminders, archived: original.archived, intraoperative, postoperative, drains, statusControls, intraopControls, specimens, clinicalEvents, appointmentTypes,
      taskCategories: workspace.settings.taskCategories, taskCategoryIndex: Math.max(0, workspace.settings.taskCategories.indexOf(this.data.taskCategories[this.data.taskCategoryIndex]) >= 0 ? workspace.settings.taskCategories.indexOf(this.data.taskCategories[this.data.taskCategoryIndex]) : workspace.settings.taskCategories.indexOf('其他')),
    });
  },
  togglePrivacy() { this.setData({ privacyVisible: !this.data.privacyVisible }, () => this.loadPatient()); },
  startEdit() {
    if (this.data.archived) return;
    const patient = getPatient(this.patientId);
    const workspace = getWorkspace();
    if (!patient) return;
    const procedures = workspace.settings.procedures;
    const knownProcedureIndex = procedures.indexOf(patient.surgeryName || '未选择术式');
    const customProcedureMode = Boolean(patient.surgeryName) && knownProcedureIndex < 0;
    this.setData({
      editing: true, departments: workspace.settings.departments, procedures, procedureOptions: [...procedures, CUSTOM_PROCEDURE_OPTION], conditionOptions: workspace.settings.conditionTags.filter((item) => !['有引流', '留置导尿'].includes(item)).map((value) => ({ value, selected: (patient.conditions || []).includes(value) })), editConditions: (patient.conditions || []).filter((item) => !['有引流', '留置导尿'].includes(item)),
      departmentIndex: Math.max(0, workspace.settings.departments.indexOf(patient.department)),
      procedureIndex: customProcedureMode ? procedures.length : Math.max(0, knownProcedureIndex),
      customProcedureMode, customProcedure: customProcedureMode ? patient.surgeryName : '', addCustomProcedureToLibrary: false,
      editForm: {
        id: patient.id, name: patient.name, bed: patient.bed, age: patient.age || '', gender: patient.gender || '', patientType: patient.patientType || '普通',
        diagnosis: patient.diagnosis || '', admissionDate: patient.admissionDate || '', surgeryDate: patient.surgeryDate || '', surgeon: patient.surgeon || '', firstAssistant: patient.firstAssistant || '',
      },
    });
  },
  cancelEdit() { this.setData({ editing: false, editForm: {}, customProcedureMode: false, customProcedure: '', addCustomProcedureToLibrary: false }); },
  inputEdit(e) {
    const field = e.currentTarget.dataset.field;
    const value = ['bed', 'age'].includes(field) ? `${e.detail.value}`.replace(/\D/g, '') : e.detail.value;
    this.setData({ [`editForm.${field}`]: value });
  },
  chooseEditGender(e) { this.setData({ 'editForm.gender': e.currentTarget.dataset.value }); },
  chooseEditType(e) { this.setData({ 'editForm.patientType': e.currentTarget.dataset.value }); },
  toggleEditCondition(e) {
    const value = e.currentTarget.dataset.value;
    const editConditions = this.data.editConditions.includes(value) ? this.data.editConditions.filter((item) => item !== value) : [...this.data.editConditions, value];
    this.setData({ editConditions, conditionOptions: this.data.conditionOptions.map((item) => ({ ...item, selected: editConditions.includes(item.value) })) });
  },
  chooseEditDepartment(e) { this.setData({ departmentIndex: Number(e.detail.value) }); },
  chooseEditProcedure(e) {
    const procedureIndex = Number(e.detail.value);
    const customProcedureMode = procedureIndex === this.data.procedureOptions.length - 1;
    this.setData({ procedureIndex, customProcedureMode, customProcedure: customProcedureMode ? this.data.customProcedure : '', addCustomProcedureToLibrary: customProcedureMode ? this.data.addCustomProcedureToLibrary : false });
  },
  inputEditCustomProcedure(e) { this.setData({ customProcedure: e.detail.value }); },
  toggleEditCustomProcedureLibrary(e) { this.setData({ addCustomProcedureToLibrary: Boolean(e.detail.value) }); },
  saveEdit() {
    const form = this.data.editForm;
    if (!`${form.id || ''}`.trim() || !`${form.name || ''}`.trim() || !`${form.bed || ''}`.trim() || !`${form.surgeon || ''}`.trim()) return wx.showToast({ title: '请填写红色 * 标记的项目', icon: 'none' });
    if (!form.gender) return wx.showToast({ title: '请选择性别', icon: 'none' });
    const selectedProcedure = this.data.procedureOptions[this.data.procedureIndex];
    const procedure = this.data.customProcedureMode ? `${this.data.customProcedure || ''}`.trim() : selectedProcedure;
    if (this.data.customProcedureMode && !procedure) return wx.showToast({ title: '请填写自定义术式名称', icon: 'none' });
    const result = updatePatient(this.patientId, {
      id: form.id.trim(), name: form.name.trim(), bed: form.bed, age: form.age, gender: form.gender, patientType: form.patientType,
      diagnosis: `${form.diagnosis || ''}`.trim(), admissionDate: form.admissionDate, surgeryDate: form.surgeryDate,
      surgeryName: procedure === '未选择术式' ? '' : procedure, surgeon: form.surgeon.trim(), firstAssistant: `${form.firstAssistant || ''}`.trim(),
      department: this.data.departments[this.data.departmentIndex], conditions: this.data.editConditions,
    });
    if (!result.ok) return wx.showToast({ title: result.error, icon: 'none', duration: 2500 });
    if (this.data.customProcedureMode && this.data.addCustomProcedureToLibrary) addSettingItem('procedures', procedure);
    this.patientId = form.id.trim();
    this.setData({ editing: false, editForm: {}, customProcedureMode: false, customProcedure: '', addCustomProcedureToLibrary: false });
    this.loadPatient();
    wx.showToast({ title: '患者资料已更新', icon: 'success' });
  },
  copyAppointment(e) {
    const patient = getPatient(this.patientId);
    const type = e.currentTarget.dataset.type;
    if (!patient || !['photo', 'radiotherapy', 'surgery-summary'].includes(type)) return;
    const fields = type === 'photo' ? ['name', 'age', 'gender', 'id', 'diagnosis', 'surgeryDate', 'surgeryName', 'surgeon'] : type === 'surgery-summary' ? ['name', 'age', 'gender', 'diagnosis', 'confirmedSurgeryName'] : ['name', 'gender', 'id', 'diagnosis', 'surgeryDate'];
    const missing = missingFields(patient, fields);
    if (missing.length) return wx.showToast({ title: type === 'photo' ? '请补全患者、术式和主刀信息' : type === 'surgery-summary' ? '请补全姓名、年龄、性别、诊断和术式' : '请补全患者基本信息和诊断', icon: 'none', duration: 2600 });
    if (type === 'surgery-summary' && (!patient.surgeryNameConfirmedAt || !patient.confirmedSurgeryName)) return wx.showToast({ title: '请先完成主刀术式确认', icon: 'none', duration: 2400 });
    if (type !== 'surgery-summary' && getPOD(patient.surgeryDate) !== -1) return wx.showToast({ title: '手术日期须为明日，才能生成该预约文本', icon: 'none', duration: 2600 });
    const text = appointmentText(patient, type);
    wx.showModal({
      title: appointmentTitle(type), content: text, confirmText: '确认复制',
      success: (result) => {
        if (!result.confirm) return;
        wx.setClipboardData({ data: text, success: () => {
          const completed = completeAppointmentTask(this.patientId, type);
          wx.showToast({ title: completed ? `文本已复制，已完成${type === 'photo' ? '拍照' : '放疗会诊'}` : '文本已复制，请手动发送', icon: 'none', duration: 2600 });
          if (completed) this.loadPatient();
        } });
      },
    });
  },
  inputTask(e) { this.setData({ newTask: e.detail.value }); },
  chooseTaskCategory(e) { this.setData({ taskCategoryIndex: Number(e.detail.value) }); },
  addTask() {
    const title = this.data.newTask.trim();
    if (!title) return wx.showToast({ title: '请输入待办内容', icon: 'none' });
    const result = addTask(this.patientId, { title, dueAt: todayKey(), category: this.data.taskCategories[this.data.taskCategoryIndex] || '其他', priority: '普通' });
    if (!result.ok) return wx.showToast({ title: result.error, icon: 'none' });
    this.setData({ newTask: '' });
    this.loadPatient();
  },
  toggleTask(e) {
    if (this.data.archived) return;
    const task = this.data.patient.tasks.find((item) => item.id === e.currentTarget.dataset.id);
    if (!task) return;
    if (task.requiresSurgeryNameConfirm) return this.confirmSurgeryName(task);
    const done = !task.done;
    const result = setTaskDone(this.patientId, task.id, done);
    if (!result.ok) return wx.showToast({ title: result.error, icon: 'none', duration: 2400 });
    wx.showToast({ title: done ? '已完成' : '已恢复待办', icon: 'success' });
    this.loadPatient();
  },
  confirmSurgeryName(task) {
    const patient = getPatient(this.patientId);
    if (!patient) return;
    this.openEditor({ kind: 'surgery-confirm', title: '与主刀确认正式术式', description: '确认后会完成此任务，并解锁手术同意书签署。', placeholder: '填写确认后的正式手术名称', content: patient.confirmedSurgeryName || patient.surgeryName || '', taskId: task.id, confirmText: '确认保存' });
  },
  addReminder(e) {
    const reminder = this.data.reminders.find((item) => item.id === e.currentTarget.dataset.id);
    if (!reminder || reminder.alreadyAdded) return;
    const result = addReminderAsTask(this.patientId, reminder);
    wx.showToast({ title: result.ok ? '已加入今日待办' : result.error, icon: result.ok ? 'success' : 'none' });
    this.loadPatient();
  },
  changePostopStatus(e) {
    if (this.data.archived) return;
    const result = setPostopStatus(this.patientId, e.currentTarget.dataset.key, e.currentTarget.dataset.value);
    if (!result.ok) return wx.showToast({ title: result.error, icon: 'none' });
    this.loadPatient();
  },
  addAntibioticNote() {
    if (this.data.archived) return;
    this.openEditor({ kind: 'antibiotic-note', title: '记录抗生素调整', placeholder: '填写调整内容', confirmText: '保存' });
  },
  changeIntraopStatus(e) {
    if (this.data.archived) return;
    const result = setIntraopStatus(this.patientId, e.currentTarget.dataset.key, e.currentTarget.dataset.value);
    if (!result.ok) return wx.showToast({ title: result.error, icon: 'none' });
    this.loadPatient();
  },
  editFirstAssistant() {
    if (this.data.archived) return;
    const patient = getPatient(this.patientId);
    if (!patient) return;
    this.openEditor({ kind: 'first-assistant', title: '填写一助医生', placeholder: '一助医生姓名', content: patient.firstAssistant || '', confirmText: '保存' });
  },
  addSpecimen() {
    if (this.data.archived) return;
    this.openEditor({ kind: 'specimen', title: '添加标本病理', placeholder: '例如：瘢痕组织、皮肤肿物', confirmText: '添加' });
  },
  changeSpecimenStatus(e) {
    if (this.data.archived) return;
    setPathologyStatus(this.patientId, e.currentTarget.dataset.id, e.currentTarget.dataset.value);
    this.loadPatient();
  },
  addDrain() {
    if (this.data.archived) return;
    this.openEditor({ kind: 'drain', title: '添加引流', placeholder: '例如：盆腔引流、T 管', confirmText: '添加' });
  },
  recordDrain(e) {
    if (this.data.archived) return;
    this.openEditor({ kind: 'drain-volume', title: '记录引流量', placeholder: '引流量（mL）', drainId: e.currentTarget.dataset.id, confirmText: '保存' });
  },
  toggleDrain(e) {
    if (this.data.archived) return;
    const next = e.currentTarget.dataset.status === 'active' ? 'removed' : 'active';
    setDrainStatus(this.patientId, e.currentTarget.dataset.id, next);
    wx.showToast({ title: next === 'removed' ? '已标记拔除' : '已恢复在位', icon: 'success' });
    this.loadPatient();
  },
  openEditor(config) {
    this.setData({ editor: { visible: true, title: config.title || '', description: config.description || '', placeholder: config.placeholder || '', content: config.content || '', kind: config.kind || '', taskId: config.taskId || '', drainId: config.drainId || '', nextStage: config.nextStage || '', confirmText: config.confirmText || '保存', focus: false }, editorKeyboardHeight: 0 }, () => this.setData({ 'editor.focus': true }));
  },
  closeEditor() { this.setData({ editor: { visible: false, title: '', description: '', placeholder: '', content: '', kind: '', taskId: '', drainId: '', nextStage: '', confirmText: '保存', focus: false }, editorKeyboardHeight: 0 }); },
  keepEditorOpen() {},
  inputEditor(e) { this.setData({ 'editor.content': e.detail.value }); },
  editorFocus(e) { this.setData({ editorKeyboardHeight: Math.max(0, Number(e.detail.height) || 0) }); },
  editorBlur() { this.setData({ editorKeyboardHeight: 0 }); },
  saveEditor() {
    const editor = this.data.editor;
    const value = `${editor.content || ''}`.trim();
    let result;
    if (editor.kind === 'surgery-confirm') {
      if (!value) return wx.showToast({ title: '请填写正式手术名称', icon: 'none' });
      result = updatePatient(this.patientId, { confirmedSurgeryName: value });
      if (result.ok) result = setTaskDone(this.patientId, editor.taskId, true);
      if (!result.ok) return wx.showToast({ title: result.error || '保存失败', icon: 'none' });
      this.closeEditor();
      wx.showToast({ title: '正式术式已确认', icon: 'success' });
      return this.loadPatient();
    }
    if (editor.kind === 'antibiotic-note') result = addClinicalEvent(this.patientId, 'antibiotic-note', value);
    if (editor.kind === 'first-assistant') {
      result = updatePatient(this.patientId, { firstAssistant: value });
      if (result.ok) result = setIntraopStatus(this.patientId, 'assistant', value ? 'present' : 'none');
    }
    if (editor.kind === 'specimen') result = addPathologySpecimen(this.patientId, value);
    if (editor.kind === 'drain') result = addDrain(this.patientId, value);
    if (editor.kind === 'drain-volume') {
      if (!/^\d+(\.\d+)?$/.test(value)) return wx.showToast({ title: '请只填写数字', icon: 'none' });
      result = recordDrainVolume(this.patientId, editor.drainId, value);
    }
    if (editor.kind === 'stage-back') {
      this.closeEditor();
      return this.applyStageChange(editor.nextStage, value);
    }
    if (!result || !result.ok) return wx.showToast({ title: (result && result.error) || '保存失败', icon: 'none' });
    this.closeEditor();
    wx.showToast({ title: editor.kind === 'antibiotic-note' ? '调整记录已保存' : editor.kind === 'specimen' ? '标本已添加' : editor.kind === 'drain' ? '已添加引流' : editor.kind === 'drain-volume' ? '引流量已记录' : '已保存', icon: 'success' });
    this.loadPatient();
  },
  goRound() {
    if (this.data.archived) return wx.showToast({ title: '归档患者为只读状态', icon: 'none' });
    wx.navigateTo({ url: `/pages/rounds/rounds?id=${encodeURIComponent(this.patientId)}` });
  },
  selectStage(e) {
    if (this.data.archived) return wx.showToast({ title: '归档患者为只读状态', icon: 'none' });
    const nextStage = e.currentTarget.dataset.stage;
    const currentPatient = getPatient(this.patientId);
    if (!currentPatient || nextStage === currentPatient.stage) return;
    const names = getPatientFlow(currentPatient).map((item) => item.name);
    const isBackward = names.indexOf(nextStage) < names.indexOf(currentPatient.stage);
    if (isBackward) {
      this.openEditor({ kind: 'stage-back', title: '确认退回流程？', description: `将从“${currentPatient.stage}”退回至“${nextStage}”，记录不会删除。`, placeholder: '退回备注（可选）', nextStage, confirmText: '确认退回' });
    } else this.applyStageChange(nextStage);
  },
  applyStageChange(nextStage, note = '') {
    const result = changePatientStage(this.patientId, nextStage, note);
    if (!result.ok) {
      const detail = result.blockers && result.blockers.length ? `：${result.blockers.map((item) => item.title).join('、')}` : '';
      return wx.showModal({ title: '暂不能推进', content: `${result.error}${detail}`, showCancel: false });
    }
    this.loadPatient();
    wx.showToast({ title: `已切换至${nextStage}`, icon: 'success' });
  },
  archive() {
    wx.showModal({
      title: '归档这位患者？', content: '归档后将移出主页和在院列表，全部记录保留为只读。', confirmText: '确认归档',
      success: (result) => {
        if (!result.confirm) return;
        const archived = archivePatient(this.patientId);
        if (!archived.ok) return wx.showToast({ title: archived.error, icon: 'none' });
        wx.showToast({ title: '已归档', icon: 'success' });
        setTimeout(() => wx.navigateBack(), 500);
      },
    });
  },
});
