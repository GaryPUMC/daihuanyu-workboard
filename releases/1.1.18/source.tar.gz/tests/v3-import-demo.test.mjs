import assert from 'node:assert/strict';
import fs from 'node:fs';
import { createV3ImportDemo } from './fixtures/v3-import-demo.mjs';

const storage = new Map();
globalThis.wx = {
  getStorageSync: (key) => storage.get(key),
  setStorageSync: (key, value) => storage.set(key, value),
};

const sourcePath = new URL('../utils/workspace-store.js', import.meta.url);
const source = fs.readFileSync(sourcePath, 'utf8');
const store = await import(`data:text/javascript;base64,${Buffer.from(source).toString('base64')}`);
const sourceWorkspace = createV3ImportDemo();
const imported = store.prepareBackupImport(sourceWorkspace);

assert.equal(imported.sourceSchemaVersion, 3);
assert.equal(imported.targetSchemaVersion, 8);
assert.equal(imported.migrated, true);
assert.equal(imported.workspace.patients.length, 10);
assert.equal(imported.workspace.tasks.length >= 58, true);
assert.equal(imported.workspace.devices.length, 9);
assert.equal(imported.workspace.observations.length, 3);
assert.equal(imported.workspace.clinicalEvents.length, 11);
assert.equal(imported.workspace.pathologySpecimens.length, 4);
assert.equal(imported.workspace.patients[0].id, 'DEMO-V3-001');
assert.equal(imported.workspace.patients[0].allergies, '');

const dischargeTarget = imported.workspace.patients[0];
dischargeTarget.stage = '术后';
dischargeTarget.actualDischargeDate = '';
storage.set('daihuanyu_workboard_local_v3', structuredClone(imported.workspace));
const discharged = store.dischargePatient(dischargeTarget.id, '2026-08-05');
const dischargedWorkspace = store.getWorkspace();
const dischargedPatient = dischargedWorkspace.patients.find((item) => item.id === dischargeTarget.id);
assert.equal(discharged.ok, true);
assert.equal(dischargedPatient.stage, '出院');
assert.equal(dischargedPatient.actualDischargeDate, '2026-08-05');
assert.equal(store.getPatientStatus(dischargedPatient), '出院');
assert.equal(dischargedWorkspace.stageLogs[0].action, 'discharge');
const pendingDischarge = store.getDischargeReadiness(dischargedPatient, dischargedWorkspace);
assert.equal(pendingDischarge.discharged, true);
assert.equal(pendingDischarge.readyToArchive, false);
assert.equal(pendingDischarge.pendingLabels.includes('待通知一助并标记完成'), true);
const dischargeTask = dischargedWorkspace.tasks.find((task) => task.patientId === dischargedPatient.id && task.stage === '出院' && task.critical);
assert.equal(store.setTaskDone(dischargedPatient.id, dischargeTask.id, true).ok, true);
assert.equal(store.addClinicalEvent(dischargedPatient.id, 'cooperation-discharge-notice', '已通知一助').ok, true);
assert.equal(store.getDischargeReadiness(store.getPatient(dischargedPatient.id)).readyToArchive, true);
assert.equal(store.dischargePatient(dischargeTarget.id, '').ok, false);

const invalidDischargeWorkspace = structuredClone(imported.workspace);
invalidDischargeWorkspace.patients[1].admissionDate = '2999-12-31';
storage.set('daihuanyu_workboard_local_v3', invalidDischargeWorkspace);
const invalidDischarge = store.dischargePatient(invalidDischargeWorkspace.patients[1].id);
assert.equal(invalidDischarge.ok, false);
assert.equal(invalidDischarge.error, '入院日期不能晚于手术日期');

const invalidBackup = structuredClone(sourceWorkspace);
invalidBackup.patients[0].admissionDate = '2026-02-31';
assert.throws(() => store.prepareBackupImport(invalidBackup), /备份中存在无效日期/);

const scheduledWorkspace = structuredClone(imported.workspace);
scheduledWorkspace.patients[1].stage = '术后';
scheduledWorkspace.patients[1].plannedDischargeDate = store.todayKey();
scheduledWorkspace.patients[2].stage = '术后';
scheduledWorkspace.patients[2].plannedDischargeDate = '2999-12-31';
storage.set('daihuanyu_workboard_local_v3', scheduledWorkspace);
const scheduled = store.getWorkspace();
assert.equal(scheduled.patients[1].stage, '术后');
assert.equal(scheduled.patients[2].stage, '术后');
assert.equal(store.getPatientStatus(scheduled.patients[1]), '术后');

const planOnlyPatient = scheduled.patients[1];
assert.equal(planOnlyPatient.actualDischargeDate, '');
assert.equal(store.getPatientStatus(planOnlyPatient), '术后');

const reversedDates = store.createPatient({ id: 'validation-1', admissionDate: '2026-08-08', surgeryDate: '2026-08-07' });
assert.equal(reversedDates.ok, false);
assert.equal(reversedDates.error, '入院日期不能晚于手术日期');

const invalidDaySurgeryDates = store.createPatient({ id: 'validation-day-1', patientType: '日间', admissionDate: '2026-08-08', surgeryDate: '2026-08-09' });
assert.equal(invalidDaySurgeryDates.ok, false);
assert.equal(invalidDaySurgeryDates.error, '日间手术患者的入院日期与手术日期必须为同一天');

const incompleteAllergy = store.createPatient({ id: 'validation-allergy-1', allergyStatus: 'present', allergies: '' });
assert.equal(incompleteAllergy.ok, false);
assert.equal(incompleteAllergy.error, '请填写过敏史详情，或改为“无／未核实”');

const correctionTarget = scheduled.patients[0];
assert.equal(store.updatePatient(correctionTarget.id, { diagnosis: '更正后的诊断' }).ok, true);
const revisionEvent = store.getWorkspace().clinicalEvents.find((item) => item.patientId === correctionTarget.id && item.type === 'patient-revision');
assert.equal(Boolean(revisionEvent), true);
assert.match(revisionEvent.note, /诊断：/);

const drainDevice = store.getWorkspace().devices.find((item) => item.patientId === correctionTarget.id && item.type === 'drain');
assert.equal(store.recordDrainVolume(correctionTarget.id, drainDevice.id, '24.5', 1).ok, true);
assert.equal(store.recordDrainVolume(correctionTarget.id, drainDevice.id, '拔', 2).ok, true);
assert.equal(store.getWorkspace().devices.find((item) => item.id === drainDevice.id).status, 'removed');
const afterRemoval = store.recordDrainVolume(correctionTarget.id, drainDevice.id, '10', 3);
assert.equal(afterRemoval.ok, false);
assert.equal(afterRemoval.error, '该引流已在 POD 2 拔除，仅可更正拔管当日或此前记录');
const editBeforeRemoval = store.recordDrainVolume(correctionTarget.id, drainDevice.id, '12', 1);
assert.equal(editBeforeRemoval.ok, true);
assert.equal(store.recordDrainVolume(correctionTarget.id, drainDevice.id, '拔', 2).ok, true);
assert.equal(store.getWorkspace().devices.find((item) => item.id === drainDevice.id).status, 'removed');
assert.equal(store.getWorkspace().observations.some((item) => item.deviceId === drainDevice.id && item.pod === 2 && item.entryType === 'removed'), true);

assert.equal(store.ensureDrainRowCount(correctionTarget.id, 6).ok, true);
assert.equal(store.getPatient(correctionTarget.id).drainRowCount, 6);

const legacyDrainBackup = {
  schemaVersion: 4,
  settings: { activeDepartment: '整形外科', clinicalPresetVersion: 2 },
  patients: [{ id: 'LEGACY-DRAIN-001', name: '脱敏旧患者', bed: '9', gender: '男', department: '整形外科', stage: '入院' }],
  archivedPatients: [], rounds: [], tasks: [], taskDrafts: [], templates: [], stageLogs: [], clinicalEvents: [], pathologySpecimens: [],
  devices: [{ id: 'legacy-drain-001', patientId: 'LEGACY-DRAIN-001', type: 'drainage', name: '旧引流', status: 'present', createdAt: '2026-08-01T01:00:00.000Z' }],
  observations: [{ id: 'legacy-observation-001', patientId: 'LEGACY-DRAIN-001', drainId: 'legacy-drain-001', amount: '18', createdAt: '2026-08-02T01:00:00.000Z' }],
};
const legacyImported = store.prepareBackupImport(legacyDrainBackup);
const legacyDevice = legacyImported.workspace.devices[0];
assert.equal(legacyDevice.type, 'drain');
assert.equal(legacyDevice.status, 'active');
assert.equal(legacyDevice.legacy, true);
assert.equal(legacyImported.workspace.observations[0].deviceId, legacyDevice.id);
assert.equal(legacyImported.workspace.observations[0].value, 18);
storage.set('daihuanyu_workboard_local_v3', structuredClone(legacyImported.workspace));
assert.equal(store.recordDrainVolume('LEGACY-DRAIN-001', legacyDevice.id, '20', 2).ok, true);

const legacyRemovedBackup = structuredClone(legacyDrainBackup);
legacyRemovedBackup.devices[0].status = 'removed';
const legacyRemoved = store.prepareBackupImport(legacyRemovedBackup);
storage.set('daihuanyu_workboard_local_v3', structuredClone(legacyRemoved.workspace));
assert.equal(store.recordDrainVolume('LEGACY-DRAIN-001', 'legacy-drain-001', '19', 1).ok, true);
assert.equal(store.recordDrainVolume('LEGACY-DRAIN-001', 'legacy-drain-001', '20', 2).ok, false);

const cancellationId = scheduled.patients[2].id;
storage.set('daihuanyu_workboard_local_v3', structuredClone(scheduled));
assert.equal(store.addTask(cancellationId, '回收站恢复回归').ok, true);
assert.equal(store.revokePatientRegistration(cancellationId).ok, true);
assert.equal(store.getWorkspace().patients.some((patient) => patient.id === cancellationId), false);
const revoked = store.getRevokedRegistrations();
assert.equal(revoked.length, 1);
assert.equal(revoked[0].records.tasks.some((task) => task.title === '回收站恢复回归'), true);
assert.equal(store.getWorkspaceIntegrity().ok, true);
assert.equal(store.restoreRevokedRegistration(revoked[0].id).ok, true);
assert.equal(store.getWorkspace().patients.some((patient) => patient.id === cancellationId), true);
assert.equal(store.getWorkspace().tasks.some((task) => task.patientId === cancellationId && task.title === '回收站恢复回归'), true);

const atomicSource = [
  { id: 'atomic-001', admissionDate: '2026-08-08', surgeryDate: '', patientType: '普通' },
  { id: 'atomic-001', admissionDate: '2026-08-08', surgeryDate: '', patientType: '普通' },
];
assert.equal(store.createPatientsAtomically(atomicSource).ok, false);
assert.equal(store.getWorkspace().patients.some((patient) => patient.id === 'atomic-001'), false);
const atomicSuccess = store.createPatientsAtomically([{ id: 'atomic-002', admissionDate: '2026-08-08', surgeryDate: '', patientType: '普通' }]);
assert.equal(atomicSuccess.ok, true);
assert.equal(store.getWorkspace().patients.some((patient) => patient.id === 'atomic-002'), true);

const beforeRestore = structuredClone(store.getWorkspace());
const changedWorkspace = structuredClone(beforeRestore);
changedWorkspace.patients = changedWorkspace.patients.filter((patient) => patient.id !== 'atomic-002');
store.restoreWorkspace(changedWorkspace);
assert.equal(store.getRestoreSnapshotSummary().activePatients, beforeRestore.patients.length);
assert.equal(store.restorePreviousWorkspace().ok, true);
assert.equal(store.getWorkspace().patients.some((patient) => patient.id === 'atomic-002'), true);
const verified = store.recordBackupVerification('export', store.getBackupSummary(store.getWorkspace()));
assert.equal(verified.kind, 'export');
assert.equal(Boolean(store.getBackupSummary(store.getWorkspace()).lastBackupVerification), true);

const intraopFlow = store.createPatient({ id: 'flow-intraop-001', department: '整形外科', stage: '手术', firstAssistant: '' });
assert.equal(intraopFlow.ok, true);
const missingAssistant = store.changePatientStage('flow-intraop-001', '术后');
assert.equal(missingAssistant.ok, false);
assert.equal(missingAssistant.blockers.some((item) => item.title === '填写术中一助医生'), true);
assert.equal(missingAssistant.blockers.some((item) => /引流|尿管|病理/.test(item.title)), false);
assert.equal(store.changePatientStage('flow-intraop-001', '出院').error, '请按流程顺序逐步推进');
assert.equal(store.updatePatient('flow-intraop-001', { firstAssistant: '脱敏一助' }).ok, true);
assert.equal(store.changePatientStage('flow-intraop-001', '术后').ok, true);

const legacyIntraopWorkspace = structuredClone(store.getWorkspace());
legacyIntraopWorkspace.settings.clinicalPresetVersion = 2;
legacyIntraopWorkspace.patients.find((item) => item.id === 'flow-intraop-001').stage = '手术';
legacyIntraopWorkspace.tasks.push({ id: 'legacy-intraop-task', patientId: 'flow-intraop-001', title: '确认术中尿管情况', category: '术后观察', priority: '重要', status: 'todo', stage: '手术', critical: true, source: '阶段要求', sourceRef: 'stage:手术:确认术中尿管情况', createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() });
storage.set('daihuanyu_workboard_local_v3', legacyIntraopWorkspace);
store.ensureStageTasks('flow-intraop-001');
const retiredLegacyTask = store.getWorkspace().tasks.find((item) => item.id === 'legacy-intraop-task');
assert.equal(retiredLegacyTask.critical, false);
assert.equal(retiredLegacyTask.source, '已取消的阶段要求');

const postoperativeCleanup = structuredClone(store.getWorkspace());
postoperativeCleanup.settings.clinicalPresetVersion = 3;
postoperativeCleanup.settings.roundActionTemplates = [
  { id: 'round-action-remove-catheter', title: '拔尿管', category: '术后观察', priority: '普通', postoperativeOnly: true, effect: { key: 'urinaryCatheter', value: 'removed' } },
  { id: 'round-action-drain', title: '记录引流量', category: '术后观察', priority: '重要', postoperativeOnly: true, effect: null },
];
storage.set('daihuanyu_workboard_local_v3', postoperativeCleanup);
const cleanedPostoperative = store.getWorkspace();
assert.equal(cleanedPostoperative.settings.roundActionTemplates.some((item) => item.title === '拔尿管'), false);
assert.equal(cleanedPostoperative.settings.roundActionTemplates.some((item) => item.title === '记录引流量'), true);
assert.equal(store.getPatientReminders(store.getPatient('flow-intraop-001')).some((item) => /尿管|抗生素/.test(item.title)), false);

console.log('v3 de-identified import demo, discharge follow-up, validation, recoverable cancellation, and backup verification: passed');
