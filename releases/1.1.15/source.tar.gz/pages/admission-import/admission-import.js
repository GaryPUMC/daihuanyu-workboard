import { buildAdmissionPatient, getAdmissionImportPrompt, parseAdmissionImport } from '../../utils/admission-import';
import { createPatient, getWorkspace, todayKey } from '../../utils/workspace-store';

function decorateCandidates(candidates) {
  return candidates.map((item) => ({ ...item, selectedLabel: item.selected ? '已纳入' : '已跳过' }));
}

function preserveSelections(nextCandidates, previousCandidates) {
  return nextCandidates.map((item, index) => {
    const previous = previousCandidates[index];
    const selected = !item.errors.length && (!previous || previous.errors.length ? true : previous.selected);
    return { ...item, selected, selectedLabel: selected ? '已纳入' : '已跳过' };
  });
}

function emptyEditor() {
  return { visible: false, candidateId: '', form: {}, departmentIndex: 0, focus: false };
}

Page({
  data: {
    activeDepartment: '', prompt: '', inputText: '', candidates: [], parseError: '', summary: null, resultText: '',
    departments: [], genders: ['男', '女'], patientTypes: ['普通', '国疗', '日间'], editor: emptyEditor(),
  },
  onShow() {
    const workspace = getWorkspace();
    this.setData({ activeDepartment: workspace.settings.activeDepartment, departments: workspace.settings.departments, prompt: getAdmissionImportPrompt(todayKey()) });
  },
  inputText(e) { this.setData({ inputText: e.detail.value, parseError: '', resultText: '' }); },
  copyPrompt() {
    wx.setClipboardData({ data: this.data.prompt, success: () => wx.showToast({ title: '提示词已复制', icon: 'success' }) });
  },
  parseText() {
    const workspace = getWorkspace();
    const result = parseAdmissionImport(this.data.inputText, {
      today: todayKey(), activeDepartment: workspace.settings.activeDepartment,
      departments: workspace.settings.departments,
      existingPatients: [...workspace.patients, ...workspace.archivedPatients],
    });
    if (!result.ok) return this.setData({ candidates: [], summary: null, parseError: result.error });
    this.setData({ candidates: decorateCandidates(result.candidates), summary: result.summary, parseError: '', resultText: '' });
  },
  toggleCandidate(e) {
    const candidateId = e.currentTarget.dataset.id;
    const candidates = this.data.candidates.map((item) => {
      if (item.candidateId !== candidateId || item.errors.length) return item;
      const selected = !item.selected;
      return { ...item, selected, selectedLabel: selected ? '已纳入' : '已跳过' };
    });
    this.setData({ candidates });
  },
  openEditor(e) {
    const candidate = this.data.candidates.find((item) => item.candidateId === e.currentTarget.dataset.id);
    if (!candidate || candidate.statusTone === 'done') return;
    const departments = this.data.departments;
    this.setData({
      editor: {
        visible: true, candidateId: candidate.candidateId, form: { ...candidate.patient },
        departmentIndex: Math.max(0, departments.indexOf(candidate.patient.department)), focus: false,
      },
    });
  },
  closeEditor() { this.setData({ editor: emptyEditor() }); },
  keepEditorOpen() {},
  inputEditor(e) {
    const field = e.currentTarget.dataset.field;
    const value = ['bed', 'age'].includes(field) ? `${e.detail.value}`.replace(/\D/g, '') : e.detail.value;
    this.setData({ [`editor.form.${field}`]: value });
  },
  chooseEditorGender(e) { this.setData({ 'editor.form.gender': e.currentTarget.dataset.value }); },
  chooseEditorType(e) { this.setData({ 'editor.form.patientType': e.currentTarget.dataset.value }); },
  changeManagedByDaihuanyu(e) { this.setData({ 'editor.form.managedByDaihuanyu': Boolean(e.detail.value) }); },
  chooseEditorDepartment(e) {
    const departmentIndex = Number(e.detail.value);
    this.setData({ 'editor.departmentIndex': departmentIndex, 'editor.form.department': this.data.departments[departmentIndex] || '' });
  },
  saveEditor() {
    const editor = this.data.editor;
    if (!editor.candidateId) return;
    const patients = this.data.candidates.map((item) => item.candidateId === editor.candidateId ? editor.form : item.patient);
    const workspace = getWorkspace();
    const result = parseAdmissionImport(JSON.stringify({
      schema: 'workboard-admission-import/v1', department: this.data.activeDepartment, patients,
    }), {
      today: todayKey(), activeDepartment: workspace.settings.activeDepartment,
      departments: workspace.settings.departments,
      existingPatients: [...workspace.patients, ...workspace.archivedPatients],
    });
    if (!result.ok) return wx.showToast({ title: result.error, icon: 'none' });
    this.setData({
      candidates: preserveSelections(result.candidates, this.data.candidates), summary: result.summary,
      parseError: '', resultText: '', editor: emptyEditor(),
    });
    wx.showToast({ title: '已更新并重新校验', icon: 'success' });
  },
  confirmImport() {
    const selected = this.data.candidates.filter((item) => item.selected && !item.errors.length);
    if (!selected.length) return wx.showToast({ title: '请至少纳入一位可导入患者', icon: 'none' });
    wx.showModal({
      title: '确认录入今日入院患者',
      content: `将把 ${selected.length} 位患者保存到本机。请核对住院号、床位、性别和主刀医生。`,
      confirmText: '确认录入',
      success: (modal) => {
        if (!modal.confirm) return;
        const today = todayKey();
        const imported = [];
        const failed = [];
        selected.forEach((candidate) => {
          const result = createPatient(buildAdmissionPatient(candidate, today));
          if (result.ok) imported.push(candidate.patient.name || candidate.patient.id);
          else failed.push(`${candidate.patient.name || candidate.patient.id}：${result.error || '保存失败'}`);
        });
        const candidates = this.data.candidates.map((item) => imported.includes(item.patient.name || item.patient.id) ? { ...item, selected: false, selectedLabel: '已录入', statusLabel: '已录入', statusTone: 'done' } : item);
        this.setData({ candidates, inputText: '', resultText: `已录入 ${imported.length} 位${failed.length ? `；${failed.length} 位未录入：${failed.join('；')}` : ''}` });
        wx.showToast({ title: imported.length ? `已录入 ${imported.length} 位` : '未录入任何患者', icon: imported.length ? 'success' : 'none' });
      },
    });
  },
  clearImport() { this.setData({ inputText: '', candidates: [], parseError: '', summary: null, resultText: '', editor: emptyEditor() }); },
});
