import { addRoundActionTask, getPatientStatus, getPOD, getWorkspace, isPostoperative, maskPatient } from '../../utils/workspace-store';

const STATUS_LABELS = {
  unknown: '未确认', present: '留置中', removed: '已拔除', none: '未留置',
  active: '使用中', stopped: '已停止',
};
const PATIENT_TYPE_ORDER = { '日间': 0, '国疗': 1, '普通': 2 };

function compareRoundPatients(a, b) {
  const typeDiff = (PATIENT_TYPE_ORDER[a.patientType] ?? 99) - (PATIENT_TYPE_ORDER[b.patientType] ?? 99);
  if (typeDiff) return typeDiff;
  const bedA = Number((`${a.bed || ''}`.match(/\d+/) || ['999999'])[0]);
  const bedB = Number((`${b.bed || ''}`.match(/\d+/) || ['999999'])[0]);
  return bedA - bedB || `${a.name || ''}`.localeCompare(`${b.name || ''}`);
}

Page({
  data: { patients: [], actionTemplates: [], privacyVisible: true },
  onLoad(options) { this.initialId = decodeURIComponent(options.id || ''); },
  onShow() { this.setData({ privacyVisible: true }); this.loadBoard(); },
  onHide() { this.setData({ privacyVisible: true }); },
  loadBoard() {
    const workspace = getWorkspace();
    const actionTemplates = workspace.settings.roundActionTemplates || [];
    const activeDepartment = workspace.settings.activeDepartment;
    const patients = workspace.patients.filter((patient) => patient.department === activeDepartment && (getPatientStatus(patient) !== '出院' || (patient.patientType === '日间' && patient.admissionDate === patient.dischargeDate)) && workspace.devices.some((item) => item.patientId === patient.id && item.type === 'drain' && item.status === 'active')).map((patient) => {
      const masked = maskPatient(patient);
      const pod = getPOD(patient.surgeryDate);
      const drains = workspace.devices.filter((item) => item.patientId === patient.id && item.type === 'drain' && item.status === 'active').map((device) => {
        const values = workspace.observations.filter((item) => item.deviceId === device.id && item.entryType !== 'removed').sort((a, b) => a.pod - b.pod);
        const latest = values[values.length - 1];
        return `${device.name} ${latest ? `POD${latest.pod} ${latest.value}mL` : '待记录'}`;
      });
      const postoperative = isPostoperative(patient);
      const actions = actionTemplates.filter((action) => {
        if (!postoperative && action.postoperativeOnly) return false;
        if (action.effect && action.effect.key === 'urinaryCatheter' && patient.postopStatus.urinaryCatheter !== 'present') return false;
        if (action.effect && action.effect.key === 'monitoring' && patient.postopStatus.monitoring !== 'active') return false;
        if (action.effect && action.effect.key === 'oxygen' && patient.postopStatus.oxygen !== 'active') return false;
        if (action.id === 'round-action-drain' && !drains.length) return false;
        return true;
      });
      return {
        ...patient, genderClass: masked.genderClass, patientTypeClass: masked.patientTypeClass,
        displayName: this.data.privacyVisible ? patient.name : masked.displayName,
        displayId: this.data.privacyVisible ? patient.id : masked.displayId,
        podText: pod === null ? '' : pod < 0 ? `术前 ${Math.abs(pod)} 天` : `POD ${pod}`,
        openTaskCount: workspace.tasks.filter((item) => item.patientId === patient.id && item.status !== 'done').length,
        drainText: drains.join(' · '),
        catheterText: patient.postopStatus ? STATUS_LABELS[patient.postopStatus.urinaryCatheter] : '未确认',
        antibioticText: patient.postopStatus ? STATUS_LABELS[patient.postopStatus.antibiotic] : '未确认',
        postoperative, actions, careStatus: getPatientStatus(patient),
      };
    }).sort(compareRoundPatients);
    if (this.initialId) patients.sort((a, b) => (a.id === this.initialId ? -1 : b.id === this.initialId ? 1 : 0));
    this.setData({ patients, actionTemplates });
  },
  togglePrivacy() { this.setData({ privacyVisible: !this.data.privacyVisible }, () => this.loadBoard()); },
  addAction(e) {
    const result = addRoundActionTask(e.currentTarget.dataset.patientId, e.currentTarget.dataset.actionId);
    wx.showToast({ title: result.ok ? '已加入今日待办' : result.error, icon: result.ok ? 'success' : 'none', duration: 2200 });
    if (result.ok) this.loadBoard();
  },
  goPatient(e) { wx.navigateTo({ url: `/pages/patient-detail/patient-detail?id=${encodeURIComponent(e.currentTarget.dataset.id)}` }); },
  goSettings() { wx.navigateTo({ url: '/pages/settings' }); },
});
