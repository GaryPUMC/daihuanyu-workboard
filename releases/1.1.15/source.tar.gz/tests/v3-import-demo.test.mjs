import assert from 'node:assert/strict';
import fs from 'node:fs';
import { createV3ImportDemo } from './fixtures/v3-import-demo.mjs';

const storage = new Map();
globalThis.wx = {
  getStorageSync: (key) => storage.get(key),
  setStorageSync: (key, value) => storage.set(key, value),
};

const sourcePath = new URL('../utils/workspace-store.js', import.meta.url);
const source = fs.readFileSync(sourcePath, 'utf8');
const store = await import(`data:text/javascript;base64,${Buffer.from(source).toString('base64')}`);
const sourceWorkspace = createV3ImportDemo();
const imported = store.prepareBackupImport(sourceWorkspace);

assert.equal(imported.sourceSchemaVersion, 3);
assert.equal(imported.targetSchemaVersion, 5);
assert.equal(imported.migrated, true);
assert.equal(imported.workspace.patients.length, 10);
assert.equal(imported.workspace.tasks.length >= 58, true);
assert.equal(imported.workspace.devices.length, 9);
assert.equal(imported.workspace.observations.length, 3);
assert.equal(imported.workspace.clinicalEvents.length, 11);
assert.equal(imported.workspace.pathologySpecimens.length, 4);
assert.equal(imported.workspace.patients[0].id, 'DEMO-V3-001');
assert.equal(imported.workspace.patients[0].allergies, '');

const dischargeTarget = imported.workspace.patients[0];
dischargeTarget.stage = '术后';
dischargeTarget.dischargeDate = '';
storage.set('daihuanyu_workboard_local_v3', structuredClone(imported.workspace));
const discharged = store.dischargePatient(dischargeTarget.id, '2026-08-05');
const dischargedWorkspace = store.getWorkspace();
const dischargedPatient = dischargedWorkspace.patients.find((item) => item.id === dischargeTarget.id);
assert.equal(discharged.ok, true);
assert.equal(dischargedPatient.stage, '出院');
assert.equal(dischargedPatient.dischargeDate, '2026-08-05');
assert.equal(store.getPatientStatus(dischargedPatient), '出院');
assert.equal(dischargedWorkspace.stageLogs[0].action, 'discharge');
assert.equal(store.dischargePatient(dischargeTarget.id, '').ok, false);

const invalidDischargeWorkspace = structuredClone(imported.workspace);
invalidDischargeWorkspace.patients[1].admissionDate = '2999-12-31';
storage.set('daihuanyu_workboard_local_v3', invalidDischargeWorkspace);
const invalidDischarge = store.dischargePatient(invalidDischargeWorkspace.patients[1].id);
assert.equal(invalidDischarge.ok, false);
assert.equal(invalidDischarge.error, '入院日期不能晚于手术日期');

const invalidBackup = structuredClone(sourceWorkspace);
invalidBackup.patients[0].admissionDate = '2026-02-31';
assert.throws(() => store.prepareBackupImport(invalidBackup), /备份中存在无效日期/);

const scheduledWorkspace = structuredClone(imported.workspace);
scheduledWorkspace.patients[1].stage = '术后';
scheduledWorkspace.patients[1].dischargeDate = store.todayKey();
scheduledWorkspace.patients[2].stage = '术后';
scheduledWorkspace.patients[2].dischargeDate = '2999-12-31';
storage.set('daihuanyu_workboard_local_v3', scheduledWorkspace);
const scheduled = store.getWorkspace();
assert.equal(scheduled.patients[1].stage, '术后');
assert.equal(scheduled.patients[2].stage, '术后');
assert.equal(store.getPatientStatus(scheduled.patients[1]), '术后');

const reversedDates = store.createPatient({ id: 'validation-1', admissionDate: '2026-08-08', surgeryDate: '2026-08-07' });
assert.equal(reversedDates.ok, false);
assert.equal(reversedDates.error, '入院日期不能晚于手术日期');

const correctionTarget = scheduled.patients[0];
assert.equal(store.updatePatient(correctionTarget.id, { diagnosis: '更正后的诊断' }).ok, true);
assert.equal(store.getWorkspace().clinicalEvents.some((item) => item.patientId === correctionTarget.id && item.type === 'patient-correction'), false);

const drainDevice = store.getWorkspace().devices.find((item) => item.patientId === correctionTarget.id && item.type === 'drain');
assert.equal(store.recordDrainVolume(correctionTarget.id, drainDevice.id, '24.5', 1).ok, true);
assert.equal(store.recordDrainVolume(correctionTarget.id, drainDevice.id, '拔', 2).ok, true);
assert.equal(store.getWorkspace().devices.find((item) => item.id === drainDevice.id).status, 'removed');
const afterRemoval = store.recordDrainVolume(correctionTarget.id, drainDevice.id, '10', 3);
assert.equal(afterRemoval.ok, false);
assert.equal(afterRemoval.error, '该引流已在 POD 2 拔除，仅可更正拔管当日或此前记录');
const editBeforeRemoval = store.recordDrainVolume(correctionTarget.id, drainDevice.id, '12', 1);
assert.equal(editBeforeRemoval.ok, true);
assert.equal(store.recordDrainVolume(correctionTarget.id, drainDevice.id, '拔', 2).ok, true);
assert.equal(store.getWorkspace().devices.find((item) => item.id === drainDevice.id).status, 'removed');
assert.equal(store.getWorkspace().observations.some((item) => item.deviceId === drainDevice.id && item.pod === 2 && item.entryType === 'removed'), true);

const legacyDrainBackup = {
  schemaVersion: 4,
  settings: { activeDepartment: '整形外科', clinicalPresetVersion: 2 },
  patients: [{ id: 'LEGACY-DRAIN-001', name: '脱敏旧患者', bed: '9', gender: '男', department: '整形外科', stage: '入院' }],
  archivedPatients: [], rounds: [], tasks: [], taskDrafts: [], templates: [], stageLogs: [], clinicalEvents: [], pathologySpecimens: [],
  devices: [{ id: 'legacy-drain-001', patientId: 'LEGACY-DRAIN-001', type: 'drainage', name: '旧引流', status: 'present', createdAt: '2026-08-01T01:00:00.000Z' }],
  observations: [{ id: 'legacy-observation-001', patientId: 'LEGACY-DRAIN-001', drainId: 'legacy-drain-001', amount: '18', createdAt: '2026-08-02T01:00:00.000Z' }],
};
const legacyImported = store.prepareBackupImport(legacyDrainBackup);
const legacyDevice = legacyImported.workspace.devices[0];
assert.equal(legacyDevice.type, 'drain');
assert.equal(legacyDevice.status, 'active');
assert.equal(legacyDevice.legacy, true);
assert.equal(legacyImported.workspace.observations[0].deviceId, legacyDevice.id);
assert.equal(legacyImported.workspace.observations[0].value, 18);
storage.set('daihuanyu_workboard_local_v3', structuredClone(legacyImported.workspace));
assert.equal(store.recordDrainVolume('LEGACY-DRAIN-001', legacyDevice.id, '20', 2).ok, true);

const legacyRemovedBackup = structuredClone(legacyDrainBackup);
legacyRemovedBackup.devices[0].status = 'removed';
const legacyRemoved = store.prepareBackupImport(legacyRemovedBackup);
storage.set('daihuanyu_workboard_local_v3', structuredClone(legacyRemoved.workspace));
assert.equal(store.recordDrainVolume('LEGACY-DRAIN-001', 'legacy-drain-001', '19', 1).ok, true);
assert.equal(store.recordDrainVolume('LEGACY-DRAIN-001', 'legacy-drain-001', '20', 2).ok, false);

const cancellationId = scheduled.patients[2].id;
storage.set('daihuanyu_workboard_local_v3', structuredClone(scheduled));
assert.equal(store.revokePatientRegistration(cancellationId).ok, true);
assert.equal(store.getWorkspace().patients.some((patient) => patient.id === cancellationId), false);

console.log('v3 de-identified import demo, manual discharge, reminder, validation, and cancellation: passed');
