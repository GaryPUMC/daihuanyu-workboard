import { buildAdmissionPatient, getAdmissionImportPrompt, parseAdmissionImport } from '../../utils/admission-import';
import { addSettingItem, createPatientsAtomically, getDepartmentWards, getWorkspace, todayKey } from '../../utils/workspace-store';
import { createDialog, emptyDialog } from '../../utils/ui-state';

const CUSTOM_ASSISTANT_OPTION = '其他（手动填写）';
const ALLERGY_OPTIONS = [
  { value: 'unknown', label: '未核实' }, { value: 'none', label: '无' }, { value: 'present', label: '有' },
];

function decorateCandidates(candidates) {
  return candidates.map((item) => ({ ...item, selectedLabel: item.selected ? '已纳入' : '已跳过' }));
}

function preserveSelections(nextCandidates, previousCandidates) {
  return nextCandidates.map((item, index) => {
    const previous = previousCandidates[index];
    const selected = !item.errors.length && (!previous || previous.errors.length ? true : previous.selected);
    return { ...item, selected, selectedLabel: selected ? '已纳入' : '已跳过' };
  });
}

function emptyEditor() {
  return { visible: false, candidateId: '', form: {}, departmentIndex: 0, wardOptions: [], wardIndex: 0, firstAssistantIndex: 0, customAssistantMode: false, customAssistant: '', addCustomAssistantToLibrary: false, focus: false };
}

function wardState(department, departmentWards, ward = '') {
  const wardOptions = getDepartmentWards(department, { departmentWards });
  const selectedWard = wardOptions.length === 1 ? wardOptions[0] : (wardOptions.includes(ward) ? ward : '');
  return { wardOptions, ward: selectedWard, wardIndex: Math.max(0, wardOptions.indexOf(selectedWard)) };
}

Page({
  data: {
    activeDepartment: '', prompt: '', inputText: '', candidates: [], parseError: '', summary: null, resultText: '',
    departments: [], departmentWards: {}, genders: ['男', '女'], patientTypes: ['普通', '国疗', '日间'], allergyOptions: ALLERGY_OPTIONS, firstAssistants: [], firstAssistantOptions: [], editor: emptyEditor(), editorKeyboardHeight: 0, editorScrollIntoView: '', editorSaveBusy: false, editorDirty: false, dialog: emptyDialog(),
  },
  onShow() {
    const workspace = getWorkspace();
    this.setData({ activeDepartment: workspace.settings.activeDepartment, departments: workspace.settings.departments, departmentWards: workspace.settings.departmentWards, prompt: getAdmissionImportPrompt(todayKey()) });
  },
  inputText(e) { this.setData({ inputText: e.detail.value, parseError: '', resultText: '' }); },
  openDialog(config) { wx.hideKeyboard({ complete: () => this.setData({ dialog: createDialog(config) }) }); },
  copyPrompt() {
    wx.setClipboardData({ data: this.data.prompt, success: () => wx.showToast({ title: '提示词已复制', icon: 'success' }) });
  },
  parseText() {
    const workspace = getWorkspace();
    const result = parseAdmissionImport(this.data.inputText, {
      today: todayKey(), activeDepartment: workspace.settings.activeDepartment,
      departments: workspace.settings.departments, departmentWards: workspace.settings.departmentWards,
      existingPatients: [...workspace.patients, ...workspace.archivedPatients],
    });
    if (!result.ok) return this.setData({ candidates: [], summary: null, parseError: result.error });
    this.setData({ candidates: decorateCandidates(result.candidates), summary: result.summary, parseError: '', resultText: '' });
  },
  toggleCandidate(e) {
    const candidateId = e.currentTarget.dataset.id;
    const candidates = this.data.candidates.map((item) => {
      if (item.candidateId !== candidateId || item.errors.length) return item;
      const selected = !item.selected;
      return { ...item, selected, selectedLabel: selected ? '已纳入' : '已跳过' };
    });
    this.setData({ candidates });
  },
  openEditor(e) {
    const candidate = this.data.candidates.find((item) => item.candidateId === e.currentTarget.dataset.id);
    if (!candidate || candidate.statusTone === 'done') return;
    const departments = this.data.departments;
    const workspace = getWorkspace();
    const firstAssistants = workspace.settings.firstAssistants;
    const assistantIndex = firstAssistants.indexOf(candidate.patient.firstAssistant);
    const wards = wardState(candidate.patient.department, workspace.settings.departmentWards, candidate.patient.ward);
    this.setData({
      editor: {
        visible: true, candidateId: candidate.candidateId, form: { ...candidate.patient, ward: wards.ward, allergyStatus: candidate.patient.allergyStatus || (candidate.patient.allergies ? 'present' : 'unknown') },
        wardOptions: wards.wardOptions, wardIndex: wards.wardIndex,
        departmentIndex: Math.max(0, departments.indexOf(candidate.patient.department)), firstAssistantIndex: assistantIndex >= 0 ? assistantIndex + 1 : (candidate.patient.firstAssistant ? firstAssistants.length + 1 : 0), customAssistantMode: Boolean(candidate.patient.firstAssistant) && assistantIndex < 0, customAssistant: assistantIndex < 0 ? candidate.patient.firstAssistant : '', addCustomAssistantToLibrary: false, focus: false,
      },
      firstAssistants, firstAssistantOptions: ['未填写', ...firstAssistants, CUSTOM_ASSISTANT_OPTION], editorKeyboardHeight: 0, editorScrollIntoView: '', editorSaveBusy: false, editorDirty: false,
    });
  },
  closeEditor() {
    if (!this.data.editorSaveBusy) this.setData({ editor: emptyEditor(), editorKeyboardHeight: 0, editorScrollIntoView: '', editorDirty: false });
  },
  editorKeyboardChange(e) {
    const editorKeyboardHeight = Math.max(0, Number(e.detail.height) || 0);
    if (editorKeyboardHeight !== this.data.editorKeyboardHeight) this.setData({ editorKeyboardHeight });
  },
  focusEditorField(e) { this.setData({ editorScrollIntoView: e.currentTarget.id || '' }); },
  markEditorDirty(updates) { this.setData({ ...updates, editorDirty: true }); },
  inputEditor(e) {
    const field = e.currentTarget.dataset.field;
    const value = ['bed', 'age'].includes(field) ? `${e.detail.value}`.replace(/\D/g, '') : e.detail.value;
    this.markEditorDirty({ [`editor.form.${field}`]: value });
  },
  chooseEditorGender(e) { this.markEditorDirty({ 'editor.form.gender': e.currentTarget.dataset.value }); },
  chooseEditorType(e) {
    const patientType = e.currentTarget.dataset.value;
    const updates = { 'editor.form.patientType': patientType };
    if (patientType === '日间' && this.data.editor.form.admissionDate) updates['editor.form.surgeryDate'] = this.data.editor.form.admissionDate;
    this.markEditorDirty(updates);
  },
  chooseEditorAllergyStatus(e) { this.markEditorDirty({ 'editor.form.allergyStatus': e.currentTarget.dataset.value, 'editor.form.allergies': e.currentTarget.dataset.value === 'none' ? '' : this.data.editor.form.allergies }); },
  chooseEditorFirstAssistant(e) {
    const firstAssistantIndex = Number(e.detail.value);
    const customAssistantMode = firstAssistantIndex === this.data.firstAssistantOptions.length - 1;
    const firstAssistant = customAssistantMode ? this.data.editor.form.firstAssistant : (this.data.firstAssistantOptions[firstAssistantIndex] === '未填写' ? '' : this.data.firstAssistantOptions[firstAssistantIndex]);
    this.markEditorDirty({ 'editor.firstAssistantIndex': firstAssistantIndex, 'editor.customAssistantMode': customAssistantMode, 'editor.customAssistant': customAssistantMode ? this.data.editor.customAssistant || this.data.editor.form.firstAssistant : '', 'editor.form.firstAssistant': firstAssistant, 'editor.addCustomAssistantToLibrary': customAssistantMode ? this.data.editor.addCustomAssistantToLibrary : false });
  },
  inputEditorCustomAssistant(e) { this.markEditorDirty({ 'editor.customAssistant': e.detail.value, 'editor.form.firstAssistant': e.detail.value }); },
  toggleEditorCustomAssistantLibrary(e) { this.markEditorDirty({ 'editor.addCustomAssistantToLibrary': Boolean(e.detail.value) }); },
  changeManagedByDaihuanyu(e) { this.markEditorDirty({ 'editor.form.managedByDaihuanyu': Boolean(e.detail.value) }); },
  chooseEditorDepartment(e) {
    const departmentIndex = Number(e.detail.value);
    const department = this.data.departments[departmentIndex] || '';
    const wards = wardState(department, this.data.departmentWards);
    this.markEditorDirty({ 'editor.departmentIndex': departmentIndex, 'editor.form.department': department, 'editor.form.ward': wards.ward, 'editor.wardOptions': wards.wardOptions, 'editor.wardIndex': wards.wardIndex });
  },
  chooseEditorWard(e) {
    const wardIndex = Number(e.detail.value);
    this.markEditorDirty({ 'editor.wardIndex': wardIndex, 'editor.form.ward': this.data.editor.wardOptions[wardIndex] || '' });
  },
  saveEditor() {
    const editor = this.data.editor;
    if (!editor.candidateId || this.data.editorSaveBusy) return;
    this.setData({ editorSaveBusy: true });
    const patients = this.data.candidates.map((item) => item.candidateId === editor.candidateId ? editor.form : item.patient);
    const workspace = getWorkspace();
    const result = parseAdmissionImport(JSON.stringify({
      schema: 'workboard-admission-import/v1', department: this.data.activeDepartment, patients,
    }), {
      today: todayKey(), activeDepartment: workspace.settings.activeDepartment,
      departments: workspace.settings.departments, departmentWards: workspace.settings.departmentWards,
      existingPatients: [...workspace.patients, ...workspace.archivedPatients],
    });
    if (!result.ok) { this.setData({ editorSaveBusy: false }); return wx.showToast({ title: result.error, icon: 'none' }); }
    this.setData({
      candidates: preserveSelections(result.candidates, this.data.candidates), summary: result.summary,
      parseError: '', resultText: '', editor: emptyEditor(), editorKeyboardHeight: 0, editorScrollIntoView: '', editorSaveBusy: false, editorDirty: false,
    });
    if (editor.customAssistantMode && editor.addCustomAssistantToLibrary && `${editor.form.firstAssistant || ''}`.trim()) addSettingItem('firstAssistants', `${editor.form.firstAssistant}`.trim());
    wx.showToast({ title: '已更新并重新校验', icon: 'success' });
  },
  confirmImport() {
    const selected = this.data.candidates.filter((item) => item.selected && !item.errors.length);
    if (!selected.length) return wx.showToast({ title: '请至少纳入一位可导入患者', icon: 'none' });
    this.openDialog({ title: '确认录入拟入院患者', message: `将把 ${selected.length} 位患者保存到本机。预入院患者可暂不填写床位，系统将显示“待分配”。请核对住院号、性别和主刀医生。`, confirmText: '确认录入', action: 'confirm-import' });
  },
  closeDialog() { if (!this.data.dialog.loading) this.setData({ dialog: emptyDialog() }); },
  confirmDialog() {
    if (this.dialogBusy || this.data.dialog.loading) return;
    if (this.data.dialog.action === 'dismiss') return this.setData({ dialog: emptyDialog() });
    if (this.data.dialog.action !== 'confirm-import') return;
    const selected = this.data.candidates.filter((item) => item.selected && !item.errors.length);
    if (!selected.length) return this.setData({ dialog: emptyDialog() });
    this.dialogBusy = true;
    this.setData({ 'dialog.loading': true });
    const result = createPatientsAtomically(selected.map((candidate) => buildAdmissionPatient(candidate, todayKey())));
    this.dialogBusy = false;
    if (!result.ok) return this.setData({ dialog: createDialog({ title: '未录入任何患者', message: `${result.error}。请重新解析并核对后再确认。`, confirmText: '知道了', showCancel: false, action: 'dismiss' }) });
    const importedIds = new Set(result.patients.map((patient) => patient.id));
    const candidates = this.data.candidates.map((item) => importedIds.has(item.patient.id) ? { ...item, selected: false, selectedLabel: '已录入', statusLabel: '已录入', statusTone: 'done' } : item);
    this.setData({ candidates, inputText: '', resultText: `已原子录入 ${result.patients.length} 位；未产生部分写入。`, dialog: emptyDialog() });
    wx.showToast({ title: `已录入 ${result.patients.length} 位`, icon: 'success' });
  },
  clearImport() { this.setData({ inputText: '', candidates: [], parseError: '', summary: null, resultText: '', editor: emptyEditor(), editorKeyboardHeight: 0, editorScrollIntoView: '', editorSaveBusy: false, editorDirty: false }); },
});
