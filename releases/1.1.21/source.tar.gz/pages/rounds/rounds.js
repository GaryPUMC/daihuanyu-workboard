import { addRoundActionTask, getPatientStatus, getPOD, getWorkspace, isPostoperative, maskPatient } from '../../utils/workspace-store';
const PATIENT_TYPE_ORDER = { '日间': 0, '国疗': 1, '普通': 2 };

function isInHospitalForRounds(patient) {
  return !['出院', '待入院'].includes(getPatientStatus(patient));
}

function compareRoundPatients(a, b) {
  const typeDiff = (PATIENT_TYPE_ORDER[a.patientType] ?? 99) - (PATIENT_TYPE_ORDER[b.patientType] ?? 99);
  if (typeDiff) return typeDiff;
  const wardDiff = `${a.ward || ''}`.localeCompare(`${b.ward || ''}`);
  if (wardDiff) return wardDiff;
  const bedA = Number((`${a.bed || ''}`.match(/\d+/) || ['999999'])[0]);
  const bedB = Number((`${b.bed || ''}`.match(/\d+/) || ['999999'])[0]);
  return bedA - bedB || `${a.name || ''}`.localeCompare(`${b.name || ''}`);
}

Page({
  data: { patients: [], actionTemplates: [], privacyVisible: true, viewMode: 'drain', allPatientCount: 0, drainPatientCount: 0 },
  onLoad(options) { this.initialId = decodeURIComponent(options.id || ''); },
  onShow() { this.setData({ privacyVisible: true }); this.loadBoard(); },
  onHide() { this.setData({ privacyVisible: true }); },
  loadBoard() {
    const workspace = getWorkspace();
    const actionTemplates = workspace.settings.roundActionTemplates || [];
    const activeDepartment = workspace.settings.activeDepartment;
    const allInHospital = workspace.patients.filter((patient) => patient.department === activeDepartment && isInHospitalForRounds(patient));
    const drainPatients = allInHospital.filter((patient) => workspace.devices.some((item) => item.patientId === patient.id && item.type === 'drain' && item.status === 'active'));
    const sourcePatients = this.data.viewMode === 'drain' ? drainPatients : allInHospital;
    const patients = sourcePatients.map((patient) => {
      const masked = maskPatient(patient, workspace.settings.departmentWards);
      const pod = getPOD(patient.surgeryDate);
      const drains = workspace.devices.filter((item) => item.patientId === patient.id && item.type === 'drain' && item.status === 'active').map((device) => {
        const values = workspace.observations.filter((item) => item.deviceId === device.id && item.entryType !== 'removed').sort((a, b) => a.pod - b.pod);
        const latest = values[values.length - 1];
        return `${device.name} ${latest ? `POD${latest.pod} ${latest.value}mL` : '待记录'}`;
      });
      const postoperative = isPostoperative(patient);
      const actions = actionTemplates.filter((action) => {
        if (!postoperative && action.postoperativeOnly) return false;
        if (action.id === 'round-action-drain' && !drains.length) return false;
        return true;
      });
      return {
        ...patient, locationLabel: masked.locationLabel, genderClass: masked.genderClass, patientTypeClass: masked.patientTypeClass,
        displayName: this.data.privacyVisible ? patient.name : masked.displayName,
        displayId: this.data.privacyVisible ? patient.id : masked.displayId,
        podText: pod === null ? '' : pod < 0 ? `术前 ${Math.abs(pod)} 天` : `POD ${pod}`,
        openTaskCount: workspace.tasks.filter((item) => item.patientId === patient.id && item.status !== 'done').length,
        drainText: drains.join(' · ') || '无在位引流',
        postoperative, actions, careStatus: getPatientStatus(patient),
      };
    }).sort(compareRoundPatients);
    if (this.initialId) patients.sort((a, b) => (a.id === this.initialId ? -1 : b.id === this.initialId ? 1 : 0));
    this.setData({ patients, actionTemplates, allPatientCount: allInHospital.length, drainPatientCount: drainPatients.length });
  },
  selectViewMode(e) {
    const viewMode = e.currentTarget.dataset.mode;
    if (!['drain', 'all'].includes(viewMode) || viewMode === this.data.viewMode) return;
    this.setData({ viewMode }, () => this.loadBoard());
  },
  togglePrivacy() { this.setData({ privacyVisible: !this.data.privacyVisible }, () => this.loadBoard()); },
  addAction(e) {
    const result = addRoundActionTask(e.currentTarget.dataset.patientId, e.currentTarget.dataset.actionId);
    wx.showToast({ title: result.ok ? '已加入今日待办' : result.error, icon: result.ok ? 'success' : 'none', duration: 2200 });
    if (result.ok) this.loadBoard();
  },
  goPatient(e) { wx.navigateTo({ url: `/pages/patient-detail/patient-detail?id=${encodeURIComponent(e.currentTarget.dataset.id)}` }); },
  goSettings() { wx.navigateTo({ url: '/pages/settings' }); },
});
