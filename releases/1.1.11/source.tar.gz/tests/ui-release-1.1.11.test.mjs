import assert from 'node:assert/strict';
import fs from 'node:fs';

const read = (path) => fs.readFileSync(new URL(path, import.meta.url), 'utf8');
const home = read('../pages/home/home.wxml');
const patientList = read('../pages/patients/patients.wxml');
const patientListCss = read('../pages/patients/patients.wxss');
const detail = read('../pages/patient-detail/patient-detail.wxml');
const detailCss = read('../pages/patient-detail/patient-detail.wxss');
const rounds = read('../pages/rounds/rounds.wxml');
const roundsJs = read('../pages/rounds/rounds.js');
const version = read('../VERSION').trim();

assert.equal(version.startsWith('1.1.11'), true);
assert.equal(home.includes('class="action-grid"'), false);
assert.equal(home.includes('主刀、一助、入院／手术／出院日期与过敏史一览'), false);
assert.equal(home.includes('<text class="patient-flag out">出</text><text class="patient-status">'), false);
assert.equal(home.includes('class="summary-badges"'), true);
assert.equal(read('../pages/home/home.js').includes("privacyVisible: true"), true);
assert.equal(patientList.includes('class="card-actions"'), true);
assert.equal(patientListCss.includes('.edit { position: absolute'), false);
assert.equal(patientListCss.includes('.allergy.has-allergy { padding:'), true);
assert.equal(read('../pages/patients/patients.js').includes("privacyVisible: true"), true);
assert.equal(detail.includes('计划出院：{{patient.dischargeDate || \'未设置\'}}'), true);
assert.equal(detail.includes('今天出院'), true);
assert.equal(detailCss.includes('.identity-surgeon, .identity-assistant'), true);
assert.equal(rounds.includes('class="patient-labels"'), true);
assert.equal(roundsJs.includes('getPatientStatus(patient) !== \'出院\''), true);

console.log('1.1.11 UI release checks: passed');
