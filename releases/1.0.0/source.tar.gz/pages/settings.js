import { addRoundActionTemplate, addSettingItem, getBackupSummary, getWorkspace, removeRoundActionTemplate, removeSettingItem, restoreWorkspace } from '../utils/workspace-store';
import { decryptBackup, encryptBackup } from '../utils/secure-backup';

const sectionDefinitions = [
  { key: 'departments', title: '轮转科室', desc: '用于患者归属、科室流程和默认模板。', placeholder: '添加科室' },
  { key: 'procedures', title: '术式', desc: '可与围术期路径建立默认关联。', placeholder: '添加术式' },
  { key: 'diagnoses', title: '诊断常用词', desc: '为后续快速录入预留的常用诊断简称。', placeholder: '添加诊断简称' },
  { key: 'stages', title: '通用流程阶段', desc: '各科室未单独配置时使用的流程主线。', placeholder: '添加阶段' },
  { key: 'taskCategories', title: '任务分类', desc: '用于患者详情中新增待办时的分类选择。', placeholder: '添加任务分类' },
  { key: 'conditionTags', title: '规则条件', desc: '用于路径条件规则；引流和尿管由术后模块自动判断，不在建档时选择。', placeholder: '添加其他条件' },
];

Page({
  data: {
    sections: [], inputs: {}, roundActions: [], roundActionInput: '', backupPassword: '', backupPath: '', backupSummary: null,
  },
  onShow() { this.loadSettings(); },
  loadSettings() {
    const workspace = getWorkspace();
    const sections = sectionDefinitions.map((section) => ({ ...section, items: workspace.settings[section.key] || [] }));
    this.setData({ sections, roundActions: workspace.settings.roundActionTemplates || [], backupSummary: getBackupSummary(workspace) });
  },
  inputSetting(e) { this.setData({ [`inputs.${e.currentTarget.dataset.category}`]: e.detail.value }); },
  inputPassword(e) { this.setData({ backupPassword: e.detail.value }); },
  inputRoundAction(e) { this.setData({ roundActionInput: e.detail.value }); },
  addRoundAction() {
    const title = this.data.roundActionInput.trim();
    if (!title) return wx.showToast({ title: '请输入操作名称', icon: 'none' });
    if (!addRoundActionTemplate(title)) return wx.showToast({ title: '已存在相同操作', icon: 'none' });
    this.setData({ roundActionInput: '' });
    this.loadSettings();
  },
  removeRoundAction(e) {
    wx.showModal({
      title: '移除快捷操作？', content: '已有待办不会受到影响。', confirmText: '移除',
      success: (result) => { if (result.confirm) { removeRoundActionTemplate(e.currentTarget.dataset.id); this.loadSettings(); } },
    });
  },
  add(e) {
    const category = e.currentTarget.dataset.category;
    const value = `${this.data.inputs[category] || ''}`.trim();
    if (!value) return wx.showToast({ title: '请输入名称', icon: 'none' });
    if (!addSettingItem(category, value)) return wx.showToast({ title: '已存在相同项目', icon: 'none' });
    this.setData({ [`inputs.${category}`]: '' });
    this.loadSettings();
  },
  remove(e) {
    const { category, value } = e.currentTarget.dataset;
    const section = this.data.sections.find((item) => item.key === category);
    if (['departments', 'stages'].includes(category) && section.items.length <= 1) return wx.showToast({ title: '请至少保留一个项目', icon: 'none' });
    if (category === 'procedures' && value === '未选择术式') return;
    wx.showModal({
      title: '确认移除？', content: `“${value}”将不再出现在新建选项中，已有患者资料不会改变。`, confirmText: '移除',
      success: (result) => {
        if (!result.confirm) return;
        const removed = removeSettingItem(category, value);
        if (!removed.ok) return wx.showToast({ title: removed.error, icon: 'none', duration: 2600 });
        this.loadSettings();
      },
    });
  },
  goTemplates() { wx.navigateTo({ url: '/pages/templates/templates' }); },
  goWorkflows() { wx.navigateTo({ url: '/pages/workflow-settings/workflow-settings' }); },
  exportBackup() {
    const password = this.data.backupPassword;
    if (!password || password.length < 8) return wx.showToast({ title: '请先输入至少 8 位备份密码', icon: 'none' });
    wx.showModal({
      title: '生成加密备份？', content: '备份包含患者敏感资料。请妥善保管密码，不要发送给无关人员。', confirmText: '生成备份',
      success: (result) => {
        if (!result.confirm) return;
        wx.showLoading({ title: '正在加密', mask: true });
        try {
          const content = encryptBackup(getWorkspace(), password);
          const filePath = `${wx.env.USER_DATA_PATH}/工作板备份-${Date.now()}.dhwb`;
          wx.getFileSystemManager().writeFileSync(filePath, content, 'utf8');
          this.setData({ backupPath: filePath });
          wx.hideLoading();
          wx.showToast({ title: '加密备份已生成', icon: 'success' });
        } catch (error) {
          wx.hideLoading();
          wx.showModal({ title: '备份失败', content: error.message || '无法生成备份', showCancel: false });
        }
      },
    });
  },
  shareBackup() {
    if (!this.data.backupPath) return;
    wx.showModal({
      title: '离开本机前再次确认',
      content: '下一步会打开微信文件分享界面，但不会自动发送。备份已加密，仍应只保存到你本人控制的位置。',
      confirmText: '打开分享',
      success: (result) => {
        if (!result.confirm) return;
        wx.shareFileMessage({ filePath: this.data.backupPath, fileName: '代寰宇的工作板加密备份.dhwb', fail: () => wx.showToast({ title: '当前环境不支持文件分享', icon: 'none' }) });
      },
    });
  },
  importBackup() {
    const password = this.data.backupPassword;
    if (!password) return wx.showToast({ title: '请输入备份文件的密码', icon: 'none' });
    wx.showModal({
      title: '选择加密备份', content: '【隐私】仅选择由本工作板生成的 .dhwb 文件。读取和恢复均在本机完成。', confirmText: '选择文件',
      success: (confirmed) => {
        if (!confirmed.confirm) return;
        wx.chooseMessageFile({
          count: 1, type: 'file', extension: ['dhwb'],
          success: (selection) => {
            wx.showLoading({ title: '正在验证', mask: true });
            try {
              const content = wx.getFileSystemManager().readFileSync(selection.tempFiles[0].path, 'utf8');
              const workspace = decryptBackup(content, password);
              const summary = getBackupSummary(workspace);
              wx.hideLoading();
              wx.showModal({
                title: '确认恢复此备份？',
                content: `在院 ${summary.activePatients} 人，归档 ${summary.archivedPatients} 人，查房 ${summary.rounds} 条。恢复前会自动保留当前数据快照。`,
                confirmText: '确认恢复',
                success: (result) => {
                  if (!result.confirm) return;
                  try { restoreWorkspace(workspace); this.loadSettings(); wx.showToast({ title: '数据已恢复', icon: 'success' }); }
                  catch (error) { wx.showModal({ title: '恢复失败', content: error.message || '备份结构不完整', showCancel: false }); }
                },
              });
            } catch (error) {
              wx.hideLoading();
              wx.showModal({ title: '无法读取备份', content: error.message || '密码错误或文件已损坏', showCancel: false });
            }
          },
        });
      },
    });
  },
});
