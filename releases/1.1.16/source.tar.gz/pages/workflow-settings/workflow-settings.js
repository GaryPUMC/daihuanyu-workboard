import { getWorkspace, saveDepartmentWorkflow } from '../../utils/workspace-store';

Page({
  data: { departments: [], departmentIndex: 0, workflowText: '' },
  onShow() {
    const workspace = getWorkspace();
    this.workspace = workspace;
    this.setData({ departments: workspace.settings.departments }, () => this.loadWorkflow());
  },
  chooseDepartment(e) { this.setData({ departmentIndex: Number(e.detail.value) }, () => this.loadWorkflow()); },
  loadWorkflow() {
    const department = this.data.departments[this.data.departmentIndex];
    if (!department || !this.workspace) return;
    const configured = this.workspace.settings.departmentWorkflows[department];
    const stages = configured && configured.length ? configured : this.workspace.settings.stages.map((name) => ({ name, criticalTasks: this.workspace.settings.stageRequirements[name] || [] }));
    const workflowText = stages.map((stage) => `${stage.name}${stage.criticalTasks && stage.criticalTasks.length ? `：${stage.criticalTasks.join('｜')}` : ''}`).join('\n');
    this.setData({ workflowText });
  },
  input(e) { this.setData({ workflowText: e.detail.value }); },
  save() {
    const stages = this.data.workflowText.split('\n').map((line) => line.trim()).filter(Boolean).map((line) => {
      const parts = line.split(/[:：]/);
      return { name: parts[0].trim(), criticalTasks: (parts.slice(1).join('：') || '').split(/[|｜]/).map((item) => item.trim()).filter(Boolean) };
    }).filter((item) => item.name);
    if (!stages.length) return wx.showToast({ title: '请至少保留一个阶段', icon: 'none' });
    const names = stages.map((item) => item.name);
    if (new Set(names).size !== names.length) return wx.showToast({ title: '阶段名称不能重复', icon: 'none' });
    const department = this.data.departments[this.data.departmentIndex];
    const activePatients = this.workspace.patients.filter((patient) => patient.department === department);
    wx.showModal({
      title: '确认保存流程？',
      content: `将影响 ${activePatients.length} 位在院患者的当前阶段关键项；已完成记录会保留。`,
      confirmText: '确认保存',
      success: (confirmed) => {
        if (!confirmed.confirm) return;
        const result = saveDepartmentWorkflow(department, stages);
        if (!result.ok) return wx.showToast({ title: result.error || '无法保存流程', icon: 'none', duration: 2600 });
        this.workspace = getWorkspace();
        wx.showToast({ title: '科室流程已保存', icon: 'success' });
      },
    });
  },
});
