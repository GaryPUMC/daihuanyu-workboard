import { addSettingItem, createPatient, getPatientStatus, getWorkspace, maskPatient, setActiveDepartment, todayKey, updatePatient } from '../../utils/workspace-store';

const CUSTOM_PROCEDURE_OPTION = '＋ 自定义新术式';
const CUSTOM_ASSISTANT_OPTION = '其他（手动填写）';
const ALLERGY_OPTIONS = [
  { value: 'unknown', label: '未核实' }, { value: 'none', label: '无' }, { value: 'present', label: '有' },
];

function isSameDayDayPatient(patient) {
  return patient.patientType === '日间' && patient.admissionDate && patient.admissionDate === patient.actualDischargeDate;
}

function isDischargedPatient(patient) {
  return getPatientStatus(patient) === '出院' && !isSameDayDayPatient(patient);
}

function nextDayKey(dateString) {
  const [year, month, day] = `${dateString}`.split('-').map(Number);
  const date = new Date(Date.UTC(year, month - 1, day + 1));
  return `${date.getUTCFullYear()}-${`${date.getUTCMonth() + 1}`.padStart(2, '0')}-${`${date.getUTCDate()}`.padStart(2, '0')}`;
}

const emptyForm = () => {
  const admissionDate = todayKey();
  return { id: '', name: '', bed: '', age: '', gender: '', diagnosis: '', allergyStatus: 'unknown', allergies: '', admissionDate, surgeryDate: nextDayKey(admissionDate), plannedDischargeDate: '', surgeon: '', firstAssistant: '', patientType: '普通' };
};

Page({
  data: {
    patients: [], query: '', viewMode: 'active', privacyVisible: true,
    showForm: false, editingId: '', form: emptyForm(),
    templates: [], templateOptions: [], templateIndex: 0,
    departments: [], departmentIndex: 0, procedures: [], procedureOptions: [], procedureIndex: 0, customProcedureMode: false, customProcedure: '', addCustomProcedureToLibrary: false,
    diagnoses: [], genders: ['男', '女'], patientTypes: ['普通', '国疗', '日间'], allergyOptions: ALLERGY_OPTIONS, activeDepartment: '', currentDepartmentIndex: 0,
    firstAssistants: [], firstAssistantOptions: [], firstAssistantIndex: 0, customAssistantMode: false, customAssistant: '', addCustomAssistantToLibrary: false,
  },
  onShow() {
    this.setData({ privacyVisible: true });
    this.loadPatients();
  },
  onHide() { this.setData({ privacyVisible: true }); },
  loadPatients() {
    const query = this.data.query.trim().toLowerCase();
    const workspace = getWorkspace();
    const activeDepartment = workspace.settings.activeDepartment;
    const activePatients = workspace.patients.filter((patient) => !isDischargedPatient(patient));
    const dischargedPatients = workspace.patients.filter(isDischargedPatient);
    const allPatients = this.data.viewMode === 'archive' ? [...dischargedPatients, ...workspace.archivedPatients] : activePatients;
    const searchablePatients = [...workspace.patients, ...workspace.archivedPatients];
    const source = query ? searchablePatients : allPatients.filter((patient) => patient.department === activeDepartment);
    let patients = source.map((patient) => {
      const masked = maskPatient(patient);
      return {
        ...masked,
        displayName: this.data.privacyVisible ? patient.name : masked.displayName,
        displayId: this.data.privacyVisible ? patient.id : masked.displayId,
        listBadge: this.data.viewMode === 'archive' ? '出' : patient.admissionDate === todayKey() ? '新' : '',
      };
    });
    if (query) patients = patients.filter((item) => `${item.id}${item.name}${item.bed}${item.department}${item.diagnosis}`.toLowerCase().includes(query));
    const templateOptions = [{ id: '', name: '自动匹配（术式 > 科室）' }, ...workspace.templates];
    this.setData({
      patients, templates: workspace.templates, templateOptions,
      departments: workspace.settings.departments, procedures: workspace.settings.procedures, procedureOptions: [...workspace.settings.procedures, CUSTOM_PROCEDURE_OPTION],
      diagnoses: workspace.settings.diagnoses, activeDepartment, currentDepartmentIndex: Math.max(0, workspace.settings.departments.indexOf(activeDepartment)),
    });
  },
  search(e) { this.setData({ query: e.detail.value }, () => this.loadPatients()); },
  switchView(e) {
    this.setData({ viewMode: e.currentTarget.dataset.mode, showForm: false, editingId: '' }, () => this.loadPatients());
  },
  togglePrivacy() { this.setData({ privacyVisible: !this.data.privacyVisible }, () => this.loadPatients()); },
  startCreate() {
    const workspace = getWorkspace();
    this.setData({ showForm: true, editingId: '', form: emptyForm(), departmentIndex: Math.max(0, workspace.settings.departments.indexOf(workspace.settings.activeDepartment)), procedureIndex: 0, templateIndex: 0, customProcedureMode: false, customProcedure: '', addCustomProcedureToLibrary: false, firstAssistants: workspace.settings.firstAssistants, firstAssistantOptions: ['未填写', ...workspace.settings.firstAssistants, CUSTOM_ASSISTANT_OPTION], firstAssistantIndex: 0, customAssistantMode: false, customAssistant: '', addCustomAssistantToLibrary: false });
  },
  cancelForm() { this.setData({ showForm: false, editingId: '', form: emptyForm() }); },
  goAdmissionImport() { wx.navigateTo({ url: '/pages/admission-import/admission-import' }); },
  editPatient(e) {
    const id = e.currentTarget.dataset.id;
    const workspace = getWorkspace();
    const patient = workspace.patients.find((item) => item.id === id);
    if (!patient) return;
    const templateOptions = [{ id: '', name: '自动匹配（术式 > 科室）' }, ...workspace.templates];
    const procedure = patient.surgeryName || '未选择术式';
    const knownProcedureIndex = workspace.settings.procedures.indexOf(procedure);
    const customProcedureMode = Boolean(patient.surgeryName) && knownProcedureIndex < 0;
    const firstAssistants = workspace.settings.firstAssistants;
    const assistantIndex = firstAssistants.indexOf(patient.firstAssistant);
    this.setData({
      showForm: true, editingId: id,
      form: {
        id: patient.id, name: patient.name, bed: patient.bed, age: patient.age || '', diagnosis: patient.diagnosis || '',
        gender: patient.gender || '', admissionDate: patient.admissionDate || '', surgeryDate: patient.surgeryDate || '', plannedDischargeDate: patient.plannedDischargeDate || '', allergyStatus: patient.allergyStatus || (patient.allergies ? 'present' : 'unknown'), allergies: patient.allergies || '', surgeon: patient.surgeon || '', firstAssistant: patient.firstAssistant || '', patientType: patient.patientType || '普通',
      },
      departmentIndex: Math.max(0, workspace.settings.departments.indexOf(patient.department)),
      procedureIndex: customProcedureMode ? workspace.settings.procedures.length : Math.max(0, knownProcedureIndex),
      customProcedureMode, customProcedure: customProcedureMode ? patient.surgeryName : '', addCustomProcedureToLibrary: false,
      firstAssistants, firstAssistantOptions: ['未填写', ...firstAssistants, CUSTOM_ASSISTANT_OPTION], firstAssistantIndex: assistantIndex >= 0 ? assistantIndex + 1 : (patient.firstAssistant ? firstAssistants.length + 1 : 0), customAssistantMode: Boolean(patient.firstAssistant) && assistantIndex < 0, customAssistant: assistantIndex < 0 ? patient.firstAssistant : '', addCustomAssistantToLibrary: false,
      templateIndex: Math.max(0, templateOptions.findIndex((item) => item.id === patient.templateId)),
    });
  },
  input(e) {
    const field = e.currentTarget.dataset.field;
    const value = ['bed', 'age'].includes(field) ? `${e.detail.value}`.replace(/\D/g, '') : e.detail.value;
    const updates = { [`form.${field}`]: value };
    if (field === 'admissionDate' && this.data.form.patientType === '日间') updates['form.surgeryDate'] = value;
    this.setData(updates);
  },
  chooseDepartment(e) { this.setData({ departmentIndex: Number(e.detail.value) }); },
  chooseGender(e) { this.setData({ 'form.gender': e.currentTarget.dataset.value }); },
  choosePatientType(e) {
    const patientType = e.currentTarget.dataset.value;
    const updates = { 'form.patientType': patientType };
    if (patientType === '日间' && this.data.form.admissionDate) updates['form.surgeryDate'] = this.data.form.admissionDate;
    this.setData(updates);
  },
  chooseAllergyStatus(e) { this.setData({ 'form.allergyStatus': e.currentTarget.dataset.value, 'form.allergies': e.currentTarget.dataset.value === 'none' ? '' : this.data.form.allergies }); },
  chooseFirstAssistant(e) {
    const firstAssistantIndex = Number(e.detail.value);
    const customAssistantMode = firstAssistantIndex === this.data.firstAssistantOptions.length - 1;
    const firstAssistant = customAssistantMode ? this.data.form.firstAssistant : (this.data.firstAssistantOptions[firstAssistantIndex] === '未填写' ? '' : this.data.firstAssistantOptions[firstAssistantIndex]);
    this.setData({ firstAssistantIndex, customAssistantMode, customAssistant: customAssistantMode ? this.data.customAssistant || this.data.form.firstAssistant : '', 'form.firstAssistant': firstAssistant, addCustomAssistantToLibrary: customAssistantMode ? this.data.addCustomAssistantToLibrary : false });
  },
  inputCustomAssistant(e) { this.setData({ customAssistant: e.detail.value, 'form.firstAssistant': e.detail.value }); },
  toggleAddCustomAssistant(e) { this.setData({ addCustomAssistantToLibrary: Boolean(e.detail.value) }); },
  chooseCurrentDepartment(e) {
    const department = this.data.departments[Number(e.detail.value)];
    if (department && setActiveDepartment(department)) this.setData({ showForm: false, editingId: '' }, () => this.loadPatients());
  },
  chooseTemplate(e) { this.setData({ templateIndex: Number(e.detail.value) }); },
  chooseProcedure(e) {
    const procedureIndex = Number(e.detail.value);
    const customProcedureMode = procedureIndex === this.data.procedureOptions.length - 1;
    this.setData({ procedureIndex, customProcedureMode, customProcedure: customProcedureMode ? this.data.customProcedure : '', addCustomProcedureToLibrary: customProcedureMode ? this.data.addCustomProcedureToLibrary : false });
  },
  inputCustomProcedure(e) { this.setData({ customProcedure: e.detail.value }); },
  toggleAddCustomProcedure(e) { this.setData({ addCustomProcedureToLibrary: Boolean(e.detail.value) }); },
  chooseDiagnosis(e) { this.setData({ 'form.diagnosis': e.currentTarget.dataset.value }); },
  savePatient() {
    const { id, name, bed, age, gender, diagnosis, allergyStatus, allergies, admissionDate, surgeryDate, plannedDischargeDate, surgeon, firstAssistant, patientType } = this.data.form;
    if (!id.trim() || !name.trim() || !bed.trim() || !surgeon.trim()) return wx.showToast({ title: '请填写住院号、姓名、床位和主刀医生', icon: 'none' });
    if (!gender) return wx.showToast({ title: '请选择性别', icon: 'none' });
    const template = this.data.templateOptions[this.data.templateIndex];
    const selectedProcedure = this.data.procedureOptions[this.data.procedureIndex];
    const procedure = this.data.customProcedureMode ? `${this.data.customProcedure || ''}`.trim() : selectedProcedure;
    if (this.data.customProcedureMode && !procedure) return wx.showToast({ title: '请填写自定义术式名称', icon: 'none' });
    const payload = {
      id: id.trim(), name: name.trim(), bed: bed.trim(), age: age.trim(), gender,
      diagnosis: diagnosis.trim(), allergyStatus, allergies: allergies.trim(), admissionDate, surgeryDate, plannedDischargeDate, surgeon: surgeon.trim(), firstAssistant: firstAssistant.trim(), patientType,
      surgeryName: procedure === '未选择术式' ? '' : procedure,
      templateId: template ? template.id : '', department: this.data.departments[this.data.departmentIndex],
    };
    let result;
    const wasEditing = Boolean(this.data.editingId);
    if (wasEditing) result = updatePatient(this.data.editingId, payload);
    else {
      result = createPatient({ ...payload, stage: surgeryDate ? '术前' : '入院' });
    }
    if (!result.ok) return wx.showToast({ title: result.error, icon: 'none', duration: 2500 });
    if (this.data.customProcedureMode && this.data.addCustomProcedureToLibrary) addSettingItem('procedures', procedure);
    if (this.data.customAssistantMode && this.data.addCustomAssistantToLibrary && firstAssistant.trim()) addSettingItem('firstAssistants', firstAssistant.trim());
    this.setData({ showForm: false, editingId: '', form: emptyForm(), templateIndex: 0, procedureIndex: 0, customProcedureMode: false, customProcedure: '', addCustomProcedureToLibrary: false });
    this.loadPatients();
    wx.showToast({ title: wasEditing ? '患者资料已更新' : '已保存至本机', icon: 'success' });
  },
  goDetail(e) { wx.navigateTo({ url: `/pages/patient-detail/patient-detail?id=${encodeURIComponent(e.currentTarget.dataset.id)}` }); },
});
