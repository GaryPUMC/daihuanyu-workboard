import { addSettingItem, addTemplate, getWorkspace, setTemplateAssignment, updateTemplate } from '../../utils/workspace-store';

const CUSTOM_PROCEDURE_OPTION = '＋ 自定义新术式';

const emptyRule = () => ({ kindIndex: 0, startDay: '1', endDay: '1', stageIndex: 0, conditionIndex: 0, critical: false, tasks: '' });

Page({
  data: {
    templates: [], selectedId: '', showForm: false, editingId: '',
    departments: [], departmentOptions: [], departmentIndex: 0,
    procedures: [], procedureOptions: [], procedureIndex: 0, customProcedureMode: false, customProcedure: '', addCustomProcedureToLibrary: false,
    stages: [], conditions: [], conditionOptions: [],
    kindOptions: ['术前/术后相对日', '流程阶段'],
    form: { name: '', rules: [] }, ruleForm: emptyRule(),
  },
  onShow() { this.loadTemplates(); },
  stageOptionsForDepartment(index) {
    const workspace = this.workspace || getWorkspace();
    const department = index ? this.data.departmentOptions[index] : '';
    const flow = department && workspace.settings.departmentWorkflows[department];
    return flow && flow.length ? flow.map((item) => item.name) : workspace.settings.stages;
  },
  loadTemplates() {
    const workspace = getWorkspace();
    this.workspace = workspace;
    const departmentOptions = ['不指定科室', ...workspace.settings.departments];
    const procedureOptions = ['不关联术式', ...workspace.settings.procedures.filter((item) => item !== '未选择术式'), CUSTOM_PROCEDURE_OPTION];
    const conditionOptions = ['无条件', ...workspace.settings.conditionTags];
    const decorateRule = (rule) => ({
      ...rule,
      tasksText: (rule.tasks || []).join('；'),
      metaText: `${rule.label}${rule.conditionTag ? ` · 条件：${rule.conditionTag}` : ''}${rule.critical ? ' · 关键任务' : ''}`,
    });
    const templates = workspace.templates.map((template) => {
      const departmentDefault = Object.keys(workspace.settings.departmentTemplates).find((key) => workspace.settings.departmentTemplates[key] === template.id);
      const procedureDefault = Object.keys(workspace.settings.procedureTemplates).find((key) => workspace.settings.procedureTemplates[key] === template.id);
      return { ...template, rules: template.rules.map(decorateRule), assignmentText: [procedureDefault && `术式：${procedureDefault}`, departmentDefault && `科室：${departmentDefault}`].filter(Boolean).join(' · ') || '未设默认关联' };
    });
    this.setData({
      templates, selectedId: this.data.selectedId || (templates[0] && templates[0].id),
      departments: workspace.settings.departments, departmentOptions, procedures: workspace.settings.procedures,
      procedureOptions, stages: workspace.settings.stages, conditions: workspace.settings.conditionTags, conditionOptions,
    });
  },
  select(e) { this.setData({ selectedId: e.currentTarget.dataset.id }); },
  startCreate() {
    this.setData({ showForm: true, editingId: '', departmentIndex: 0, procedureIndex: 0, stages: this.stageOptionsForDepartment(0), customProcedureMode: false, customProcedure: '', addCustomProcedureToLibrary: false, form: { name: '', rules: [] }, ruleForm: emptyRule() });
  },
  cancelForm() { this.setData({ showForm: false, editingId: '', customProcedureMode: false, customProcedure: '', addCustomProcedureToLibrary: false, form: { name: '', rules: [] }, ruleForm: emptyRule() }); },
  editTemplate(e) {
    const workspace = getWorkspace();
    const template = workspace.templates.find((item) => item.id === e.currentTarget.dataset.id);
    if (!template) return;
    const departmentDefault = Object.keys(workspace.settings.departmentTemplates).find((key) => workspace.settings.departmentTemplates[key] === template.id) || '';
    const procedureDefault = Object.keys(workspace.settings.procedureTemplates).find((key) => workspace.settings.procedureTemplates[key] === template.id) || '';
    const knownProcedureIndex = this.data.procedureOptions.indexOf(procedureDefault);
    const customProcedureMode = Boolean(procedureDefault) && knownProcedureIndex < 0;
    const departmentIndex = Math.max(0, this.data.departmentOptions.indexOf(departmentDefault));
    const stages = this.stageOptionsForDepartment(departmentIndex);
    this.setData({
      showForm: true, editingId: template.id,
      departmentIndex, stages,
      procedureIndex: customProcedureMode ? this.data.procedureOptions.length - 1 : Math.max(0, knownProcedureIndex),
      customProcedureMode, customProcedure: customProcedureMode ? procedureDefault : '', addCustomProcedureToLibrary: false,
      form: { name: template.name, rules: template.rules.map((rule) => ({ ...rule, tasksText: (rule.tasks || []).join('；'), metaText: `${rule.label}${rule.conditionTag ? ` · ${rule.conditionTag}` : ''}${rule.critical ? ' · 关键' : ''}` })) }, ruleForm: emptyRule(),
    });
  },
  input(e) { this.setData({ [`${e.currentTarget.dataset.scope}.${e.currentTarget.dataset.field}`]: e.detail.value }); },
  chooseDepartment(e) {
    const departmentIndex = Number(e.detail.value);
    const stages = this.stageOptionsForDepartment(departmentIndex);
    this.setData({ departmentIndex, stages, 'ruleForm.stageIndex': Math.min(this.data.ruleForm.stageIndex, Math.max(0, stages.length - 1)) });
  },
  chooseProcedure(e) {
    const procedureIndex = Number(e.detail.value);
    const customProcedureMode = procedureIndex === this.data.procedureOptions.length - 1;
    this.setData({ procedureIndex, customProcedureMode, customProcedure: customProcedureMode ? this.data.customProcedure : '', addCustomProcedureToLibrary: customProcedureMode ? this.data.addCustomProcedureToLibrary : false });
  },
  inputCustomProcedure(e) { this.setData({ customProcedure: e.detail.value }); },
  toggleAddCustomProcedure(e) { this.setData({ addCustomProcedureToLibrary: Boolean(e.detail.value) }); },
  chooseKind(e) { this.setData({ 'ruleForm.kindIndex': Number(e.detail.value) }); },
  chooseStage(e) { this.setData({ 'ruleForm.stageIndex': Number(e.detail.value) }); },
  chooseCondition(e) { this.setData({ 'ruleForm.conditionIndex': Number(e.detail.value) }); },
  toggleCritical(e) { this.setData({ 'ruleForm.critical': e.detail.value }); },
  timingLabel(kind, startDay, endDay, stage) {
    if (kind === 'stage') return `${stage}阶段`;
    const label = (day) => Number(day) < 0 ? `术前 ${Math.abs(Number(day))} 天` : `POD ${Number(day)}`;
    return Number(startDay) === Number(endDay) ? label(startDay) : `${label(startDay)} 至 ${label(endDay)}`;
  },
  addRule() {
    const ruleForm = this.data.ruleForm;
    const tasks = ruleForm.tasks.split('\n').map((item) => item.trim()).filter(Boolean);
    if (!tasks.length) return wx.showToast({ title: '请至少填写一个任务', icon: 'none' });
    const kind = ruleForm.kindIndex === 1 ? 'stage' : 'relative';
    const startDay = kind === 'relative' ? Number(ruleForm.startDay) : null;
    const endDay = kind === 'relative' ? Number(ruleForm.endDay || ruleForm.startDay) : null;
    if (kind === 'relative' && (!Number.isFinite(startDay) || !Number.isFinite(endDay))) return wx.showToast({ title: '请输入有效的相对天数', icon: 'none' });
    const stage = kind === 'stage' ? this.data.stages[ruleForm.stageIndex] : '';
    const conditionTag = ruleForm.conditionIndex ? this.data.conditionOptions[ruleForm.conditionIndex] : '';
    const metaText = `${this.timingLabel(kind, startDay, endDay, stage)}${conditionTag ? ` · ${conditionTag}` : ''}${ruleForm.critical ? ' · 关键' : ''}`;
    const rule = {
      id: `rule-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      label: this.timingLabel(kind, startDay, endDay, stage), kind, anchor: 'surgery', startDay, endDay, stage,
      conditionTag, critical: ruleForm.critical, tasks, tasksText: tasks.join('；'), metaText,
    };
    const duplicate = this.data.form.rules.some((item) => item.kind === rule.kind && item.startDay === rule.startDay && item.endDay === rule.endDay && item.stage === rule.stage && item.conditionTag === rule.conditionTag && item.tasks.join('\n') === rule.tasks.join('\n'));
    if (duplicate) return wx.showToast({ title: '相同规则已存在，请勿重复添加', icon: 'none' });
    this.setData({ 'form.rules': [...this.data.form.rules, rule], ruleForm: emptyRule() });
  },
  removeRule(e) {
    const index = Number(e.currentTarget.dataset.index);
    this.setData({ 'form.rules': this.data.form.rules.filter((item, itemIndex) => itemIndex !== index) });
  },
  saveTemplate() {
    const name = this.data.form.name.trim();
    if (!name) return wx.showToast({ title: '请填写模板名称', icon: 'none' });
    if (!this.data.form.rules.length) return wx.showToast({ title: '请至少添加一条时间规则', icon: 'none' });
    const invalidStageRule = this.data.form.rules.find((rule) => rule.kind === 'stage' && !this.data.stages.includes(rule.stage));
    if (invalidStageRule) return wx.showToast({ title: `阶段“${invalidStageRule.stage}”不在当前科室流程中`, icon: 'none', duration: 2600 });
    const departmentAssignment = this.data.departmentIndex ? this.data.departmentOptions[this.data.departmentIndex] : '';
    const department = departmentAssignment || '轮转通用';
    const procedure = this.data.customProcedureMode ? `${this.data.customProcedure || ''}`.trim() : this.data.procedureIndex ? this.data.procedureOptions[this.data.procedureIndex] : '';
    if (this.data.customProcedureMode && !procedure) return wx.showToast({ title: '请填写自定义术式名称', icon: 'none' });
    const payload = { name, department, procedure, rules: this.data.form.rules };
    let templateId = this.data.editingId;
    if (templateId) updateTemplate(templateId, payload);
    else templateId = addTemplate(payload).id;
    if (this.data.customProcedureMode && this.data.addCustomProcedureToLibrary) addSettingItem('procedures', procedure);
    setTemplateAssignment('department', departmentAssignment, templateId);
    setTemplateAssignment('procedure', this.data.procedureIndex ? procedure : '', templateId);
    const wasEditing = Boolean(this.data.editingId);
    this.setData({ showForm: false, editingId: '', customProcedureMode: false, customProcedure: '', addCustomProcedureToLibrary: false, form: { name: '', rules: [] }, ruleForm: emptyRule(), selectedId: templateId });
    this.loadTemplates();
    wx.showToast({ title: wasEditing ? '路径模板已更新' : '路径模板已保存', icon: 'success' });
  },
});
