const LEGACY_STORAGE_KEY = 'daihuanyu_workboard_local_v1';
const STORAGE_KEY = 'daihuanyu_workboard_local_v2';
const MIGRATION_SNAPSHOT_KEY = 'daihuanyu_workboard_migration_snapshot_v1';
const RESTORE_SNAPSHOT_KEY = 'daihuanyu_workboard_restore_snapshot_v2';
const SIMULATION_CLEANUP_SNAPSHOT_KEY = 'daihuanyu_workboard_simulation_cleanup_snapshot_v1';
const SCHEMA_VERSION = 2;

export const DEFAULT_STAGES = ['入院', '检查', '谈话', '术前', '手术', '术后', '出院', '整理'];
export const PLASTIC_PATIENT_TYPES = ['普通', '国疗', '日间'];
const PLASTIC_SURGERY_NAME_CONFIRM_TASK = '与主刀确认手术名称，并核实手术同意书名称';
const PLASTIC_CONSENT_TASK = '核查手术同意书等已签署';

const PLASTIC_PREOP_TASKS = [
  PLASTIC_SURGERY_NAME_CONFIRM_TASK,
  PLASTIC_CONSENT_TASK,
  '核查术前检查已完善并打印化验单',
  '核查入院病史已签字',
  '完成术前拍照',
];

const PLASTIC_SURGERY_TASKS = ['确认术中一助情况', '确认术中引流情况', '确认术中尿管情况', '确认标本病理情况'];

const PLASTIC_WORKFLOW = [
  { name: '术前', criticalTasks: PLASTIC_PREOP_TASKS },
  { name: '手术', criticalTasks: PLASTIC_SURGERY_TASKS },
  { name: '术后', criticalTasks: [] },
  { name: '出院', criticalTasks: ['完成出院记录、宣教与复诊安排'] },
  { name: '整理', criticalTasks: [] },
];

const DEFAULT_ROUND_ACTIONS = [
  { id: 'round-action-dressing', title: '换药', category: '查房', priority: '普通', effect: null },
  { id: 'round-action-stop-monitor', title: '停监护', category: '术后观察', priority: '普通', postoperativeOnly: true, effect: { key: 'monitoring', value: 'stopped' } },
  { id: 'round-action-stop-oxygen', title: '停吸氧', category: '术后观察', priority: '普通', postoperativeOnly: true, effect: { key: 'oxygen', value: 'stopped' } },
  { id: 'round-action-remove-catheter', title: '拔尿管', category: '术后观察', priority: '普通', postoperativeOnly: true, effect: { key: 'urinaryCatheter', value: 'removed' } },
  { id: 'round-action-blood-test', title: '复查血常规', category: '检查', priority: '普通', effect: null },
  { id: 'round-action-drain', title: '记录引流量', category: '术后观察', priority: '重要', postoperativeOnly: true, effect: null },
];

const DEFAULT_SETTINGS = {
  activeDepartment: '整形外科',
  departments: ['轮转通用', '整形外科', '普外科', '骨科', '泌尿外科', '妇产科', '神经外科'],
  procedures: ['未选择术式'],
  diagnoses: [],
  stages: DEFAULT_STAGES,
  taskCategories: ['查房', '检查', '沟通签字', '术前准备', '术后观察', '出院整理', '其他'],
  conditionTags: ['有引流', '留置导尿', '抗凝中'],
  roundActionTemplates: DEFAULT_ROUND_ACTIONS,
  departmentWorkflows: { 整形外科: PLASTIC_WORKFLOW },
  departmentTemplates: { 轮转通用: 'template-general-v2' },
  procedureTemplates: {},
  stageRequirements: {
    谈话: ['完成术前谈话', '确认知情同意签字'],
    术前: ['完成术前安全核查'],
    出院: ['完成出院记录、宣教与复诊安排'],
  },
  aiGatewayConfigured: false,
  clinicalPresetVersion: 2,
};

const DEFAULT_TEMPLATE = {
  id: 'template-general-v2',
  name: '轮转通用路径',
  department: '轮转通用',
  procedure: '',
  editable: true,
  rules: [
    {
      id: 'rule-preop-1', label: '术前 1 天', kind: 'relative', anchor: 'surgery', startDay: -1, endDay: -1,
      conditionTag: '', critical: true, tasks: ['确认术前谈话和签字', '核对术前检查与准备'],
    },
    {
      id: 'rule-pod-0', label: '术后 POD 0', kind: 'relative', anchor: 'surgery', startDay: 0, endDay: 0,
      conditionTag: '', critical: false, tasks: ['完成术后首次评估与观察'],
    },
    {
      id: 'rule-pod-1', label: '术后 POD 1', kind: 'relative', anchor: 'surgery', startDay: 1, endDay: 1,
      conditionTag: '', critical: false, tasks: ['查看术后检查结果', '确认引流、疼痛与活动计划'],
    },
    {
      id: 'rule-discharge', label: '出院阶段', kind: 'stage', stage: '出院', startDay: null, endDay: null,
      conditionTag: '', critical: true, tasks: ['核对出院记录、宣教与复诊安排'],
    },
  ],
};

function clone(value) {
  return JSON.parse(JSON.stringify(value));
}

function uniqueId(prefix) {
  return `${prefix}-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
}

export function todayKey(date = new Date()) {
  const year = date.getFullYear();
  const month = `${date.getMonth() + 1}`.padStart(2, '0');
  const day = `${date.getDate()}`.padStart(2, '0');
  return `${year}-${month}-${day}`;
}

function localDate(dateString) {
  if (!dateString) return null;
  const parts = `${dateString}`.slice(0, 10).split('-').map(Number);
  if (parts.length !== 3 || parts.some((item) => !Number.isFinite(item))) return null;
  return new Date(parts[0], parts[1] - 1, parts[2]);
}

function dayDifference(later, earlier) {
  const one = localDate(later);
  const two = localDate(earlier);
  if (!one || !two) return null;
  return Math.round((one.getTime() - two.getTime()) / 86400000);
}

function emptyWorkspace() {
  return {
    schemaVersion: SCHEMA_VERSION,
    settings: clone(DEFAULT_SETTINGS),
    patients: [],
    archivedPatients: [],
    rounds: [],
    tasks: [],
    taskDrafts: [],
    templates: [clone(DEFAULT_TEMPLATE)],
    stageLogs: [],
    devices: [],
    observations: [],
    clinicalEvents: [],
    pathologySpecimens: [],
    meta: { createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() },
  };
}

function normalizeRule(rule, index = 0) {
  if (rule.kind) {
    return {
      id: rule.id || uniqueId('rule'),
      label: rule.label || rule.timing || `规则 ${index + 1}`,
      kind: rule.kind,
      anchor: rule.anchor || 'surgery',
      startDay: rule.startDay === null || rule.startDay === undefined ? null : Number(rule.startDay),
      endDay: rule.endDay === null || rule.endDay === undefined ? null : Number(rule.endDay),
      stage: rule.stage || '',
      conditionTag: rule.conditionTag || '',
      critical: Boolean(rule.critical),
      tasks: Array.isArray(rule.tasks) ? rule.tasks.filter(Boolean) : [],
    };
  }
  const keyMap = {
    preop1: { startDay: -1, endDay: -1 },
    pod0: { startDay: 0, endDay: 0 },
    pod1: { startDay: 1, endDay: 1 },
  };
  if (rule.key === 'discharge') {
    return { id: uniqueId('rule'), label: rule.timing || '出院阶段', kind: 'stage', anchor: 'surgery', startDay: null, endDay: null, stage: '出院', conditionTag: '', critical: false, tasks: rule.tasks || [] };
  }
  const timing = keyMap[rule.key] || { startDay: 0, endDay: 0 };
  return { id: uniqueId('rule'), label: rule.timing || `规则 ${index + 1}`, kind: 'relative', anchor: 'surgery', ...timing, stage: '', conditionTag: '', critical: false, tasks: rule.tasks || [] };
}

function normalizeTemplate(template, index = 0) {
  return {
    id: template.id || uniqueId('template'),
    name: template.name || `路径模板 ${index + 1}`,
    department: template.department || '轮转通用',
    procedure: template.procedure || '',
    editable: template.editable !== false,
    rules: (template.rules || []).map(normalizeRule).filter((rule) => rule.tasks.length),
  };
}

function inferGender(patient) {
  if (patient.gender) return patient.gender;
  if (/(F|女)\s*$/i.test(patient.ageSex || '')) return '女';
  if (/(M|男)\s*$/i.test(patient.ageSex || '')) return '男';
  return '';
}

function inferAge(patient) {
  if (patient.age !== undefined && patient.age !== null) return (`${patient.age}`.match(/\d+/) || [''])[0];
  const match = `${patient.ageSex || ''}`.match(/\d+/);
  return match ? match[0] : '';
}

export function formatAgeSex(age, gender) {
  const sex = gender === '女' ? 'F' : gender === '男' ? 'M' : '';
  return [age ? `${age}岁` : '', sex].filter(Boolean).join(' / ');
}

function numericOnly(value) {
  const match = `${value || ''}`.match(/\d+/);
  return match ? match[0] : '';
}

function normalizePatient(patient, archived = false) {
  const gender = inferGender(patient);
  const age = inferAge(patient);
  const legacyConditions = Array.isArray(patient.conditions) ? patient.conditions : [];
  const existingPostop = patient.postopStatus || {};
  const existingIntraop = patient.intraopStatus || {};
  const department = patient.department || '轮转通用';
  const rawStage = patient.stage || '入院';
  const patientType = PLASTIC_PATIENT_TYPES.includes(patient.patientType) ? patient.patientType : '普通';
  return {
    id: `${patient.id || patient.hospitalId || uniqueId('patient')}`,
    name: patient.name || '',
    bed: numericOnly(patient.bed),
    age,
    gender,
    ageSex: formatAgeSex(age, gender),
    department,
    patientType,
    diagnosis: patient.diagnosis || '',
    admissionDate: patient.admissionDate || '',
    surgeryDate: patient.surgeryDate || '',
    surgeryName: patient.surgeryName || patient.procedure || '',
    confirmedSurgeryName: patient.confirmedSurgeryName || '',
    surgeryNameConfirmedAt: patient.surgeryNameConfirmedAt || '',
    surgeon: patient.surgeon || '',
    firstAssistant: patient.firstAssistant || '',
    templateId: patient.templateId || '',
    stage: department === '整形外科' && ['入院', '检查', '谈话'].includes(rawStage) ? '术前' : rawStage,
    conditions: legacyConditions.filter((item) => !['有引流', '留置导尿'].includes(item)),
    legacyDrainPresent: Boolean(patient.legacyDrainPresent || legacyConditions.includes('有引流')),
    postopStatus: {
      urinaryCatheter: existingPostop.urinaryCatheter || (legacyConditions.includes('留置导尿') ? 'present' : 'unknown'),
      monitoring: existingPostop.monitoring || 'unknown',
      oxygen: existingPostop.oxygen || 'unknown',
      antibiotic: existingPostop.antibiotic || 'unknown',
    },
    intraopStatus: {
      assistant: existingIntraop.assistant || 'unknown',
      drain: existingIntraop.drain || 'unknown',
      urinaryCatheter: existingIntraop.urinaryCatheter || 'unknown',
      pathology: existingIntraop.pathology || 'unknown',
    },
    workflowOverride: Array.isArray(patient.workflowOverride) ? patient.workflowOverride : [],
    archived: archived || Boolean(patient.archived),
    archivedAt: patient.archivedAt || '',
    createdAt: patient.createdAt || new Date().toISOString(),
    updatedAt: patient.updatedAt || new Date().toISOString(),
  };
}

function normalizeTask(task, patientId) {
  const dueAt = task.dueAt || (task.due && /^\d{4}-\d{2}-\d{2}/.test(task.due) ? task.due : todayKey());
  return {
    id: task.id || uniqueId('task'), patientId, title: task.title || '',
    category: task.category || '其他', priority: task.priority || '普通', dueAt,
    status: task.status || (task.done ? 'done' : 'todo'), source: task.source || '手动添加',
    sourceRef: task.sourceRef || '', stage: task.stage || '', critical: Boolean(task.critical), effect: task.effect || null,
    completionNote: task.completionNote || '', createdAt: task.createdAt || new Date().toISOString(),
    completedAt: task.completedAt || '',
  };
}

function normalizeRound(round, patientId) {
  return {
    id: round.id || uniqueId('round'), patientId, date: round.date || todayKey(),
    symptoms: round.symptoms || '', exam: round.exam || '', results: round.results || '',
    assessment: round.assessment || '', plan: round.plan || '', rawText: round.rawText || '',
    createdAt: round.createdAt || new Date().toISOString(), updatedAt: round.updatedAt || round.createdAt || new Date().toISOString(),
  };
}

function normalizeSettings(settings = {}) {
  const result = { ...clone(DEFAULT_SETTINGS), ...clone(settings) };
  ['departments', 'procedures', 'diagnoses', 'stages', 'taskCategories', 'conditionTags'].forEach((key) => {
    result[key] = Array.isArray(result[key]) ? Array.from(new Set(result[key].filter(Boolean))) : clone(DEFAULT_SETTINGS[key]);
  });
  if (!result.procedures.includes('未选择术式')) result.procedures.unshift('未选择术式');
  if (!result.departments.includes(result.activeDepartment)) result.activeDepartment = '整形外科';
  result.departmentWorkflows = result.departmentWorkflows || {};
  const plasticWorkflow = result.departmentWorkflows['整形外科'];
  if (Array.isArray(plasticWorkflow)) {
    result.departmentWorkflows['整形外科'] = plasticWorkflow.map((step) => ({
      ...step,
      criticalTasks: (step.criticalTasks || []).map((title) => title === '手术同意书名称已与主刀医生核实' ? PLASTIC_SURGERY_NAME_CONFIRM_TASK : title),
    }));
  }
  result.departmentTemplates = result.departmentTemplates || {};
  result.procedureTemplates = result.procedureTemplates || {};
  result.stageRequirements = result.stageRequirements || clone(DEFAULT_SETTINGS.stageRequirements);
  if (Number(settings.clinicalPresetVersion || 0) < 1) {
    if (!result.departments.includes('整形外科')) result.departments.splice(1, 0, '整形外科');
    result.departmentWorkflows['整形外科'] = clone(PLASTIC_WORKFLOW);
    delete result.departmentTemplates['整形外科'];
    result.clinicalPresetVersion = 1;
  }
  if (Number(settings.clinicalPresetVersion || 0) < 2) {
    const workflow = Array.isArray(result.departmentWorkflows['整形外科']) ? result.departmentWorkflows['整形外科'] : clone(PLASTIC_WORKFLOW);
    const surgeryStep = workflow.find((step) => step.name === '手术');
    if (surgeryStep) surgeryStep.criticalTasks = Array.from(new Set([...PLASTIC_SURGERY_TASKS, ...(surgeryStep.criticalTasks || [])]));
    result.departmentWorkflows['整形外科'] = workflow;
    result.clinicalPresetVersion = 2;
  }
  result.roundActionTemplates = (settings.roundActionTemplates || DEFAULT_ROUND_ACTIONS).map((item, index) => {
    if (typeof item === 'string') return { id: `round-action-custom-${index}`, title: item, category: '查房', priority: '普通', postoperativeOnly: false, effect: null };
    const preset = DEFAULT_ROUND_ACTIONS.find((candidate) => candidate.id === item.id) || {};
    return {
      id: item.id || uniqueId('round-action'), title: item.title || preset.title || '', category: item.category || preset.category || '查房',
      priority: item.priority || preset.priority || '普通',
      postoperativeOnly: item.postoperativeOnly === undefined ? Boolean(preset.postoperativeOnly) : Boolean(item.postoperativeOnly),
      effect: item.effect || preset.effect || null,
    };
  }).filter((item) => item.title);
  return result;
}

function normalizeDevice(device) {
  return {
    id: device.id || uniqueId('device'), patientId: device.patientId, type: device.type || 'drain',
    name: device.name || '引流', status: device.status || 'active',
    placedAt: device.placedAt || new Date().toISOString(), removedAt: device.removedAt || '',
  };
}

function normalizeObservation(observation) {
  return {
    id: observation.id || uniqueId('observation'), patientId: observation.patientId, deviceId: observation.deviceId,
    type: observation.type || 'drainVolume', value: Number(observation.value), unit: observation.unit || 'mL',
    recordedAt: observation.recordedAt || new Date().toISOString(),
  };
}

function normalizeClinicalEvent(event) {
  return {
    id: event.id || uniqueId('clinical-event'), patientId: event.patientId, type: event.type || '',
    value: event.value || '', note: event.note || '', at: event.at || new Date().toISOString(),
  };
}

function normalizePathologySpecimen(specimen) {
  return {
    id: specimen.id || uniqueId('specimen'), patientId: specimen.patientId,
    name: specimen.name || '手术标本', status: specimen.status || 'retained',
    note: specimen.note || '', createdAt: specimen.createdAt || new Date().toISOString(),
    updatedAt: specimen.updatedAt || specimen.createdAt || new Date().toISOString(),
  };
}

function isSeedDemoPatient(patient) {
  return /^DEMO-/.test(patient.id || '') && /界面演示/.test(patient.diagnosis || '');
}

function isPlasticSimulationPatient(patient) {
  return /^SIM-PLASTIC-/.test(patient.id || '');
}

function purgePlasticSimulationRecords(workspace) {
  const patientIds = new Set([...workspace.patients, ...workspace.archivedPatients].filter(isPlasticSimulationPatient).map((patient) => patient.id));
  if (!patientIds.size) return false;
  workspace.patients = workspace.patients.filter((patient) => !patientIds.has(patient.id));
  workspace.archivedPatients = workspace.archivedPatients.filter((patient) => !patientIds.has(patient.id));
  workspace.rounds = workspace.rounds.filter((item) => !patientIds.has(item.patientId));
  workspace.tasks = workspace.tasks.filter((item) => !patientIds.has(item.patientId));
  workspace.taskDrafts = workspace.taskDrafts.filter((item) => !patientIds.has(item.patientId));
  workspace.stageLogs = workspace.stageLogs.filter((item) => !patientIds.has(item.patientId));
  workspace.devices = workspace.devices.filter((item) => !patientIds.has(item.patientId));
  workspace.observations = workspace.observations.filter((item) => !patientIds.has(item.patientId));
  workspace.clinicalEvents = workspace.clinicalEvents.filter((item) => !patientIds.has(item.patientId));
  workspace.pathologySpecimens = workspace.pathologySpecimens.filter((item) => !patientIds.has(item.patientId));
  return true;
}

function migrateLegacy(legacy) {
  const workspace = emptyWorkspace();
  if (!legacy || !Array.isArray(legacy.patients)) return workspace;
  workspace.settings = normalizeSettings(legacy.settings);
  workspace.templates = (legacy.templates || []).filter((template) => !(template.id === 'template-postop' && /示例/.test(template.name || ''))).map(normalizeTemplate);
  if (!workspace.templates.length) workspace.templates = [clone(DEFAULT_TEMPLATE)];
  if (!workspace.templates.some((template) => template.id === workspace.settings.departmentTemplates['轮转通用'])) {
    const general = workspace.templates.find((template) => ['template-general', 'template-general-v2'].includes(template.id)) || workspace.templates[0];
    workspace.settings.departmentTemplates['轮转通用'] = general.id;
  }
  legacy.patients.filter((patient) => !isSeedDemoPatient(patient)).forEach((patient) => {
    workspace.patients.push(normalizePatient(patient));
    (patient.rounds || []).forEach((round) => workspace.rounds.push(normalizeRound(round, patient.id)));
    (patient.tasks || []).forEach((task) => workspace.tasks.push(normalizeTask(task, patient.id)));
    (patient.stageHistory || []).forEach((entry) => workspace.stageLogs.push({
      id: uniqueId('stage-log'), patientId: patient.id, fromStage: '', toStage: entry.stage,
      action: 'legacy', note: '', at: entry.at || new Date().toISOString(),
    }));
  });
  workspace.patients.forEach((patient) => stageRequirementTasks(workspace, patient, patient.stage));
  workspace.meta.migratedFrom = 1;
  workspace.meta.migratedAt = new Date().toISOString();
  return workspace;
}

function normalizeWorkspace(saved) {
  if (!saved || saved.schemaVersion !== SCHEMA_VERSION) return migrateLegacy(saved);
  const workspace = emptyWorkspace();
  workspace.settings = normalizeSettings(saved.settings);
  workspace.patients = (saved.patients || []).map((item) => normalizePatient(item, false));
  workspace.archivedPatients = (saved.archivedPatients || []).map((item) => normalizePatient(item, true));
  workspace.rounds = (saved.rounds || []).map((item) => normalizeRound(item, item.patientId));
  workspace.tasks = (saved.tasks || []).map((item) => normalizeTask(item, item.patientId));
  workspace.taskDrafts = Array.isArray(saved.taskDrafts) ? saved.taskDrafts : [];
  workspace.templates = (saved.templates || []).filter((template) => !(template.id === 'template-postop' && /示例/.test(template.name || ''))).map(normalizeTemplate);
  workspace.stageLogs = Array.isArray(saved.stageLogs) ? saved.stageLogs : [];
  workspace.devices = (saved.devices || []).map(normalizeDevice);
  workspace.observations = (saved.observations || []).map(normalizeObservation).filter((item) => Number.isFinite(item.value));
  workspace.clinicalEvents = (saved.clinicalEvents || []).map(normalizeClinicalEvent);
  workspace.pathologySpecimens = (saved.pathologySpecimens || []).map(normalizePathologySpecimen);
  workspace.meta = { ...workspace.meta, ...(saved.meta || {}) };
  purgePlasticSimulationRecords(workspace);
  if (!workspace.templates.length) workspace.templates = [clone(DEFAULT_TEMPLATE)];
  if (!workspace.templates.some((template) => template.id === workspace.settings.departmentTemplates['轮转通用'])) {
    const general = workspace.templates.find((template) => ['template-general', 'template-general-v2'].includes(template.id)) || workspace.templates[0];
    workspace.settings.departmentTemplates['轮转通用'] = general.id;
  }
  [...workspace.patients, ...workspace.archivedPatients].forEach((patient) => {
    if (patient.legacyDrainPresent && !workspace.devices.some((device) => device.patientId === patient.id && device.type === 'drain')) {
      workspace.devices.push(normalizeDevice({ patientId: patient.id, type: 'drain', name: '引流 1', status: 'active' }));
    }
  });
  return workspace;
}

export function getWorkspace() {
  const saved = wx.getStorageSync(STORAGE_KEY);
  if (saved && saved.schemaVersion === SCHEMA_VERSION) {
    const needsClinicalUpgrade = Number((saved.settings && saved.settings.clinicalPresetVersion) || 0) < 2;
    const hasPlasticSimulationData = [...(saved.patients || []), ...(saved.archivedPatients || [])].some(isPlasticSimulationPatient);
    const workspace = normalizeWorkspace(saved);
    if (needsClinicalUpgrade || hasPlasticSimulationData) {
      if (hasPlasticSimulationData) wx.setStorageSync(SIMULATION_CLEANUP_SNAPSHOT_KEY, clone(saved));
      workspace.patients.forEach((patient) => stageRequirementTasks(workspace, patient, patient.stage));
      return saveWorkspace(workspace);
    }
    return workspace;
  }
  const legacy = wx.getStorageSync(LEGACY_STORAGE_KEY);
  if (legacy) wx.setStorageSync(MIGRATION_SNAPSHOT_KEY, clone(legacy));
  const workspace = migrateLegacy(legacy);
  saveWorkspace(workspace);
  return workspace;
}

export function saveWorkspace(workspace) {
  const next = normalizeWorkspace({ ...workspace, schemaVersion: SCHEMA_VERSION });
  next.meta.updatedAt = new Date().toISOString();
  wx.setStorageSync(STORAGE_KEY, next);
  return next;
}

export function setActiveDepartment(department) {
  const workspace = getWorkspace();
  if (!workspace.settings.departments.includes(department)) return false;
  workspace.settings.activeDepartment = department;
  saveWorkspace(workspace);
  return true;
}

export function restoreWorkspace(workspace) {
  if (!workspace || !Array.isArray(workspace.patients) || !Array.isArray(workspace.templates)) throw new Error('备份数据结构不完整');
  wx.setStorageSync(RESTORE_SNAPSHOT_KEY, clone(getWorkspace()));
  const normalized = normalizeWorkspace(workspace);
  normalized.patients.forEach((patient) => stageRequirementTasks(normalized, patient, patient.stage));
  saveWorkspace(normalized);
  return normalized;
}

export function getBackupSummary(workspace) {
  return {
    schemaVersion: workspace.schemaVersion || 1,
    activePatients: (workspace.patients || []).length,
    archivedPatients: (workspace.archivedPatients || []).length,
    rounds: (workspace.rounds || []).length,
    tasks: (workspace.tasks || []).length,
    updatedAt: workspace.meta && workspace.meta.updatedAt ? workspace.meta.updatedAt : '',
  };
}

export function getPatient(id) {
  const workspace = getWorkspace();
  return workspace.patients.find((item) => item.id === id) || workspace.archivedPatients.find((item) => item.id === id);
}

export function getPatientRounds(patientId) {
  return getWorkspace().rounds.filter((item) => item.patientId === patientId).sort((a, b) => `${b.date}${b.createdAt}`.localeCompare(`${a.date}${a.createdAt}`));
}

export function getPatientTasks(patientId, includeDone = true) {
  return getWorkspace().tasks.filter((item) => item.patientId === patientId && (includeDone || item.status !== 'done'))
    .sort((a, b) => `${a.status}${a.dueAt}`.localeCompare(`${b.status}${b.dueAt}`));
}

export function getPatientBundle(id) {
  const patient = getPatient(id);
  if (!patient) return null;
  const workspace = getWorkspace();
  return {
    ...patient, rounds: getPatientRounds(id), tasks: getPatientTasks(id),
    stageLogs: workspace.stageLogs.filter((item) => item.patientId === id),
    devices: workspace.devices.filter((item) => item.patientId === id),
    observations: workspace.observations.filter((item) => item.patientId === id),
    clinicalEvents: workspace.clinicalEvents.filter((item) => item.patientId === id),
    pathologySpecimens: workspace.pathologySpecimens.filter((item) => item.patientId === id),
  };
}

function findPatientIdConflict(workspace, id, excludingId = '') {
  const active = workspace.patients.find((item) => item.id === id && item.id !== excludingId);
  if (active) return { ...active, archived: false };
  const archived = workspace.archivedPatients.find((item) => item.id === id && item.id !== excludingId);
  return archived ? { ...archived, archived: true } : null;
}

function duplicatePatientId(workspace, id, excludingId = '') {
  return Boolean(findPatientIdConflict(workspace, id, excludingId));
}

function stageRequirementTasks(workspace, patient, stage) {
  const workflow = getPatientFlow(patient, workspace);
  const step = workflow.find((item) => item.name === stage);
  const common = workspace.settings.stageRequirements[stage] || [];
  const hasDepartmentWorkflow = Boolean(workspace.settings.departmentWorkflows[patient.department]);
  const required = Array.from(new Set(hasDepartmentWorkflow ? (step && step.criticalTasks ? step.criticalTasks : []) : common));
  if (patient.department === '整形外科' && stage === '术前') {
    const oldTitle = '手术同意书名称已与主刀医生核实';
    const nextTitle = PLASTIC_SURGERY_NAME_CONFIRM_TASK;
    const oldTask = workspace.tasks.find((task) => task.patientId === patient.id && task.stage === stage && task.title === oldTitle);
    if (oldTask) {
      oldTask.title = nextTitle;
      oldTask.sourceRef = `stage:${stage}:${nextTitle}`;
    }
    const confirmationTask = workspace.tasks.find((task) => task.patientId === patient.id && task.stage === stage && task.title === nextTitle);
    if (confirmationTask && confirmationTask.status === 'done' && !`${patient.confirmedSurgeryName || ''}`.trim()) {
      confirmationTask.status = 'todo';
      confirmationTask.completedAt = '';
      confirmationTask.completionNote = '';
      patient.surgeryNameConfirmedAt = '';
      workspace.tasks.forEach((task) => {
        if (task.patientId === patient.id && task.stage === stage && task.title === PLASTIC_CONSENT_TASK) { task.status = 'todo'; task.completedAt = ''; task.completionNote = ''; }
      });
    } else if (confirmationTask && confirmationTask.status === 'done' && !patient.surgeryNameConfirmedAt) patient.surgeryNameConfirmedAt = confirmationTask.completedAt || new Date().toISOString();
  }
  if (patient.department === '整形外科' && stage === '术前' && /瘢痕疙瘩|瘢痕瘤|keloid/i.test(patient.diagnosis || '')) required.push('完成放疗科会诊');
  required.forEach((title) => {
    const sourceRef = `stage:${stage}:${title}`;
    if (!workspace.tasks.some((task) => task.patientId === patient.id && task.sourceRef === sourceRef)) {
      workspace.tasks.push(normalizeTask({
        id: uniqueId('task'), title, category: stage === '谈话' ? '沟通签字' : stage === '术前' ? '术前准备' : stage === '手术' ? '术后观察' : stage === '出院' ? '出院整理' : '其他',
        priority: '重要', dueAt: todayKey(), source: '阶段要求', sourceRef, stage, critical: true,
      }, patient.id));
    }
  });
}

export function createPatient(patient) {
  const workspace = getWorkspace();
  const id = `${patient.id || ''}`.trim();
  if (!id) return { ok: false, error: '请填写住院号或病案号' };
  const conflict = findPatientIdConflict(workspace, id);
  if (conflict) return { ok: false, error: `该住院号已存在于${conflict.archived ? '归档' : '在院'}患者（${conflict.department || '未分配科室'}），请先搜索核对` };
  const normalized = normalizePatient({ ...patient, id });
  workspace.patients.unshift(normalized);
  stageRequirementTasks(workspace, normalized, normalized.stage);
  saveWorkspace(workspace);
  return { ok: true, patient: normalized };
}

export function updatePatient(patientId, changes) {
  const workspace = getWorkspace();
  const patient = workspace.patients.find((item) => item.id === patientId);
  if (!patient) return { ok: false, error: '未找到可编辑的在院患者' };
  const nextId = `${changes.id || patient.id}`.trim();
  const conflict = nextId !== patientId ? findPatientIdConflict(workspace, nextId, patientId) : null;
  if (conflict) return { ok: false, error: `该住院号已存在于${conflict.archived ? '归档' : '在院'}患者（${conflict.department || '未分配科室'}），请先搜索核对` };
  const previousSurgeryName = patient.surgeryName;
  const previousSurgeon = patient.surgeon;
  Object.assign(patient, normalizePatient({ ...patient, ...changes, id: nextId, updatedAt: new Date().toISOString() }));
  if (patient.department === '整形外科' && (patient.surgeryName !== previousSurgeryName || patient.surgeon !== previousSurgeon)) {
    patient.confirmedSurgeryName = '';
    patient.surgeryNameConfirmedAt = '';
    workspace.tasks.forEach((task) => {
      if (task.patientId !== patientId || task.stage !== '术前' || ![PLASTIC_SURGERY_NAME_CONFIRM_TASK, PLASTIC_CONSENT_TASK].includes(task.title)) return;
      task.status = 'todo';
      task.completedAt = '';
      task.completionNote = '';
    });
  }
  stageRequirementTasks(workspace, patient, patient.stage);
  if (nextId !== patientId) {
    workspace.rounds.forEach((item) => { if (item.patientId === patientId) item.patientId = nextId; });
    workspace.tasks.forEach((item) => { if (item.patientId === patientId) item.patientId = nextId; });
    workspace.taskDrafts.forEach((item) => { if (item.patientId === patientId) item.patientId = nextId; });
    workspace.stageLogs.forEach((item) => { if (item.patientId === patientId) item.patientId = nextId; });
    workspace.devices.forEach((item) => { if (item.patientId === patientId) item.patientId = nextId; });
    workspace.observations.forEach((item) => { if (item.patientId === patientId) item.patientId = nextId; });
    workspace.clinicalEvents.forEach((item) => { if (item.patientId === patientId) item.patientId = nextId; });
    workspace.pathologySpecimens.forEach((item) => { if (item.patientId === patientId) item.patientId = nextId; });
  }
  saveWorkspace(workspace);
  return { ok: true, patient };
}

export function archivePatient(patientId) {
  const workspace = getWorkspace();
  const index = workspace.patients.findIndex((item) => item.id === patientId);
  if (index < 0) return { ok: false, error: '未找到在院患者' };
  const patient = workspace.patients[index];
  if (!['出院', '整理'].includes(patient.stage)) return { ok: false, error: '患者进入出院或整理阶段后才能归档' };
  const blockers = workspace.tasks.filter((task) => task.patientId === patientId && task.stage === '出院' && task.critical && task.status !== 'done');
  if (blockers.length) return { ok: false, error: '请先完成出院关键项', blockers };
  workspace.patients.splice(index, 1);
  patient.archived = true;
  patient.archivedAt = new Date().toISOString();
  workspace.archivedPatients.unshift(patient);
  workspace.stageLogs.unshift({ id: uniqueId('stage-log'), patientId, fromStage: patient.stage, toStage: patient.stage, action: 'archive', note: '', at: patient.archivedAt });
  saveWorkspace(workspace);
  return { ok: true };
}

export function saveRound(patientId, round) {
  const workspace = getWorkspace();
  if (!workspace.patients.some((item) => item.id === patientId)) return { ok: false, error: '未找到在院患者' };
  const savedRound = normalizeRound({ ...round, id: round.id || uniqueId('round'), createdAt: round.createdAt || new Date().toISOString(), updatedAt: new Date().toISOString() }, patientId);
  const existingIndex = workspace.rounds.findIndex((item) => item.id === savedRound.id);
  if (existingIndex >= 0) workspace.rounds[existingIndex] = savedRound;
  else workspace.rounds.unshift(savedRound);
  saveWorkspace(workspace);
  return { ok: true, round: savedRound };
}

export function addTask(patientId, task) {
  const workspace = getWorkspace();
  if (!workspace.patients.some((item) => item.id === patientId)) return { ok: false, error: '归档患者不能新增任务' };
  const payload = typeof task === 'string' ? { title: task } : task;
  if (!payload.title || !payload.title.trim()) return { ok: false, error: '任务标题不能为空' };
  if (payload.sourceRef && workspace.tasks.some((item) => item.patientId === patientId && item.sourceRef === payload.sourceRef)) {
    return { ok: false, error: '相同来源的任务已存在' };
  }
  const { id: ignoredTaskId, ...taskPayload } = payload;
  const saved = normalizeTask({ ...taskPayload, id: uniqueId('task'), dueAt: taskPayload.dueAt || todayKey(), category: taskPayload.category || '其他', priority: taskPayload.priority || '普通', source: taskPayload.source || '手动添加' }, patientId);
  workspace.tasks.unshift(saved);
  saveWorkspace(workspace);
  return { ok: true, task: saved };
}

export function addTasksFromDrafts(patientId, drafts, sourceRef = '') {
  const results = [];
  (drafts || []).forEach((draft, index) => {
    if (draft.selected === false) return;
    results.push(addTask(patientId, {
      title: draft.title, category: draft.category || '其他', priority: draft.priority || '普通',
      dueAt: draft.dueAt || todayKey(), source: draft.source || '查房建议',
      sourceRef: draft.sourceRef || `${sourceRef}:${index}:${draft.title}`, stage: draft.stage || '', critical: Boolean(draft.critical),
    }));
  });
  return results;
}

export function setTaskDone(patientId, taskId, done, completionNote = '') {
  const workspace = getWorkspace();
  const task = workspace.tasks.find((item) => item.patientId === patientId && item.id === taskId);
  const patient = workspace.patients.find((item) => item.id === patientId);
  if (!task || !patient) return { ok: false, error: '未找到可完成的任务' };
  if (done && task.title === PLASTIC_SURGERY_NAME_CONFIRM_TASK && !`${patient.confirmedSurgeryName || ''}`.trim()) return { ok: false, error: '请先录入与主刀确认后的正式术式名称' };
  if (done && task.title === PLASTIC_CONSENT_TASK && (!patient.surgeryNameConfirmedAt || !`${patient.confirmedSurgeryName || ''}`.trim())) return { ok: false, error: '请先完成与主刀确认手术名称' };
  task.status = done ? 'done' : 'todo';
  task.completionNote = done ? completionNote.trim() : '';
  task.completedAt = done ? new Date().toISOString() : '';
  if (task.title === PLASTIC_SURGERY_NAME_CONFIRM_TASK) {
    patient.surgeryNameConfirmedAt = done ? task.completedAt : '';
    if (!done) patient.confirmedSurgeryName = '';
    if (!done) {
      workspace.tasks.forEach((item) => {
        if (item.patientId === patientId && item.stage === '术前' && item.title === PLASTIC_CONSENT_TASK) {
          item.status = 'todo';
          item.completedAt = '';
          item.completionNote = '';
        }
      });
    }
  }
  if (done && task.effect && task.effect.key) {
    const patient = workspace.patients.find((item) => item.id === patientId);
    if (patient) patient.postopStatus[task.effect.key] = task.effect.value;
  }
  saveWorkspace(workspace);
  return { ok: true };
}

export function toggleTask(patientId, taskId) {
  const task = getWorkspace().tasks.find((item) => item.patientId === patientId && item.id === taskId);
  return task ? setTaskDone(patientId, taskId, task.status !== 'done') : false;
}

export function addTemplate(template) {
  const workspace = getWorkspace();
  const saved = normalizeTemplate({ id: uniqueId('template'), editable: true, ...template });
  workspace.templates.unshift(saved);
  saveWorkspace(workspace);
  return saved;
}

export function updateTemplate(templateId, changes) {
  const workspace = getWorkspace();
  const index = workspace.templates.findIndex((item) => item.id === templateId);
  if (index < 0) return false;
  workspace.templates[index] = normalizeTemplate({ ...workspace.templates[index], ...changes, id: templateId, editable: true });
  saveWorkspace(workspace);
  return true;
}

export function setTemplateAssignment(type, name, templateId) {
  const workspace = getWorkspace();
  const key = type === 'procedure' ? 'procedureTemplates' : 'departmentTemplates';
  if (!templateId) return false;
  Object.keys(workspace.settings[key]).forEach((item) => { if (workspace.settings[key][item] === templateId) delete workspace.settings[key][item]; });
  if (name) workspace.settings[key][name] = templateId;
  saveWorkspace(workspace);
  return true;
}

export function addSettingItem(category, value) {
  const workspace = getWorkspace();
  const list = workspace.settings[category];
  if (!Array.isArray(list) || list.includes(value)) return false;
  list.push(value);
  saveWorkspace(workspace);
  return true;
}

export function removeSettingItem(category, value) {
  const workspace = getWorkspace();
  const list = workspace.settings[category];
  if (!Array.isArray(list)) return { ok: false, error: '该设置项不存在' };
  if (!list.includes(value)) return { ok: false, error: '该设置项不存在' };
  if (category === 'departments') {
    if (workspace.settings.activeDepartment === value) return { ok: false, error: '请先切换当前工作科室，再移除' };
    if ([...workspace.patients, ...workspace.archivedPatients].some((patient) => patient.department === value)) return { ok: false, error: '该科室仍有关联患者，请先调整患者归属' };
    delete workspace.settings.departmentWorkflows[value];
    delete workspace.settings.departmentTemplates[value];
  }
  if (category === 'stages') {
    const affected = workspace.patients.some((patient) => !workspace.settings.departmentWorkflows[patient.department] && patient.stage === value);
    if (affected) return { ok: false, error: '有在院患者正处于该通用阶段，暂不能移除' };
    delete workspace.settings.stageRequirements[value];
  }
  workspace.settings[category] = list.filter((item) => item !== value);
  saveWorkspace(workspace);
  return { ok: true };
}

export function saveDepartmentWorkflow(department, stages) {
  const workspace = getWorkspace();
  if (!department || !workspace.settings.departments.includes(department)) return { ok: false, error: '未找到该科室' };
  if (!Array.isArray(stages) || !stages.length) return { ok: false, error: '请至少保留一个阶段' };
  const normalizedStages = stages.map((item) => ({
    name: `${item.name || ''}`.trim(), criticalTasks: Array.from(new Set((Array.isArray(item.criticalTasks) ? item.criticalTasks : []).map((task) => `${task || ''}`.trim()).filter(Boolean))),
  })).filter((item) => item.name);
  if (!normalizedStages.length) return { ok: false, error: '请至少保留一个有效阶段' };
  const names = normalizedStages.map((item) => item.name);
  if (new Set(names).size !== names.length) return { ok: false, error: '阶段名称不能重复' };
  const unavailableStage = workspace.patients.find((patient) => patient.department === department && !names.includes(patient.stage));
  if (unavailableStage) return { ok: false, error: `在院患者仍处于“${unavailableStage.stage}”，请保留该阶段或先完成患者阶段调整` };
  workspace.settings.departmentWorkflows[department] = normalizedStages;
  workspace.patients.filter((patient) => patient.department === department).forEach((patient) => {
    const current = normalizedStages.find((stage) => stage.name === patient.stage);
    const expected = new Set((current ? current.criticalTasks : []).concat(patient.stage === '术前' && /瘢痕疙瘩|瘢痕瘤|keloid/i.test(patient.diagnosis || '') ? ['完成放疗科会诊'] : []));
    workspace.tasks.filter((task) => task.patientId === patient.id && task.stage === patient.stage && task.sourceRef && task.sourceRef.startsWith(`stage:${patient.stage}:`)).forEach((task) => {
      if (expected.has(task.title)) { task.critical = true; task.source = '阶段要求'; }
      else if (task.status !== 'done') { task.critical = false; task.source = '已取消的阶段要求'; }
    });
    stageRequirementTasks(workspace, patient, patient.stage);
  });
  saveWorkspace(workspace);
  return { ok: true };
}

export function getPatientFlow(patient, suppliedWorkspace) {
  const workspace = suppliedWorkspace || getWorkspace();
  if (patient.workflowOverride && patient.workflowOverride.length) return patient.workflowOverride.map((item) => typeof item === 'string' ? { name: item, criticalTasks: [] } : item);
  const departmentFlow = workspace.settings.departmentWorkflows[patient.department];
  if (departmentFlow && departmentFlow.length) return departmentFlow;
  return workspace.settings.stages.map((name) => ({ name, criticalTasks: [] }));
}

export function ensureStageTasks(patientId) {
  const workspace = getWorkspace();
  const patient = workspace.patients.find((item) => item.id === patientId);
  if (!patient) return;
  const before = workspace.tasks.length;
  stageRequirementTasks(workspace, patient, patient.stage);
  if (workspace.tasks.length !== before) saveWorkspace(workspace);
}

export function getStageBlockers(patientId) {
  const workspace = getWorkspace();
  const patient = workspace.patients.find((item) => item.id === patientId);
  if (!patient) return [];
  return workspace.tasks.filter((task) => task.patientId === patientId && task.stage === patient.stage && task.critical && task.status !== 'done');
}

export function changePatientStage(patientId, nextStage, note = '') {
  const workspace = getWorkspace();
  const patient = workspace.patients.find((item) => item.id === patientId);
  if (!patient) return { ok: false, error: '未找到在院患者' };
  const flow = getPatientFlow(patient, workspace).map((item) => item.name);
  const currentIndex = flow.indexOf(patient.stage);
  const nextIndex = flow.indexOf(nextStage);
  if (nextIndex < 0) return { ok: false, error: '目标阶段不在当前科室流程中' };
  if (currentIndex >= 0 && nextIndex > currentIndex + 1) return { ok: false, error: '请按流程顺序逐步推进' };
  if (nextIndex > currentIndex) {
    const pendingSuggestions = getPatientReminders(patient).filter((reminder) => reminder.critical && reminder.stage === patient.stage)
      .filter((reminder) => !workspace.tasks.some((task) => task.patientId === patientId && task.sourceRef === reminder.sourceRef && task.status === 'done'))
      .map((reminder) => ({ ...reminder, id: reminder.id, status: 'todo' }));
    const blockers = [
      ...workspace.tasks.filter((task) => task.patientId === patientId && task.stage === patient.stage && task.critical && task.status !== 'done'),
      ...pendingSuggestions,
    ];
    if (patient.department === '整形外科' && patient.stage === '术前' && (!patient.surgeryNameConfirmedAt || !`${patient.confirmedSurgeryName || ''}`.trim())) blockers.push({ title: '录入与主刀确认后的正式手术名称' });
    if (patient.stage === '手术') {
      if (patient.intraopStatus.assistant === 'unknown') blockers.push({ title: '确认术中一助情况' });
      if (patient.intraopStatus.assistant === 'present' && !`${patient.firstAssistant || ''}`.trim()) blockers.push({ title: '补充一助医生姓名' });
      if (patient.intraopStatus.drain === 'unknown') blockers.push({ title: '确认术中引流情况' });
      if (patient.intraopStatus.drain === 'present' && !workspace.devices.some((item) => item.patientId === patientId && item.type === 'drain')) blockers.push({ title: '补充术中引流项目' });
      if (patient.intraopStatus.urinaryCatheter === 'unknown') blockers.push({ title: '确认术中尿管情况' });
      if (patient.intraopStatus.pathology === 'unknown') blockers.push({ title: '确认标本病理情况' });
      if (patient.intraopStatus.pathology === 'present' && !workspace.pathologySpecimens.some((item) => item.patientId === patientId)) blockers.push({ title: '补充标本病理项目' });
    }
    if (blockers.length) return { ok: false, error: '请先完成当前阶段的关键项目', blockers };
  }
  const fromStage = patient.stage;
  patient.stage = nextStage;
  patient.updatedAt = new Date().toISOString();
  workspace.stageLogs.unshift({
    id: uniqueId('stage-log'), patientId, fromStage, toStage: nextStage,
    action: nextIndex < currentIndex ? 'rollback' : 'advance', note: note.trim(), at: new Date().toISOString(),
  });
  stageRequirementTasks(workspace, patient, nextStage);
  saveWorkspace(workspace);
  return { ok: true };
}

export function updatePatientStage(patientId, stage, note = '') {
  return changePatientStage(patientId, stage, note);
}

export function getTemplateForPatient(patient) {
  const workspace = getWorkspace();
  const direct = patient.templateId && workspace.templates.find((item) => item.id === patient.templateId);
  if (direct) return direct;
  const procedureTemplateId = workspace.settings.procedureTemplates[patient.surgeryName];
  const byProcedure = procedureTemplateId && workspace.templates.find((item) => item.id === procedureTemplateId);
  if (byProcedure) return byProcedure;
  const departmentTemplateId = workspace.settings.departmentTemplates[patient.department];
  return (departmentTemplateId && workspace.templates.find((item) => item.id === departmentTemplateId)) || null;
}

export function getPOD(surgeryDate, referenceDate = todayKey()) {
  if (!surgeryDate) return null;
  return dayDifference(referenceDate, surgeryDate);
}

export function isPostoperative(patient, referenceDate = todayKey()) {
  if (!patient) return false;
  return ['术后', '出院', '整理'].includes(patient.stage);
}

export function isIntraoperativeOrLater(patient, referenceDate = todayKey()) {
  if (!patient) return false;
  return ['手术', '术后', '出院', '整理'].includes(patient.stage);
}

export function getEffectiveConditions(patient, suppliedWorkspace) {
  const workspace = suppliedWorkspace || getWorkspace();
  const conditions = new Set(patient.conditions || []);
  if (workspace.devices.some((device) => device.patientId === patient.id && device.type === 'drain' && device.status === 'active')) conditions.add('有引流');
  if (patient.postopStatus && patient.postopStatus.urinaryCatheter === 'present') conditions.add('留置导尿');
  return Array.from(conditions);
}

function ruleApplies(rule, patient, referenceDate) {
  if (rule.conditionTag && !getEffectiveConditions(patient).includes(rule.conditionTag)) return false;
  if (rule.kind === 'stage') return patient.stage === rule.stage;
  if (rule.kind === 'relative' && rule.anchor === 'surgery') {
    const pod = getPOD(patient.surgeryDate, referenceDate);
    if (pod === null) return false;
    const start = Number(rule.startDay);
    const end = rule.endDay === null || rule.endDay === undefined ? start : Number(rule.endDay);
    return pod >= Math.min(start, end) && pod <= Math.max(start, end);
  }
  return false;
}

export function getPatientReminders(patient, referenceDate = todayKey()) {
  const template = getTemplateForPatient(patient);
  const templateReminders = template ? template.rules.filter((rule) => ruleApplies(rule, patient, referenceDate)).flatMap((rule) =>
    rule.tasks.map((title, index) => ({
      id: `${rule.id}-${index}`, title, timing: rule.label, ruleId: rule.id,
      category: rule.kind === 'stage' && rule.stage === '出院' ? '出院整理' : Number(rule.startDay) >= 0 ? '术后观察' : '术前准备',
      priority: rule.critical ? '重要' : '普通', critical: rule.critical,
      stage: rule.kind === 'stage' ? rule.stage : Number(rule.startDay) < 0 ? '术前' : '术后',
      sourceRef: `rule:${rule.id}:${referenceDate}:${index}`,
    }))
  ) : [];
  if (!isPostoperative(patient, referenceDate)) return templateReminders;
  const workspace = getWorkspace();
  const start = `${referenceDate}T00:00:00`;
  const end = `${referenceDate}T23:59:59`;
  const deviceReminders = workspace.devices
    .filter((device) => device.patientId === patient.id && device.type === 'drain' && device.status === 'active')
    .filter((device) => !workspace.observations.some((item) => item.deviceId === device.id && item.recordedAt >= start && item.recordedAt <= end))
    .map((device) => ({
      id: `drain-${device.id}-${referenceDate}`, title: `记录${device.name}今日引流量`, timing: '术后重点指标',
      category: '术后观察', priority: '重要', critical: false, stage: '术后',
      sourceRef: `drain:${device.id}:${referenceDate}`,
    }));
  const statusDefinitions = [
    { key: 'urinaryCatheter', title: '确认尿管状态' },
    { key: 'antibiotic', title: '确认抗生素使用状态' },
  ];
  const statusReminders = statusDefinitions.filter((item) => patient.postopStatus && patient.postopStatus[item.key] === 'unknown').map((item) => ({
    id: `status-${item.key}-${patient.id}-${referenceDate}`, title: item.title, timing: '术后重点指标',
    category: '术后观察', priority: '普通', critical: false, stage: '术后',
    sourceRef: `status:${item.key}:${patient.id}:${referenceDate}`,
  }));
  return [...templateReminders, ...deviceReminders, ...statusReminders];
}

export function addReminderAsTask(patientId, reminder) {
  return addTask(patientId, { ...reminder, dueAt: todayKey(), source: '路径建议' });
}

export function addRoundActionTemplate(title) {
  const value = `${title || ''}`.trim();
  if (!value) return false;
  const workspace = getWorkspace();
  if (workspace.settings.roundActionTemplates.some((item) => item.title === value)) return false;
  workspace.settings.roundActionTemplates.push({ id: uniqueId('round-action'), title: value, category: '查房', priority: '普通', effect: null });
  saveWorkspace(workspace);
  return true;
}

export function removeRoundActionTemplate(id) {
  const workspace = getWorkspace();
  const before = workspace.settings.roundActionTemplates.length;
  workspace.settings.roundActionTemplates = workspace.settings.roundActionTemplates.filter((item) => item.id !== id);
  if (workspace.settings.roundActionTemplates.length === before) return false;
  saveWorkspace(workspace);
  return true;
}

export function addRoundActionTask(patientId, actionId) {
  const workspace = getWorkspace();
  const action = workspace.settings.roundActionTemplates.find((item) => item.id === actionId);
  if (!action) return { ok: false, error: '未找到快捷操作' };
  const patient = workspace.patients.find((item) => item.id === patientId);
  if (action.postoperativeOnly && !isPostoperative(patient)) return { ok: false, error: '该操作仅在术后可用' };
  return addTask(patientId, {
    title: action.title, category: action.category, priority: action.priority, effect: action.effect,
    dueAt: todayKey(), source: '查房快捷操作', sourceRef: `round-action:${action.id}:${todayKey()}`,
  });
}

export function addDrain(patientId, name) {
  const workspace = getWorkspace();
  const patient = workspace.patients.find((item) => item.id === patientId);
  if (!patient) return { ok: false, error: '未找到在院患者' };
  if (!isIntraoperativeOrLater(patient)) return { ok: false, error: '进入手术阶段后才能添加引流' };
  const device = normalizeDevice({ patientId, name: `${name || ''}`.trim() || `引流 ${workspace.devices.filter((item) => item.patientId === patientId && item.type === 'drain').length + 1}` });
  workspace.devices.push(device);
  patient.intraopStatus.drain = 'present';
  syncIntraopTask(workspace, patient, 'drain');
  saveWorkspace(workspace);
  return { ok: true, device };
}

export function recordDrainVolume(patientId, deviceId, value, recordedAt = new Date().toISOString()) {
  const number = Number(value);
  if (!Number.isFinite(number) || number < 0) return { ok: false, error: '请输入有效的非负引流量' };
  const workspace = getWorkspace();
  const patient = workspace.patients.find((item) => item.id === patientId);
  const device = workspace.devices.find((item) => item.id === deviceId && item.patientId === patientId && item.type === 'drain');
  if (!patient || !device) return { ok: false, error: '未找到引流项目' };
  if (!isPostoperative(patient)) return { ok: false, error: '手术后才能记录引流量' };
  const observation = normalizeObservation({ patientId, deviceId, value: number, recordedAt });
  workspace.observations.push(observation);
  saveWorkspace(workspace);
  return { ok: true, observation };
}

export function setDrainStatus(patientId, deviceId, status) {
  const workspace = getWorkspace();
  const device = workspace.devices.find((item) => item.id === deviceId && item.patientId === patientId && item.type === 'drain');
  if (!device) return false;
  device.status = status === 'removed' ? 'removed' : 'active';
  device.removedAt = device.status === 'removed' ? new Date().toISOString() : '';
  workspace.clinicalEvents.push(normalizeClinicalEvent({ patientId, type: 'drain-status', value: device.status, note: device.name }));
  saveWorkspace(workspace);
  return true;
}

export function setPostopStatus(patientId, key, value) {
  if (!['urinaryCatheter', 'monitoring', 'oxygen', 'antibiotic'].includes(key)) return { ok: false, error: '未知状态类型' };
  const workspace = getWorkspace();
  const patient = workspace.patients.find((item) => item.id === patientId);
  if (!patient) return { ok: false, error: '未找到在院患者' };
  if (!isPostoperative(patient)) return { ok: false, error: '手术后才能设置该状态' };
  patient.postopStatus[key] = value;
  patient.updatedAt = new Date().toISOString();
  workspace.clinicalEvents.push(normalizeClinicalEvent({ patientId, type: key, value }));
  saveWorkspace(workspace);
  return { ok: true };
}

function syncIntraopTask(workspace, patient, key) {
  const titleMap = { assistant: '确认术中一助情况', drain: '确认术中引流情况', urinaryCatheter: '确认术中尿管情况', pathology: '确认标本病理情况' };
  const title = titleMap[key];
  const task = workspace.tasks.find((item) => item.patientId === patient.id && item.stage === '手术' && item.title === title);
  if (!task) return;
  const status = patient.intraopStatus[key];
  const hasDetail = key === 'assistant'
    ? Boolean(`${patient.firstAssistant || ''}`.trim())
    : key === 'drain'
    ? workspace.devices.some((item) => item.patientId === patient.id && item.type === 'drain')
    : key === 'pathology'
    ? workspace.pathologySpecimens.some((item) => item.patientId === patient.id)
    : true;
  const done = status === 'none' || (status === 'present' && hasDetail);
  task.status = done ? 'done' : 'todo';
  task.completedAt = done ? new Date().toISOString() : '';
}

export function setIntraopStatus(patientId, key, value) {
  if (!['assistant', 'drain', 'urinaryCatheter', 'pathology'].includes(key) || !['unknown', 'none', 'present'].includes(value)) return { ok: false, error: '未知术中状态' };
  const workspace = getWorkspace();
  const patient = workspace.patients.find((item) => item.id === patientId);
  if (!patient) return { ok: false, error: '未找到在院患者' };
  if (!isIntraoperativeOrLater(patient)) return { ok: false, error: '进入手术阶段后才能记录' };
  if (value === 'none' && key === 'drain' && workspace.devices.some((item) => item.patientId === patientId && item.type === 'drain')) return { ok: false, error: '已有引流项目，不能选择无引流' };
  if (value === 'none' && key === 'pathology' && workspace.pathologySpecimens.some((item) => item.patientId === patientId)) return { ok: false, error: '已有标本记录，不能选择无标本' };
  if (value === 'none' && key === 'assistant' && `${patient.firstAssistant || ''}`.trim()) return { ok: false, error: '已填写一助姓名，不能选择无一助' };
  patient.intraopStatus[key] = value;
  if (key === 'urinaryCatheter') {
    patient.postopStatus.urinaryCatheter = value === 'present' ? 'present' : value === 'none' ? 'none' : 'unknown';
    workspace.clinicalEvents.push(normalizeClinicalEvent({ patientId, type: 'urinaryCatheter', value: patient.postopStatus.urinaryCatheter, note: '术中交接' }));
  }
  patient.updatedAt = new Date().toISOString();
  syncIntraopTask(workspace, patient, key);
  saveWorkspace(workspace);
  return { ok: true };
}

export function addPathologySpecimen(patientId, name) {
  const workspace = getWorkspace();
  const patient = workspace.patients.find((item) => item.id === patientId);
  if (!patient) return { ok: false, error: '未找到在院患者' };
  if (!isIntraoperativeOrLater(patient)) return { ok: false, error: '进入手术阶段后才能记录标本' };
  const specimen = normalizePathologySpecimen({ patientId, name: `${name || ''}`.trim() || '手术标本' });
  workspace.pathologySpecimens.push(specimen);
  patient.intraopStatus.pathology = 'present';
  syncIntraopTask(workspace, patient, 'pathology');
  saveWorkspace(workspace);
  return { ok: true, specimen };
}

export function setPathologyStatus(patientId, specimenId, status) {
  if (!['retained', 'sent', 'resulted'].includes(status)) return false;
  const workspace = getWorkspace();
  const specimen = workspace.pathologySpecimens.find((item) => item.patientId === patientId && item.id === specimenId);
  if (!specimen) return false;
  specimen.status = status;
  specimen.updatedAt = new Date().toISOString();
  saveWorkspace(workspace);
  return true;
}

export function addClinicalEvent(patientId, type, note) {
  const value = `${note || ''}`.trim();
  if (!value) return { ok: false, error: '请填写记录内容' };
  const workspace = getWorkspace();
  if (!workspace.patients.some((item) => item.id === patientId)) return { ok: false, error: '未找到在院患者' };
  const event = normalizeClinicalEvent({ patientId, type, value });
  workspace.clinicalEvents.push(event);
  saveWorkspace(workspace);
  return { ok: true, event };
}

export function taskBucket(task, referenceDate = todayKey()) {
  const due = `${task.dueAt || referenceDate}`.slice(0, 10);
  if (due < referenceDate) return 'overdue';
  if (due === referenceDate) return 'today';
  return 'upcoming';
}

export function getActiveTasks() {
  const workspace = getWorkspace();
  const activeIds = new Set(workspace.patients.map((item) => item.id));
  return workspace.tasks.filter((item) => activeIds.has(item.patientId) && item.status !== 'done');
}

export function maskPatient(patient) {
  if (!patient) return patient;
  const rawName = patient.name || '';
  const rawId = patient.id || '';
  const name = rawName.length > 1 ? `${rawName.slice(0, 1)}*${rawName.slice(-1)}` : rawName || '未命名';
  const id = rawId.length > 4 ? `${rawId.slice(0, 2)}****${rawId.slice(-2)}` : rawId;
  const gender = inferGender(patient);
  const genderClass = gender === '女' ? 'female' : gender === '男' ? 'male' : '';
  const patientType = PLASTIC_PATIENT_TYPES.includes(patient.patientType) ? patient.patientType : '普通';
  const patientTypeClass = patientType === '国疗' ? 'type-national' : patientType === '日间' ? 'type-day' : 'type-general';
  return { ...patient, gender, genderClass, patientType, patientTypeClass, displayName: name, displayId: id, ageSex: formatAgeSex(inferAge(patient), gender) };
}

export function workspaceStorageKeys() {
  return { current: STORAGE_KEY, legacy: LEGACY_STORAGE_KEY, migrationSnapshot: MIGRATION_SNAPSHOT_KEY, restoreSnapshot: RESTORE_SNAPSHOT_KEY };
}
