import assert from 'node:assert/strict';
import fs from 'node:fs';

const sourcePath = new URL('../utils/admission-import.js', import.meta.url);
const source = fs.readFileSync(sourcePath, 'utf8');
const importer = await import(`data:text/javascript;base64,${Buffer.from(source).toString('base64')}`);
const today = '2026-08-09';
const options = { today, activeDepartment: '整形外科', departments: ['整形外科', '骨科'], existingPatients: [{ id: 'EXISTS-001' }] };

const prompt = importer.getAdmissionImportPrompt(today);
assert.match(prompt, /本次处理日期：2026-08-09（北京时间）/);
assert.match(prompt, /无法确认其中任一条件时，直接排除/);
assert.match(prompt, /若材料明确写有“X术”/);

const valid = importer.parseAdmissionImport(JSON.stringify({
  schema: importer.ADMISSION_IMPORT_SCHEMA,
  department: '整形外科',
  patients: [{ id: 'NEW-001', name: '测试患者', bed: '12', age: '32', gender: '女', admissionDate: today, surgeon: '测试主刀', firstAssistant: '', patientType: '普通', diagnosis: '', allergies: '', surgeryDate: '', dischargeDate: '', surgeryName: '', managedByDaihuanyu: true }],
}), options);
assert.equal(valid.ok, true);
assert.equal(valid.summary.ready, 1);
assert.equal(valid.candidates[0].patient.department, '整形外科');
assert.equal(importer.buildAdmissionPatient(valid.candidates[0], today).stage, '入院');

const blocked = importer.parseAdmissionImport(JSON.stringify({
  schema: importer.ADMISSION_IMPORT_SCHEMA,
  patients: [{ id: 'EXISTS-001', name: '测试患者', bed: '3床', age: '', gender: '女', admissionDate: '2026-08-08', surgeon: '', patientType: '', diagnosis: '', allergies: '', surgeryDate: '', dischargeDate: '', surgeryName: '' }],
}), options);
assert.equal(blocked.ok, true);
assert.equal(blocked.summary.blocked, 1);
assert.match(blocked.candidates[0].errorText, /已存在/);
assert.match(blocked.candidates[0].errorText, /今日入院/);
assert.match(blocked.candidates[0].errorText, /缺少主刀医生/);
assert.equal(blocked.candidates[0].patient.bed, '3');

const corrected = importer.parseAdmissionImport(JSON.stringify({
  schema: importer.ADMISSION_IMPORT_SCHEMA,
  department: '整形外科',
  patients: [{ ...blocked.candidates[0].patient, id: 'NEW-002', admissionDate: today, surgeon: '补充主刀', managedByDaihuanyu: true }],
}), options);
assert.equal(corrected.ok, true);
assert.equal(corrected.summary.ready, 1);
assert.equal(corrected.candidates[0].selected, true);

const unmanaged = importer.parseAdmissionImport(JSON.stringify({
  schema: importer.ADMISSION_IMPORT_SCHEMA,
  department: '整形外科',
  patients: [{ id: 'OTHER-001', name: '测试患者', bed: '6', age: '', gender: '男', admissionDate: today, surgeon: '其他医生', patientType: '普通', diagnosis: '', allergies: '', surgeryDate: '', dischargeDate: '', surgeryName: '', managedByDaihuanyu: false }],
}), options);
assert.equal(unmanaged.summary.blocked, 1);
assert.match(unmanaged.candidates[0].errorText, /由代寰宇负责管理/);

const badSchema = importer.parseAdmissionImport('{"schema":"other","patients":[]}', options);
assert.equal(badSchema.ok, false);

console.log('admission structured import parsing: passed');
