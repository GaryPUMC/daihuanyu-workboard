import { todayKey } from './workspace-store';

function escapeRegExp(value) {
  return value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

function replaceKnownValue(text, value, replacement) {
  if (!value || `${value}`.length < 2) return text;
  return text.replace(new RegExp(escapeRegExp(`${value}`), 'g'), replacement);
}

export function deidentifyRoundText(patient, form) {
  const sections = [
    ['主诉与夜间情况', form.symptoms],
    ['查体要点', form.exam],
    ['检查结果', form.results],
    ['当前评估', form.assessment],
    ['当日计划', form.plan],
    ['查房原文', form.rawText],
  ].filter((item) => item[1] && item[1].trim());
  let text = sections.map((item) => `${item[0]}：${item[1].trim()}`).join('\n');
  text = replaceKnownValue(text, patient.name, '[姓名已移除]');
  text = replaceKnownValue(text, patient.id, '[住院号已移除]');
  text = replaceKnownValue(text, patient.bed, '[床位已移除]');
  text = text
    .replace(/\b1\d{10}\b/g, '[手机号已移除]')
    .replace(/\b\d{15,18}[0-9Xx]\b/g, '[证件号已移除]')
    .replace(/(?:住院号|病案号|患者ID)\s*[:：]?\s*[A-Za-z0-9_-]+/gi, '[编号已移除]');
  return text;
}

export function findResidualIdentifiers(text, patient) {
  const warnings = [];
  if (patient.name && text.includes(patient.name)) warnings.push('姓名');
  if (patient.id && text.includes(patient.id)) warnings.push('住院号');
  if (patient.bed && text.includes(patient.bed)) warnings.push('床位');
  if (/\b1\d{10}\b/.test(text)) warnings.push('疑似手机号');
  if (/\b\d{15,18}[0-9Xx]\b/.test(text)) warnings.push('疑似证件号');
  return Array.from(new Set(warnings));
}

function categoryFor(title) {
  if (/血|化验|检查|影像|复查/.test(title)) return '检查';
  if (/谈话|签字|沟通|同意/.test(title)) return '沟通签字';
  if (/引流|疼痛|切口|生命体征|尿量|活动/.test(title)) return '术后观察';
  if (/出院|宣教|复诊|病历/.test(title)) return '出院整理';
  return '查房';
}

function priorityFor(title) {
  return /立即|紧急|危急|重点|异常|尽快/.test(title) ? '重要' : '普通';
}

export function createLocalTaskDrafts(form) {
  const source = [form.plan, form.rawText].filter(Boolean).join('\n');
  const candidates = source.split(/[\n；;。]+/).map((item) => item.trim())
    .filter((item) => item.length >= 2)
    .filter((item) => /查|复|关注|观察|确认|完成|安排|记录|沟通|签字|拔|停|调整|处理|随访|宣教/.test(item));
  return Array.from(new Set(candidates)).slice(0, 8).map((title, index) => ({
    id: `draft-${Date.now()}-${index}`,
    title,
    category: categoryFor(title),
    priority: priorityFor(title),
    dueAt: todayKey(),
    reason: '根据查房计划中的行动性语句生成',
    selected: true,
    source: '脱敏查房建议',
  }));
}

export function buildAIRequest(patient, form) {
  const deidentifiedText = deidentifyRoundText(patient, form);
  const warnings = findResidualIdentifiers(deidentifiedText, patient);
  return {
    ok: warnings.length === 0,
    warnings,
    payload: {
      deidentifiedText,
      clinicalContext: {
        department: patient.department || '',
        stage: patient.stage || '',
        surgeryName: patient.surgeryName || '',
        conditions: patient.conditions || [],
      },
      expectedOutput: ['title', 'category', 'priority', 'dueAt', 'reason'],
    },
  };
}

export function requestExternalTaskDrafts() {
  return Promise.reject(new Error('尚未配置安全代理；不会从小程序直接发送患者资料或保存 API 密钥'));
}
