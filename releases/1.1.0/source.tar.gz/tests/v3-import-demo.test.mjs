import assert from 'node:assert/strict';
import fs from 'node:fs';
import { createV3ImportDemo } from './fixtures/v3-import-demo.mjs';

const storage = new Map();
globalThis.wx = {
  getStorageSync: (key) => storage.get(key),
  setStorageSync: (key, value) => storage.set(key, value),
};

const sourcePath = new URL('../utils/workspace-store.js', import.meta.url);
const source = fs.readFileSync(sourcePath, 'utf8');
const store = await import(`data:text/javascript;base64,${Buffer.from(source).toString('base64')}`);
const sourceWorkspace = createV3ImportDemo();
const imported = store.prepareBackupImport(sourceWorkspace);

assert.equal(imported.sourceSchemaVersion, 3);
assert.equal(imported.targetSchemaVersion, 4);
assert.equal(imported.migrated, true);
assert.equal(imported.workspace.patients.length, 10);
assert.equal(imported.workspace.tasks.length >= 58, true);
assert.equal(imported.workspace.devices.length, 9);
assert.equal(imported.workspace.observations.length, 3);
assert.equal(imported.workspace.clinicalEvents.length, 11);
assert.equal(imported.workspace.pathologySpecimens.length, 4);
assert.equal(imported.workspace.patients[0].id, 'DEMO-V3-001');
assert.equal(imported.workspace.patients[0].allergies, '');

const dischargeTarget = imported.workspace.patients[0];
dischargeTarget.stage = '术后';
dischargeTarget.dischargeDate = '';
storage.set('daihuanyu_workboard_local_v3', structuredClone(imported.workspace));
const discharged = store.dischargePatient(dischargeTarget.id);
const dischargedWorkspace = store.getWorkspace();
const dischargedPatient = dischargedWorkspace.patients.find((item) => item.id === dischargeTarget.id);
assert.equal(discharged.ok, true);
assert.equal(dischargedPatient.stage, '出院');
assert.equal(dischargedPatient.dischargeDate, store.todayKey());
assert.equal(dischargedWorkspace.stageLogs[0].action, 'discharge');

const scheduledWorkspace = structuredClone(imported.workspace);
scheduledWorkspace.patients[1].stage = '术后';
scheduledWorkspace.patients[1].dischargeDate = store.todayKey();
scheduledWorkspace.patients[2].stage = '术后';
scheduledWorkspace.patients[2].dischargeDate = '2999-12-31';
storage.set('daihuanyu_workboard_local_v3', scheduledWorkspace);
const scheduled = store.getWorkspace();
assert.equal(scheduled.patients[1].stage, '出院');
assert.equal(scheduled.patients[2].stage, '术后');
assert.equal(scheduled.stageLogs[0].action, 'scheduled-discharge');

console.log('v3 de-identified import demo, manual discharge, and scheduled discharge: passed');
