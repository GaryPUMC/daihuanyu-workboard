import { addSettingItem, createPatient, getPatientStatus, getWorkspace, maskPatient, setActiveDepartment, todayKey, updatePatient } from '../../utils/workspace-store';

const CUSTOM_PROCEDURE_OPTION = '＋ 自定义新术式';

function isSameDayDayPatient(patient) {
  return patient.patientType === '日间' && patient.admissionDate && patient.admissionDate === patient.dischargeDate;
}

function isDischargedPatient(patient) {
  return getPatientStatus(patient) === '出院' && !isSameDayDayPatient(patient);
}

function nextDayKey(dateString) {
  const [year, month, day] = `${dateString}`.split('-').map(Number);
  const date = new Date(Date.UTC(year, month - 1, day + 1));
  return `${date.getUTCFullYear()}-${`${date.getUTCMonth() + 1}`.padStart(2, '0')}-${`${date.getUTCDate()}`.padStart(2, '0')}`;
}

const emptyForm = () => {
  const admissionDate = todayKey();
  return { id: '', name: '', bed: '', age: '', gender: '', diagnosis: '', allergies: '', admissionDate, surgeryDate: nextDayKey(admissionDate), dischargeDate: '', surgeon: '', firstAssistant: '', patientType: '普通' };
};

Page({
  data: {
    patients: [], query: '', viewMode: 'active', privacyVisible: false,
    showForm: false, editingId: '', form: emptyForm(),
    templates: [], templateOptions: [], templateIndex: 0,
    departments: [], departmentIndex: 0, procedures: [], procedureOptions: [], procedureIndex: 0, customProcedureMode: false, customProcedure: '', addCustomProcedureToLibrary: false,
    diagnoses: [], genders: ['男', '女'], patientTypes: ['普通', '国疗', '日间'], activeDepartment: '', currentDepartmentIndex: 0,
  },
  onShow() {
    this.setData({ privacyVisible: false });
    this.loadPatients();
  },
  onHide() { this.setData({ privacyVisible: false }); },
  loadPatients() {
    const query = this.data.query.trim().toLowerCase();
    const workspace = getWorkspace();
    const activeDepartment = workspace.settings.activeDepartment;
    const activePatients = workspace.patients.filter((patient) => !isDischargedPatient(patient));
    const dischargedPatients = workspace.patients.filter(isDischargedPatient);
    const allPatients = this.data.viewMode === 'archive' ? [...dischargedPatients, ...workspace.archivedPatients] : activePatients;
    const searchablePatients = [...workspace.patients, ...workspace.archivedPatients];
    const source = query ? searchablePatients : allPatients.filter((patient) => patient.department === activeDepartment);
    let patients = source.map((patient) => {
      const masked = maskPatient(patient);
      return {
        ...masked,
        displayName: this.data.privacyVisible ? patient.name : masked.displayName,
        displayId: this.data.privacyVisible ? patient.id : masked.displayId,
        listBadge: this.data.viewMode === 'archive' ? '出' : patient.admissionDate === todayKey() ? '新' : '',
      };
    });
    if (query) patients = patients.filter((item) => `${item.id}${item.name}${item.bed}${item.department}${item.diagnosis}`.toLowerCase().includes(query));
    const templateOptions = [{ id: '', name: '自动匹配（术式 > 科室）' }, ...workspace.templates];
    this.setData({
      patients, templates: workspace.templates, templateOptions,
      departments: workspace.settings.departments, procedures: workspace.settings.procedures, procedureOptions: [...workspace.settings.procedures, CUSTOM_PROCEDURE_OPTION],
      diagnoses: workspace.settings.diagnoses, activeDepartment, currentDepartmentIndex: Math.max(0, workspace.settings.departments.indexOf(activeDepartment)),
    });
  },
  search(e) { this.setData({ query: e.detail.value }, () => this.loadPatients()); },
  switchView(e) {
    this.setData({ viewMode: e.currentTarget.dataset.mode, showForm: false, editingId: '' }, () => this.loadPatients());
  },
  togglePrivacy() { this.setData({ privacyVisible: !this.data.privacyVisible }, () => this.loadPatients()); },
  startCreate() {
    const workspace = getWorkspace();
    this.setData({ showForm: true, editingId: '', form: emptyForm(), departmentIndex: Math.max(0, workspace.settings.departments.indexOf(workspace.settings.activeDepartment)), procedureIndex: 0, templateIndex: 0, customProcedureMode: false, customProcedure: '', addCustomProcedureToLibrary: false });
  },
  cancelForm() { this.setData({ showForm: false, editingId: '', form: emptyForm() }); },
  editPatient(e) {
    const id = e.currentTarget.dataset.id;
    const workspace = getWorkspace();
    const patient = workspace.patients.find((item) => item.id === id);
    if (!patient) return;
    const templateOptions = [{ id: '', name: '自动匹配（术式 > 科室）' }, ...workspace.templates];
    const procedure = patient.surgeryName || '未选择术式';
    const knownProcedureIndex = workspace.settings.procedures.indexOf(procedure);
    const customProcedureMode = Boolean(patient.surgeryName) && knownProcedureIndex < 0;
    this.setData({
      showForm: true, editingId: id,
      form: {
        id: patient.id, name: patient.name, bed: patient.bed, age: patient.age || '', diagnosis: patient.diagnosis || '',
        gender: patient.gender || '', admissionDate: patient.admissionDate || '', surgeryDate: patient.surgeryDate || '', dischargeDate: patient.dischargeDate || '', allergies: patient.allergies || '', surgeon: patient.surgeon || '', firstAssistant: patient.firstAssistant || '', patientType: patient.patientType || '普通',
      },
      departmentIndex: Math.max(0, workspace.settings.departments.indexOf(patient.department)),
      procedureIndex: customProcedureMode ? workspace.settings.procedures.length : Math.max(0, knownProcedureIndex),
      customProcedureMode, customProcedure: customProcedureMode ? patient.surgeryName : '', addCustomProcedureToLibrary: false,
      templateIndex: Math.max(0, templateOptions.findIndex((item) => item.id === patient.templateId)),
    });
  },
  input(e) {
    const field = e.currentTarget.dataset.field;
    const value = ['bed', 'age'].includes(field) ? `${e.detail.value}`.replace(/\D/g, '') : e.detail.value;
    this.setData({ [`form.${field}`]: value });
  },
  chooseDepartment(e) { this.setData({ departmentIndex: Number(e.detail.value) }); },
  chooseGender(e) { this.setData({ 'form.gender': e.currentTarget.dataset.value }); },
  choosePatientType(e) { this.setData({ 'form.patientType': e.currentTarget.dataset.value }); },
  chooseCurrentDepartment(e) {
    const department = this.data.departments[Number(e.detail.value)];
    if (department && setActiveDepartment(department)) this.setData({ showForm: false, editingId: '' }, () => this.loadPatients());
  },
  chooseTemplate(e) { this.setData({ templateIndex: Number(e.detail.value) }); },
  chooseProcedure(e) {
    const procedureIndex = Number(e.detail.value);
    const customProcedureMode = procedureIndex === this.data.procedureOptions.length - 1;
    this.setData({ procedureIndex, customProcedureMode, customProcedure: customProcedureMode ? this.data.customProcedure : '', addCustomProcedureToLibrary: customProcedureMode ? this.data.addCustomProcedureToLibrary : false });
  },
  inputCustomProcedure(e) { this.setData({ customProcedure: e.detail.value }); },
  toggleAddCustomProcedure(e) { this.setData({ addCustomProcedureToLibrary: Boolean(e.detail.value) }); },
  chooseDiagnosis(e) { this.setData({ 'form.diagnosis': e.currentTarget.dataset.value }); },
  savePatient() {
    const { id, name, bed, age, gender, diagnosis, allergies, admissionDate, surgeryDate, dischargeDate, surgeon, firstAssistant, patientType } = this.data.form;
    if (!id.trim() || !name.trim() || !bed.trim() || !surgeon.trim()) return wx.showToast({ title: '请填写住院号、姓名、床位和主刀医生', icon: 'none' });
    if (!gender) return wx.showToast({ title: '请选择性别', icon: 'none' });
    const template = this.data.templateOptions[this.data.templateIndex];
    const selectedProcedure = this.data.procedureOptions[this.data.procedureIndex];
    const procedure = this.data.customProcedureMode ? `${this.data.customProcedure || ''}`.trim() : selectedProcedure;
    if (this.data.customProcedureMode && !procedure) return wx.showToast({ title: '请填写自定义术式名称', icon: 'none' });
    const payload = {
      id: id.trim(), name: name.trim(), bed: bed.trim(), age: age.trim(), gender,
      diagnosis: diagnosis.trim(), allergies: allergies.trim(), admissionDate, surgeryDate, dischargeDate, surgeon: surgeon.trim(), firstAssistant: firstAssistant.trim(), patientType,
      surgeryName: procedure === '未选择术式' ? '' : procedure,
      templateId: template ? template.id : '', department: this.data.departments[this.data.departmentIndex],
    };
    let result;
    const wasEditing = Boolean(this.data.editingId);
    if (wasEditing) result = updatePatient(this.data.editingId, payload);
    else {
      const pod = surgeryDate ? Math.floor((new Date(`${todayKey()}T00:00:00+08:00`).getTime() - new Date(`${surgeryDate}T00:00:00+08:00`).getTime()) / 86400000) : null;
      result = createPatient({ ...payload, stage: surgeryDate ? (pod >= 0 ? '术后' : '术前') : '入院' });
    }
    if (!result.ok) return wx.showToast({ title: result.error, icon: 'none', duration: 2500 });
    if (this.data.customProcedureMode && this.data.addCustomProcedureToLibrary) addSettingItem('procedures', procedure);
    this.setData({ showForm: false, editingId: '', form: emptyForm(), templateIndex: 0, procedureIndex: 0, customProcedureMode: false, customProcedure: '', addCustomProcedureToLibrary: false });
    this.loadPatients();
    wx.showToast({ title: wasEditing ? '患者资料已更新' : '已保存至本机', icon: 'success' });
  },
  goDetail(e) { wx.navigateTo({ url: `/pages/patient-detail/patient-detail?id=${encodeURIComponent(e.currentTarget.dataset.id)}` }); },
});
